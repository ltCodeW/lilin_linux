#if 1 //net_device结构

//include/linux/netdevice.h：1781
//内核使用net_device结构管理一个网络设备，该结构是对网络设备的抽象
//而结构中的许多字段，特别是回调函数，都由网络设备驱动程序设置
struct net_device 
{
	char				name[IFNAMSIZ];		//网卡名称，如enss3、eth0、eth1等
											//调用alloc_netdev_mqs()时的参数name
											//调用alloc_etherdev()时，name被设置为"eth%d"
											//在register_netdev()中，设置成完整的网络设备名，如"eth1"
											
	struct hlist_node	name_hlist;			//哈希表冲突链表上的节点
											//该哈希表：网络设备名组成的哈希表
											//该哈希表由net结构的dev_name_head字段指向
											//register_netdev()中会加入上述哈希表
											
	struct dev_ifalias	__rcu *ifalias;		//ifconfig命令配置别名时使用，在单网卡多接口用以区分网段时会使用到，在IPROUTE工具中，提供了新方法。

	/*
	 * I/O相关
	 */

	//网络设备所用的共享内存，用于设备和内核沟通
	//通常由网路设备驱动初始化
	unsigned long		mem_end;			//网络设备所用的共享内存结束位置	
	unsigned long		mem_start;			//网络设备所用的共享内存起始位置
	
	unsigned long		base_addr;			//网络设备I/O端口的起始地址
	int					irq;				//网络设备占据的中断号
											//通常由驱动程序设置为pci_dev结构的irp（由PCI层设置）

	/*
	 *	Some hardware also needs these fields (state,dev_list,
	 *	napi_list,unreg_list,close_list) but they are not
	 *	part of the usual set specified in Space.c.
	 */
	//register_netdev()中，该字段的__LINK_STATE_PRESENT位被设置
	//dev_open()中，该字段的__LINK_STATE_START位被设置
	unsigned long		state;				//Generic network queuing layer state, see netdev_state_t

	struct list_head	dev_list;			//同一个net结构的网络设备组成的链表的节点
											//链表头是net结构的dev_base_head字段
											//register_netdev()中会加入上述链表
	
	struct list_head	napi_list;			//List entry used for polling NAPI devices
											//链表元素类型，即napi_struct结构，链入链表的字段即dev_list
											//被alloc_netdev_mqs()初始化
											//通常，驱动程序会将自己的napi_struct结构，链接到该链表

	struct list_head	unreg_list;			//List entry  when we are unregistering the device; see the function unregister_netdev
											//被alloc_netdev_mqs()初始化
											//需要被unregister的net_device构成的链表
											
	struct list_head	close_list;			//List entry used when we are closing the device
											//被alloc_netdev_mqs()初始化
											
	struct list_head	ptype_all;			//Device-specific packet handlers for all protocols
											//被alloc_netdev_mqs()初始化
											//类似于全局的ptype_all链表，可以监听任意类型的数据包
											//只不过该字段只针对当前net_device结构接收到的数据包
											//__netif_receive_skb_core()中会调用注册的回调
											
	struct list_head	ptype_specific;		//Device-specific, protocol-specific packet handlers
											//被alloc_netdev_mqs()初始化
											//类似于ptype_base全局数组，但是ptype_specific链表混合了各种协议对应的packet_type结构
											//只不过该字段只针对当前net_device结构接收到的数据包
											//__netif_receive_skb_core()中会调用注册的回调

	//若干net_device结构，可以被组织成堆叠层次关系
	//upper是当前net_device结构的上层net_device结构组成的链表
	//lower是当前net_device结构的下层net_device结构组成的链表
	//adj_list的upper、lower指向的链表，其元素是netdev_adjacent结构，后者的list字段构成链表
	struct 
	{
		struct list_head upper;				//被alloc_netdev_mqs()初始化
		struct list_head lower;				//被alloc_netdev_mqs()初始化
	} adj_list;								//Directly linked devices, like slaves for bonding

	
	/*这些特性指，如能否对高端内存做DMA，分散聚集IO，UFO，校验和等等，见include/linux/netdev_features.h第14行开始。*/
	netdev_features_t	features;			//Currently active device features
	
	netdev_features_t	hw_features;		//User-changeable features
	netdev_features_t	wanted_features;	//User-requested features
	netdev_features_t	vlan_features;		//Mask of features inheritable by VLAN devices
	netdev_features_t	hw_enc_features;	//Mask of features inherited by encapsulating devices. This field indicates what encapsulation offloads the hardware is capable of doing, and drivers will need to set them appropriately.
	netdev_features_t	mpls_features;		//Mask of features inheritable by MPLS
	netdev_features_t	gso_partial_features;

	int					ifindex;			//网络设备的唯一ID。interface index
	int					group;				//The group the device belongs to
											//alloc_netdev_mqs()中被初始化INIT_NETDEV_GROUP
											//所有网络设备默认都属于组INIT_NETDEV_GROUP

	/*该网卡相关的统计信息，如接收、发送的数据包总数相关信息等。
	 * netstat -i或者ifconfig看到的关于数据包统计信息源于此处。
	 * 应该使用rtnl_link_stats64，而非本字段
     */
	struct net_device_stats	stats;			//Statistics struct, which was left as a legacy, use rtnl_link_stats64 instead

	atomic_long_t		rx_dropped;			//Dropped packets by core network, do not use this in drivers
	atomic_long_t		tx_dropped;			//Dropped packets by core network, do not use this in drivers
	atomic_long_t		rx_nohandler;		//nohandler dropped packets by core network on inactive devices, do not use this in drivers

	/* Stats to monitor link on/off, flapping */
	atomic_t			carrier_up_count;	//记录链路从断开到又连接的次数。Number of times the carrier has been up
	atomic_t			carrier_down_count;	//记录链路断开的次数。Number of times the carrier has been down

	const struct iw_handler_def		*wireless_handlers;		//List of functions to handle Wireless Extensions, instead of ioctl, see <net/iw_handler.h> for details.
	struct iw_public_data			*wireless_data;			//Instance data managed by the core of wireless extensions

	
	/* 网卡发送接收数据的函数地址保存于此
	 * 不同的设备不同，一般由网络设备驱动编写者提供
	 */
	const struct net_device_ops 	*netdev_ops;			//Includes several pointers to callbacks, if one wants to override the ndo_*() functions
	const struct ethtool_ops 		*ethtool_ops;			//ethtool工具的操作方法的集合。Management operations
															//若驱动程序没有设置该字段，则alloc_netdev_mqs()设置为：
															// .ethtool_ops = &default_ethtool_ops
															
	const struct l3mdev_ops			*l3mdev_ops;
	const struct ndisc_ops 			*ndisc_ops;				//Includes callbacks for different IPv6 neighbour discovery handling. Necessary for e.g. 6LoWPAN.
	const struct xfrmdev_ops 		*xfrmdev_ops;
	const struct tlsdev_ops 		*tlsdev_ops;
	const struct header_ops 		*header_ops;			//Includes callbacks for creating,parsing,caching,etc of Layer 2 headers.
															//alloc_etherdev()中被设置为eth_header_ops

	unsigned int		flags;				//接口标志（按BSD方式），包括网络设备能支持的功能、设备的状态（如IFF_UP、IFF_RUNNING）
											//alloc_etherdev()中被设为: IFF_BROADCAST|IFF_MULTICAST
	
	unsigned int		priv_flags;			//Like 'flags' but invisible to userspace, see if.h for the definitions
											//alloc_netdev_mqs()中设置为：
											// IFF_XMIT_DST_RELEASE | IFF_XMIT_DST_RELEASE_PERM;
											//若驱动程序未设置tx_queue_len（即=0，对于以太网设置了该字段为1000），该字段或上
											// IFF_NO_QUEUE
											//alloc_etherdev()设置为 IFF_XMIT_DST_RELEASE | IFF_XMIT_DST_RELEASE_PERM | IFF_TX_SKB_SHARING

	unsigned short		gflags;				//Global flags ( kept as legacy )
	unsigned short		padded;				//How much padding added by alloc_netdev()
											//alloc_netdev_mqs()根据驱动私有数据空间、net_device结构大小之和，32位对齐后，分配空间
											//得到的空间地址，32位对齐后，赋值给this指针
											//this指针与得到的空间地址之差，即padded字段

	unsigned char		operstate;			//RFC2863 operstate
	unsigned char		link_mode;			//Mapping policy to operstate

	unsigned char		if_port;			//Selectable AUI, TP, ...
											//有些网络设备有一个以上的连接器，允许用户根据需求选择其中之一使用
											//该字段用于设置设备的端口类型，即选择某个连接器
											//一般驱动程序会根据该字段的值，向不同的端口收发数据
											
	unsigned char		dma;				//网络设备使用的DMA channel

	unsigned int		mtu;				//Interface MTU（maximum transfer unit） value
											//alloc_etherdev()中被设置为ETH_DATA_LEN=1500
											
	unsigned int		min_mtu;			//Interface Minimum MTU value
											//alloc_etherdev()中被设置为ETH_MIN_MTU=68
											
	unsigned int		max_mtu;			//Interface Maximum MTU value
											//alloc_etherdev()中被设置为ETH_DATA_LEN=1500
	
	unsigned short		type;				//网络设备的硬件类型。Interface hardware type
											//类型定义在include/uapi/linux/if_arp.h中，如	
											//ARPHRD_ETHER，表示Ethernet 10Mbps
											//ARPHRD_IEEE802，表示IEEE 802.2 Ethernet/TR/TB
											//alloc_etherdev()中被设置为ARPHRD_ETHER
											
	unsigned short		hard_header_len;	//Maximum hardware header length.
											//alloc_etherdev()中被设为ETH_HLEN=14，即MAC头部大小
	
	unsigned char		min_header_len;		//Minimum hardware header length
											//alloc_etherdev()中被设为ETH_HLEN=14，即MAC头部大小

	unsigned short		needed_headroom;	//Extra headroom the hardware may need, but not in all cases can this be guaranteed
	unsigned short		needed_tailroom;	//Extra tailroom the hardware may need, but not in all cases can this be guaranteed. Some cases also use LL_MAX_HEADER instead to allocate the skb

	/* Interface address info. */
	unsigned char		perm_addr[MAX_ADDR_LEN];		//永久性硬件地址，MAC地址。Permanent hw address
														//register_netdev()中，从dev_addr字段复制得到MAC地址
														
	unsigned char		addr_assign_type;				//Hw address assignment type
														//默认值0=NET_ADDR_PERM
	
	unsigned char		addr_len;						//dev_addr字段代表的Hardware address length，比如MAC地址长度
														//alloc_etherdev()中被设置为ETH_ALEN=6
	
	unsigned char		upper_level;					//Maximum depth level of upper devices.
														//被alloc_netdev_mqs()初始化为1
														
	unsigned char		lower_level;					//Maximum depth level of lower devices.
														//被alloc_netdev_mqs()初始化为1

	unsigned short		neigh_priv_len;					//Used in neigh_alloc()
	
	unsigned short      dev_id;				//Used to differentiate devices that share the same link layer address
	unsigned short     	dev_port;			//Used to differentiate devices that share the same function
	spinlock_t			addr_list_lock;		//register_netdev()中初始化
	unsigned char		name_assign_type;	//调用alloc_netdev_mqs()时的参数name_assign_type
											//由alloc_etherdev()调用时被设置为NET_NAME_UNKNOWN	
											
	bool				uc_promisc;			//Counter that indicates promiscuous mode has 
											//been enabled due to the need to listen to
											//additional unicast addresses in a device that
											//does not implement ndo_set_rx_mode()
											
	struct netdev_hw_addr_list	uc;			//unicast mac addresses
											//由alloc_netdev_mqs()初始化该链表头
	
	struct netdev_hw_addr_list	mc;			//multicast mac addresses
											//由alloc_netdev_mqs()初始化该链表头
											
	struct netdev_hw_addr_list	dev_addrs;	//list of device hw addresses（如MAC地址）
											//字段dev_addr，指向该链表第一个元素的addr数组
											//由alloc_netdev_mqs()初始化该链表头，并加入第一个元素
											//元素类型是netdev_hw_addr结构，初始化的字段包括
											//	.addr数组清0
											//	.type = NETDEV_HW_ADDR_T_LAN
											//	.refcount = 1
											//	.global_use = false
											//	.synced = 0
											//	.sync_cnt = 0
											//	.list = 加入dev_addrs链表

	struct kset			*queues_kset;		//Group of all Kobjects in the Tx and RX queues

	//混杂模式标志，即数据包目的地址非本机也会被收集到，wireshark、tcpdump会将网卡置于该工作模式
	//该字段是混杂模式计数器：进入混杂模式时递增该计数器，退出混杂模式时递减计数器
	//只有当计数器为0时，才会真正退出混杂模式
	//一般而言，当该字段非0时，flags字段也会设置IFF_PROMISC位
	unsigned int		promiscuity;		

	//该字段非0时，监听所有多播地址
	//该字段是一个计数器，和promiscuity字段类似
	unsigned int		allmulti;			//Counter, enables or disables allmulticast mode

	/* Protocol-specific pointers */
	
	struct vlan_info __rcu		*vlan_info;	//VLAN info
	struct dsa_port				*dsa_ptr;	//dsa specific data
	struct tipc_bearer __rcu 	*tipc_ptr;	//TIPC specific data
	void 						*atalk_ptr;	//AppleTalk link

	//包含了各种与IPv4相关的参数，比如该网络设备/接口上所配置的IP地址列表
	//register_netdevice_notifier函数中通过netdevice通知链，调用inetdev_event()完成初始化
	struct in_device __rcu		*ip_ptr;	//IPv4 specific data
	
	struct dn_dev __rcu     	*dn_ptr;	//DECnet specific data
	struct inet6_dev __rcu		*ip6_ptr;	//IPv6 specific data
	void						*ax25_ptr;	//AX.25 specific data
	struct wireless_dev			*ieee80211_ptr;			//IEEE 802.11 specific data, assign before registering
	struct wpan_dev				*ieee802154_ptr;
	struct mpls_dev __rcu		*mpls_ptr;

/*
 * Cache lines mostly used on receive path (including eth_type_trans())
 */
	/* Interface address info used in eth_type_trans() */
	unsigned char				*dev_addr;	//网络设备的硬件地址，比如以太网卡的MAC地址。Hw address (before bcast, because most packets are unicast)
											//实际上是.dev_addrs链表第一个元素，即netdev_hw_addr结构的addr数组地址

	//_rx是一个接收队列数组，不过在alloc_etherdev()中，只有一个队列
 	//alloc_netdev_mqs()中:
 	//  分配所有接收队列结构所占空间，接收队列个数，即num_rx_queues
 	//	对于每一个队列，初始化
 	//			.dev = 当前net_device结构地址
 	//			.xdp_rxq->dev = 当前net_device结构地址;
	//			.xdp_rxq->queue_index = 当前接收队列在数组中的编号;
	//			.xdp_rxq->reg_state = REG_STATE_REGISTERED;
	//			.xdp其余字段被清0								
	struct netdev_rx_queue		*_rx;
	
	unsigned int				num_rx_queues;			//the number of RX subqueues allocated at alloc_netdev_mqs() time
	unsigned int				real_num_rx_queues;		//Number of RX queues currently active in device
														//alloc_netdev_mqs()中被初始化为num_rx_queues字段

	struct bpf_prog __rcu		*xdp_prog;
	unsigned long				gro_flush_timeout;
	
	rx_handler_func_t __rcu		*rx_handler;			//handler for received packets
														//__netif_receive_skb()内部会调用该回调函数，主要用于对接收到的帧进行特殊处理
														//该回调函数被调用的时机，位于接收到MAC帧，交给网络层处理之前
														//内核提供了netdev_rx_handler_register接口函数向接口注册rx_handler，反注册使用netdev_rx_handler_unregister()
														//比如针对网桥设备，一般默认情况，该字段为NULL
	
	void __rcu					*rx_handler_data;
	struct mini_Qdisc __rcu		*miniq_ingress;			//ingress/clsact qdisc specific data for ingress processing

	struct netdev_queue __rcu 	*ingress_queue;
	struct nf_hook_entries __rcu *nf_hooks_ingress;		//alloc_netdev_mqs()中被初始化为NULL

	unsigned char				broadcast[MAX_ADDR_LEN];//硬件广播地址，hw bcast address
														//alloc_etherdev()中被初始化为6字节的0xff
														
	struct cpu_rmap				*rx_cpu_rmap;			//CPU reverse-mapping for RX completion interrupts,
														//indexed by RX queue number. Assigned by driver.
														//This must only be set if the ndo_rx_flow_steer
														//operation is defined
														
	struct hlist_node			index_hlist;			//Device index hash chain
														//该字段是哈希表的一个节点
														//哈希表头是net结构的dev_index_head字段
														//key实际上是net_device结构的ifindex字段取低8位
														//register_netdev()中会加入上述哈希表

/*
 * Cache lines mostly used on transmit path
 */
 	//_tx是一个发送队列数组，不过在alloc_etherdev()中，只有一个队列
 	//alloc_netdev_mqs()中:
 	//  分配所有发送队列结构所占空间，发送队列个数，即num_tx_queues
 	//	对于每一个队列，初始化
 	//			._xmit_lock =; 初始化自旋锁
 	//			.xmit_lock_owner = -1;
 	//			.dev = 当前net_device结构地址
 	//			.numa_node = NUMA_NO_NODE
 	//			.dql->max_limit = DQL_MAX_LIMIT;
	//			.dql->min_limit = 0;
	//			.dql->slack_hold_time = HZ;
	//			.dql->limit = 0;
	//			.dql->num_queued = 0;
	//			.dql->num_completed = 0;
	//			.dql->last_obj_cnt = 0;
	//			.dql->prev_num_queued = 0;
	//			.dql->prev_last_obj_cnt = 0;
	//			.dql->prev_ovlimit = 0;
	//			.dql->lowest_slack = UINT_MAX;
	//			.dql->slack_start_time = jiffies;
	//
	//register_netdev()中的设置：
	//			.qdisc = &noop_qdisc;
	//			.qdisc_sleeping = &noop_qdisc;
	//
	//pcnet32_open()中的设置：
	//			.state 清除位0（__QUEUE_STATE_DRV_XOFF）表明可以使用网卡发送数据
	//
	//dev_open()中的设置：
	//			.qdisc_sleeping = ; 分配了（Qdisc结构+ default_qdisc_ops->priv_size）大小的空间
	//								Qdisc结构在前，priv_size部分在后(该部分类型是pfifo_fast_priv结构)
	//								不过Qdisc结构部分的地址，必须是Qdisc结构大小对齐
	//								Qdisc结构对齐的地址，与分配的内存地址之差，存放于padded字段
	//			.qdisc_sleeping->padded =;
	//			.qdisc_sleeping->gso_skb = 初始化该sk_buff_head结构;
	//			.qdisc_sleeping->skb_bad_txq = 初始化该sk_buff_head结构;
	//			.qdisc_sleeping->q = 初始化该qdisc_skb_head结构;
	//			.qdisc_sleeping->q.lokc = 初始化该锁;
	//			.qdisc_sleeping->cpu_bstats = 分配per cpu空间，大小是struct gnet_stats_basic_cpu
	//			.qdisc_sleeping->cpu_qstats = 分配per cpu空间，大小是struct gnet_stats_queue
	//			.qdisc_sleeping->busylock = 初始化该锁;
	//			.qdisc_sleeping->seqlock = 初始化该锁;
	//			.qdisc_sleeping->running.sequence = 0;
	//			.qdisc_sleeping->ops = &pfifo_fast_ops;
	//			.qdisc_sleeping->flags = pfifo_fast_ops.static_flags = TCQ_F_NOLOCK | TCQ_F_CPUSTATS
	//			.qdisc_sleeping->enqueue = pfifo_fast_ops.enqueue = pfifo_fast_enqueue;
	//			.qdisc_sleeping->dequeue = pfifo_fast_ops.dequeue = pfifo_fast_dequeue;
	//			.qdisc_sleeping->dev_queue = &_tx[0];
	//			.qdisc_sleeping->empty = true;
	//			.qdisc_sleeping->refcnt = 1;
	//			.qdisc_sleeping->parent = TC_H_ROOT;
	//
	//pfifo_fast_init()中的设置
	//			.qdisc_sleeping中pfifo_fast_ops规则私有数据部分，其类型是pfifo_fast_priv
	//					包含skb_arry q[3]数组，该数组的每个元素初始化情况如下；
	//							ring.queue = 为其分配空间，该字段指向元素类型是void*的数组，元素个数1000（tx_queue_len）
	//							ring.size = 1000（tx_queue_len）
	//							ring.batch = 16
	//							ring.producer = ring.consumer_head = ring.consumer_tail = 0;
	//							ring.producer_lock = 初始化该锁
	//							ring.consumer_lock = 初始化该锁
	//			.qdisc_sleeping->flags = TCQ_F_NOLOCK | TCQ_F_CPUSTATS | TCQ_F_CAN_BYPASS;
	//
	//dev_open()中的设置：
	//			.qdisc_sleeping->flags = TCQ_F_ONETXQUEUE | TCQ_F_NOPARENT | TCQ_F_NOLOCK | TCQ_F_CPUSTATS | TCQ_F_CAN_BYPASS;
	//			.qdisc_sleeping->refcnt++;
	//			.qdisc_sleeping->state = 该字段位__QDISC_STATE_DEACTIVATED清0
	//			.qdisc = .qdisc_sleeping
	//			.trans_start = jiffies;
	//
	//dev_queue_xmit()中的设置
	//			.qdisc->empty = false;
	//			.qdisc->running.sequence++;				//qdisc_run_begin()中++
	//			.qdisc->cpu_bstats->bstats.bytes =;		//要发送的帧长度（如果使用了GSO，则考虑了所有分段）
	//			.qdisc->cpu_bstats->bstats.packets =; 	//如果使用了GSO，则等于skb_shinfo(skb)->gso_segs；否则，等于1
	//													//即要发送的帧的个数
	//			.qdisc->running.sequence++;				//qdisc_run_end()中++
	//
	struct netdev_queue			*_tx; // ____cacheline_aligned_in_smp;
	
	unsigned int				num_tx_queues;			//the number of TX subqueues allocated at alloc_netdev_mq() time
	unsigned int				real_num_tx_queues;		//Number of TX queues currently active in device
														//alloc_netdev_mq()中该字段初始化为num_tx_queues

	//用于管理入口和出口的封包队列，和流量管理相关
	//dev_open()中的设置：
	//			qdisc = _tx[0].qdisc_sleeping
	struct Qdisc				*qdisc;					//Root qdisc from userspace point of view

	//Qdisc结构构成的哈希表
	//DECLARE_HASHTABLE			(qdisc_hash, 4);		//由alloc_netdev_mqs()初始化
	struct hlist_head qdisc_hash[1<<4];

	unsigned int				tx_queue_len;			//Max frames per queue allowed
														//网络设备的传送队列长度
														//若驱动程序未设置该字段，即=0，
														//则alloc_netdev_mqs()和alloc_etherdev()均设置为 
														// tx_queue_len = DEFAULT_TX_QUEUE_LEN(即1000，1000个封包)
														
	spinlock_t					tx_global_lock;			//alloc_netdev_mqs()初始化

	//watchdog_timer的超时时间
	int							watchdog_timeo;			//驱动程序设置，传输超时的时间值

	struct xps_dev_maps __rcu 	*xps_cpus_map;
	struct xps_dev_maps __rcu 	*xps_rxqs_map;

	struct mini_Qdisc __rcu		*miniq_egress;			//clsact qdisc specific data for egress processing

	/* These may be needed for future network-power-down code. */
	//超时时间设置为 round_jiffies(jiffies + watchdog_timeo)
	//超时时，内部会调用netdev_ops->ndo_tx_timeout
	//pcnet32中将其设为5秒
	struct timer_list			watchdog_timer;			//Represents the timeout that is used by the watchdog (see dev_watchdog())
														//在register_netdev()中初始化该定时器，超时时调用的回调函数设置为dev_watchdog

	int __percpu				*pcpu_refcnt;			//Number of references to this device
														//由alloc_netdev_mqs()分配空间
														//分配一个per cpu空间，大小是int，用作per cpu的引用计数
														//register_netdev()中，加1
														//dev_open()中，加1

	//在unregister_netdev()中，将net_device结构加入到链表net_todo_list中
	//构成链表的字段即todo_list
	struct list_head			todo_list;				//Delayed register/unregister

	//网络设备链路状态改变事件，组成了链表lweventlist
	//link_watch_list构成了该链表的元素
	//该字段本身不是链表头，一个设备当前只需要存在一个状态改变事件
	struct list_head			link_watch_list;		//被alloc_netdev_mqs()初始化

	//网络设备的注册状态
	enum { NETREG_UNINITIALIZED=0,

		   //register_netdev()设置此标志
	       NETREG_REGISTERED,	/* completed register_netdevice */
	       
	       NETREG_UNREGISTERING,/* called unregister_netdevice */

		   //unregister_netdev()设置此标志
	       NETREG_UNREGISTERED,	/* completed unregister todo */
	       
	       NETREG_RELEASED,		/* called free_netdev */
	       NETREG_DUMMY,		/* dummy device for NAPI poll */
	} reg_state:8;				//Register/unregister state machine

	bool dismantle;				//Device is going to be freed
								//调用rollback_registered_many()时设置为true

	enum {
		RTNL_LINK_INITIALIZED,
		RTNL_LINK_INITIALIZING,
	} rtnl_link_state:16;		//This enum represents the phases of creating a new link
								//rtnl represents for route Netlink

	//当为true时，unregister_netdev()会调用free_netdev()
	bool needs_free_netdev;		//Should unregister perform free_netdev?

	//unregister_netdev()中调用，销毁net_device设备
	void (*priv_destructor)(struct net_device *dev);	//Called from unregister

	struct netpoll_info __rcu	*npinfo;

	possible_net_t				nd_net;		//Network namespace this network device is inside
											//alloc_netdev_mqs()中
											//	.nd_net.net = &init_net

	/* mid-layer private */
	union 
	{
		void								*ml_priv;	//Mid-layer private
		struct pcpu_lstats __percpu			*lstats;	//Loopback statistics
		struct pcpu_sw_netstats __percpu	*tstats;	//Tunnel statistics
		struct pcpu_dstats __percpu			*dstats;	//Dummy statistics
	};

	struct garp_port __rcu	*garp_port;		//GARP
	struct mrp_port __rcu	*mrp_port;		//MRP
	
	struct device			dev;			//Class/net/name entry
											//dev.parent设置为网卡对应的pci_dev结构的dev字段(类型是struct device *)
	
	const struct attribute_group 	*sysfs_groups[4];		//Space for optional device, statistics and wireless sysfs groups
	const struct attribute_group 	*sysfs_rx_queue_group;	//Space for optional per-rx queue attributes

	const struct rtnl_link_ops 		*rtnl_link_ops;			//ip和tc工具的内核支持机制Netlink的操作集.Rtnl_link_ops

	/* for setting kernel sock attribute on TCP connection setup */
#define GSO_MAX_SIZE		65536

	/*GSO 是generic segment offload，是TSO（TCP segment offload）的升级
	 *segment数据原本在TCP层，但是为了效率，现在网卡自己支持分片操作
	 *所以有些情况下会将分片操作推迟到网卡去完成
	 */
	unsigned int			gso_max_size;	//Maximum size of generic segmentation offload
											//被alloc_netdev_mqs()初始化为GSO_MAX_SIZE
	
#define GSO_MAX_SEGS		65535

	u16						gso_max_segs;	//Maximum number of segments that can be passed to the NIC for GSO
											//被alloc_netdev_mqs()初始化为GSO_MAX_SEGS

	const struct dcbnl_rtnl_ops *dcbnl_ops;	//Data Center Bridging netlink ops
	
	s16						num_tc;			//Number of traffic classes in the net device
	struct netdev_tc_txq	tc_to_txq[TC_MAX_QUEUE];
	u8						prio_tc_map[TC_BITMASK + 1];
	unsigned int			fcoe_ddp_xid;	//Max exchange id for FCoE LRO by ddp

	struct netprio_map __rcu *priomap;		
	
	struct phy_device		*phydev;		//Physical device may attach itself for hardware timestamping
	struct sfp_bus			*sfp_bus;		//attached &struct sfp_bus structure.
	
	struct lock_class_key	qdisc_tx_busylock_key;	//lockdep class annotating Qdisc->busylock spinlock
	struct lock_class_key	qdisc_running_key;		//lockdep class annotating Qdisc->running seqcount
	struct lock_class_key	qdisc_xmit_lock_key;	//lockdep class annotating netdev_queue->_xmit_lock spinlock
	struct lock_class_key	addr_list_lock_key;		//lockdep class annotating net_device->addr_list_lock spinlock
	bool					proto_down;				//protocol port state information can be sent to the
													//switch driver and used to set the phys state of the
													//switch port.
	unsigned				wol_enabled:1;	//Wake-on-LAN is enabled
};

//include/linux/netdevice.h:161
//一般来说，是由NIC驱动程序负责修改
struct net_device_stats 
{
	unsigned long	rx_packets;		//NIC驱动接收到的帧数
	unsigned long	tx_packets;		//NIC驱动接收到的帧数
	unsigned long	rx_bytes;		//NIC驱动接收到的字节数
	unsigned long	tx_bytes;		//NIC驱动发送的字节数
	unsigned long	rx_errors;		//NIC接收失败的次数，常常是设备接收缓冲区满而导致（pcnet中有32个缓冲区）
	unsigned long	tx_errors;		//NIC发送失败的次数
	unsigned long	rx_dropped;		//接收帧时，丢包计数。可能的原因包括分配skb失败
	unsigned long	tx_dropped;
	unsigned long	multicast;
	unsigned long	collisions;
	unsigned long	rx_length_errors;
	unsigned long	rx_over_errors;
	unsigned long	rx_crc_errors;
	unsigned long	rx_frame_errors;
	unsigned long	rx_fifo_errors;
	unsigned long	rx_missed_errors;
	unsigned long	tx_aborted_errors;
	unsigned long	tx_carrier_errors;
	unsigned long	tx_fifo_errors;
	unsigned long	tx_heartbeat_errors;
	unsigned long	tx_window_errors;
	unsigned long	rx_compressed;
	unsigned long	tx_compressed;
};


//net/core/dev.c:6405
struct netdev_adjacent 
{
	struct net_device *dev;

	/* upper master flag, there can only be one master device per list */
	bool master;

	/* lookup ignore flag */
	bool ignore;

	/* counter for the number of times this device was added to us */
	u16 ref_nr;

	/* private field for the users */
	void *private;

	//若干net_device结构，可以被组织成堆叠层次关系
	//net_device结构的adj_list.upper，是当前net_device结构的上层net_device结构组成的链表
	//net_device结构的adj_list.lower，是当前net_device结构的下层net_device结构组成的链表
	//upper、lower指向的链表，其元素是netdev_adjacent结构，后者的list字段构成链表
	struct list_head list;
	
	struct rcu_head rcu;
};

//include/linux/netdevice.h：1247
//网络设备驱动程序实现下述回调函数
struct net_device_ops 
{
	/*
 	 *     This function is called once when a network device is registered.
 	 *     The network device can use this for any late stage initialization
 	 *     or semantic validation. It can fail with an error code which will
 	 *     be propagated back to register_netdev.
 	 */
 	//当网络设备被注册时，调用该函数
 	//当调用register_netdev()时，会调用此函数
	int			(*ndo_init)(struct net_device *dev);

	/*
 	 *     This function is called when device is unregistered or when registration
 	 *     fails. It is not called if init fails.
 	 */
 	//当网络设备注销或注册失败时被调用
	void		(*ndo_uninit)(struct net_device *dev);

	/*     This function is called when a network device transitions to the up
 	 *     state.
 	 */
 	//当网络设备被转变成UP状态时调用
 	//该函数内部通常需要初始化硬件寄存器并注册系统资源，如中断、DMA、IO端口（不一定，常在.probe()中完成）
 	/*
 	1、禁止所有中断、关闭载波（netif_carrier_off）；

	2、分配并初始化传输和接收描述符环内存（使用dma_alloc_coherent分配确保EMAC和CPU都可以访问）；

	3、分配发送skb处理状态的链表或者数组空间（使用kzalloc），其实也可以用sk_buff_head相关的数据结构和函数；

	4、初始化接收描述符环，包括分配struct sk_buff以及数据缓存区（netdev_alloc_skb），并且进行DMA映射（dma_map_single）；

	5、注册中断相关函数（request_irq）；

	6、初始化MAC硬件模块（设置MAC相关过滤参数、填写传输和接收描述符初始化地址dma_addr_t、中断设置、聚合功能配置）；

	7、PHY芯片初始化并启动；

	8、使能NAPI模块（napi_enable）；

	9、调用netif_start_queue或者netif_tx_start_all_queues使能传输队列调度；
	
	10、调用netif_wake_queue或者netif_tx_wake_all_queues开启传输队列的调度（因为此时所有的传输环为空，可以立刻开始传输）；

	11、使能传输/接收通道，打开中断，开启定时器功能；
 	*/
 	//dev_open()内部，调用此回调。在dev_open()调用完ndo_validate_addr()回调后，就调用ndo_open
 	//正确返回0
	int			(*ndo_open)(struct net_device *dev);

	/*     This function is called when a network device transitions to the down
  	 *     state.
  	 */
  	//当网络设备被转变成DOWN状态时调用
  	/*
  	1、停止上层传输调度；

	2、停止NAPI功能；

	3、停止MAC接收功能；

	4、等待既有的skb数据发出去，释放skb跟踪链表；

	5、停止发送功能；

	6、禁止中断功能；

	7、手动处理已接收到的数据包传递给上层协议；

	8、释放接受和发送描述符环内存空间；

	9、释放接收缓存数据空间；

	10、反注册中断函数；

	11、删除NAPI功能（netif_napi_del）；

	12、停止并删除timer功能、取消并删除delaywork；

	13、关闭载波netif_carrier_off；

	14、关闭MAC和PHY电源；
  	*/
	int			(*ndo_stop)(struct net_device *dev);


	/*	Called when a packet needs to be transmitted.
 	 *	Returns NETDEV_TX_OK.  Can return NETDEV_TX_BUSY, but you should stop
	 *	the queue before that can happen; it's for obsolete devices and weird
 	 *	corner cases, but the stack really does a non-trivial amount
 	 *	of useless work if you return NETDEV_TX_BUSY.
 	 *	Required; cannot be NULL.
 	 */
	//当发送数据包时被调用
	/*
	1、检查skb_shinfo(skb)->tx_flags标志位，SKBTX_HW_TSTAMP指示硬件向上层软件提供硬件时间戳（调用skb_tstamp_tx  、skb_tx_timestamp），设置过程中置位SKBTX_IN_PROGRESS，表示硬件正在处理上层的时间戳提取要求；

	2、根据ip_summed查看是否需要协助计算校验和，需要csum_start和csum_offset；

	3、是否需要VLAN标签插入，需要vlan_proto和vlan_tci；

	4、queue_mapping指示该SKB需要插入到哪个传输队列上；

	5、根据nr_frags检查是否需要发送碎片包，此时需要初始化nr_frags数量的传输描述符；

	6、检查skb->encapsulation，确定是否需要使用内层协议头；

	7、检查skb_shinfo(skb)->gso_size是否需要硬件进行分片操作；

	7、映射DMA操作需要的地址，填入传输描述符中；
	
	8、更新传输描述环相关状态；

	9、记录该等待传输的SKB到链表中；

	10、如果传输环空间不够应停止上层继续调度，也可以调用BQL机制（netdev_tx_sent_queue）实现自动调度控制；

	11、检查skb是否为jumbo帧，硬件是否支持直接发送；

	12、检查skb->no_fcs确定是否硬件需要在帧尾部加上FCS；
	*/
	//当发送帧dev_queue_xmit()时被调用
	netdev_tx_t	(*ndo_start_xmit)(struct sk_buff *skb, struct net_device *dev);


	/*	Called by core transmit path to determine if device is capable of
 	 *	performing offload operations on a given packet. This is to give
 	 *	the device an opportunity to implement any restrictions that cannot
 	 *	be otherwise expressed by feature flags. The check is called with
 	 *	the set of features that the stack has calculated and it returns
 	 *	those the driver believes to be appropriate.
 	 */
 	//用于确定一个网络设备是否有能力在指定的数据包上执行offload操作
 	//并且会返回NIC所能支持的feature
 	//该函数在核心传输路径上调用dev_queue_xmit()发送帧时会被调用
	netdev_features_t	(*ndo_features_check)(struct sk_buff *skb,
						      struct net_device *dev,
						      netdev_features_t features);

	/*  Called to decide which queue to use when device supports multiple
	 *  transmit queues.
	 */
	//若网络设备支持多个发送队列（即net_device结构_tx数组包含多个元素），
	//当调用dev_queue_xmit发送帧时，会调用该回调函数以确定使用哪个队列
	//若没有提供回调，则默认使用netdev_pick_tx函数，前提是net_device结构有多个发送队列
	u16			(*ndo_select_queue)(struct net_device *dev,
						    struct sk_buff *skb,
						    struct net_device *sb_dev);

	/*	This function is called to allow device receiver to make
 	 *	changes to configuration when multicast or promiscuous is enabled.
 	 */
 	//当启用多播或混杂模式时，网络设备接收者调用该函数对配置进行修改 
 	/*
 	通知驱动程序netdev->flags标记（IFF_PROMISC、IFF_ALLMULTI、IFF_MULTICAST）已变更，由于上层协议栈对于ndo_change_rx_flags和ndo_set_rx_mode的调用并不同意，硬件的相应设置变更被放到ndo_set_rx_mode实现；
 	*/
	void		(*ndo_change_rx_flags)(struct net_device *dev, int flags);

	/*	This function is called device changes address list filtering.
 	 *	If driver handles unicast address filtering, it should set
 	 *	IFF_UNICAST_FLT in its priv_flags.
 	 */
 	/*
 	1、根据netdev->flags标记（IFF_PROMISC、IFF_ALLMULTI、IFF_MULTICAST），设置硬件混杂模式、单播模式、多播模式使能；

	2、根据dev->uc设置硬件的单播地址列表，辅助函数netdev_for_each_uc_addr；

	3、根据dev->mc设置硬件的多播地址列表，辅助函数netdev_for_each_mc_addr；

	4、设置驱动私有的接收工作模式；
 	*/
 	//dev_open()调用完ndo_open()后，会调用此回调
	void		(*ndo_set_rx_mode)(struct net_device *dev);

	/*	This function  is called when the Media Access Control address
	 *	needs to be changed. If this interface is not defined, the
 	 *	MAC address can not be changed.
	 */
	//设置网卡的MAC地址，更新dev->dev_addr，并设置相应硬件寄存器；传递参数为struct sockaddr
	int			(*ndo_set_mac_address)(struct net_device *dev, void *addr);

	//Test if Media Access Control address is valid for the device.
	//验证dev->dev_addr是否合法，对于ethernet网络，一般设置成eth_validate_addr()函数
	//dev_open()内部，调用此回调。不过是在dev_open()调用.ndo_open回调之前调用
	//合法地址该回调返回0，否则返回-EADDRNOTAVAIL
	int			(*ndo_validate_addr)(struct net_device *dev);

	/*	Called when a user requests an ioctl which can't be handled by
	 *	the generic interface code. If not defined ioctls return
	 *	not supported error code.
	 */
	//该函数将特定io控制命令发送给网络设备
	/*
	1、bond_dev设备相关的命令，驱动不理会；

	2、PHY芯片的命令操作，直接使用generic_mii_ioctl函数phy_mii_ioctl函数；

	3、net_bridge设备命令，驱动不理会；

	4、PTP命令，驱动从ifr->ifr_data取出struct hwtstamp_config，根据其参数配置硬件的PTP时间戳功能；备注：config.flags必须为0，config.tx_type为HWTSTAMP_TX_OFF系列，config.rx_filter为HWTSTAMP_FILTER_NONE系列；

	5、SIOCWANDEV命令，针对WLAN设备的。。。
	*/
	int			(*ndo_do_ioctl)(struct net_device *dev, struct ifreq *ifr, int cmd);

	/ *	Used to set network devices bus interface parameters. This interface
	 *	is retained for legacy reasons; new devices should use the bus
	 *	interface (PCI) for low level management.
	 */
	int			(*ndo_set_config)(struct net_device *dev, struct ifmap *map);

	//Called when a user wants to change the Maximum Transfer Unit of a device.
	//大多数网卡设备的实现都大同小异，因此内核提供了通用实现eth_change_mtu
	//一般来说，也都使用该通用实现。但目前不赞成使用该函数
	int			(*ndo_change_mtu)(struct net_device *dev, int new_mtu);

	//设置邻居子系统struct neigh_parms参数
	int			(*ndo_neigh_setup)(struct net_device *dev, struct neigh_parms *);

	//Callback used when the transmitter has not made any progress for dev->watchdog ticks.
	//传输失败（超时）时调用此函数
	/*
	1、保存现场快照；

	2、关闭MAC和PHY；

	3、复位并重新初始化MAC和PHY
	*/
	//net_device结构的watchdog_timer超时时，dev_watchdog()内部函数会调用该回调函数
	void		(*ndo_tx_timeout) (struct net_device *dev);

	/*	Called when a user wants to get the network device usage
	 *	statistics. Drivers must do one of the following:
	 *	1. Define @ndo_get_stats64 to fill in a zero-initialised
	 *	   rtnl_link_stats64 structure passed by the caller.
	 *	2. Define @ndo_get_stats to update a net_device_stats structure
	 *	   (which should normally be dev->stats) and return a pointer to
	 *	   it. The structure may be changed asynchronously only if each
	 *	   field is written atomically.
	 *	3. Update dev->stats asynchronously and atomically, and define
	 *	   neither operation.
	 */
	//用户调用此函数以查询网络设备使用统计数据
	//拷贝硬件统计计数到用户空间，注意使用的是__u64；对于1G或者更快的网卡，64位是必须的；
	void		(*ndo_get_stats64)(struct net_device *dev, struct rtnl_link_stats64 *storage);

	//Return true if this device supports offload stats of this attr_id.
	bool		(*ndo_has_offload_stats)(const struct net_device *dev, int attr_id);

	//Get statistics for offload operations by attr_id. Write it into the attr_data pointer.
	int			(*ndo_get_offload_stats)(int attr_id,
							 const struct net_device *dev,
							 void *attr_data);

	/*	Called when a user wants to get the network device usage
	 *	statistics. Drivers must do one of the following:
	 *	1. Define @ndo_get_stats64 to fill in a zero-initialised
	 *	   rtnl_link_stats64 structure passed by the caller.
	 *	2. Define @ndo_get_stats to update a net_device_stats structure
	 *	   (which should normally be dev->stats) and return a pointer to
	 *	   it. The structure may be changed asynchronously only if each
	 *	   field is written atomically.
	 *	3. Update dev->stats asynchronously and atomically, and define
	 *	   neither operation.
	 */
	//拷贝硬件统计计数到用户空间，注意使用的是__u32；可以直接拷贝netdev->stats；低速网卡使用此方法；
	struct net_device_stats* (*ndo_get_stats)(struct net_device *dev);

	//If device supports VLAN filtering this function is called when a VLAN id is registered.
	//如果网卡支持VLAN的VID过滤，则增加VID到过滤列表中；
	int			(*ndo_vlan_rx_add_vid)(struct net_device *dev, __be16 proto, u16 vid);

	//If device supports VLAN filtering this function is called when a VLAN id is unregistered.
	//如果网卡支持VLAN的VID过滤，则从过滤列表中删除对应的VID；
	int			(*ndo_vlan_rx_kill_vid)(struct net_device *dev, __be16 proto, u16 vid);

	//使用查询方式代替中断方式处理网卡数据包收发事件
	//注意必须禁止中断，实际上直接调用中断函数，也可以直接调度NAPI去处理
	void        (*ndo_poll_controller)(struct net_device *dev);

	//只有虚拟网络设备在使用
	int			(*ndo_netpoll_setup)(struct net_device *dev, struct netpoll_info *info);
	void		(*ndo_netpoll_cleanup)(struct net_device *dev);

	//设置虚拟网卡的MAC地址，第二个参数是VF，第三个参数是需要设置的MAC地址指针
	int			(*ndo_set_vf_mac)(struct net_device *dev, int queue, u8 *mac);

	//设置虚拟网卡的VLAN ID和User Priority，第二个参数代表虚拟功能号，第三个参数代表VLAN ID（1-4094），第四个参数代表User Priority（0-7）
	int			(*ndo_set_vf_vlan)(struct net_device *dev,
						   int queue, u16 vlan,
						   u8 qos, __be16 proto);

	//设置虚拟网卡的传输速率，由于多个虚拟网卡共享一个物理端口，所以单个虚拟网卡的传输速率肯定小于标准值；						   
	int			(*ndo_set_vf_rate)(struct net_device *dev,
						   int vf, int min_tx_rate,
						   int max_tx_rate);

	//设置虚拟网卡的MAC/VLAN反欺诈过滤功能（传输通道）
	int			(*ndo_set_vf_spoofchk)(struct net_device *dev,
						       int vf, bool setting);
	
	int			(*ndo_set_vf_trust)(struct net_device *dev,
						    int vf, bool setting);

	//获取虚拟网卡的参数，包括虚拟功能号、mac地址、传输速率、优先级Qos、欺诈使能标记，填入struct ifla_vf_info
	int			(*ndo_get_vf_config)(struct net_device *dev,
						     int vf,
						     struct ifla_vf_info *ivf);
	
	int			(*ndo_set_vf_link_state)(struct net_device *dev,
							 int vf, int link_state);
	
	int			(*ndo_get_vf_stats)(struct net_device *dev,
						    int vf,
						    struct ifla_vf_stats
						    *vf_stats);
	
	//设置虚拟网卡的参数：可能包括IFLA_PORT_UNSPEC至IFLA_PORT_RESPONSE；当前只有cisco的enic驱动支持
	int			(*ndo_set_vf_port)(struct net_device *dev,
						   int vf,
						   struct nlattr *port[]);

	//返回虚拟网卡的参数，放到传递的第三个参数（skb），可以调用辅助函数nla_put；当前只有cisco的enic驱动支持						
	int			(*ndo_get_vf_port)(struct net_device *dev,
						   int vf, struct sk_buff *skb);
	
	int			(*ndo_set_vf_guid)(struct net_device *dev,
						   int vf, u64 guid,
						   int guid_type);
	
	int			(*ndo_set_vf_rss_query_en)(
						   struct net_device *dev,
						   int vf, bool setting);

	//设置网卡的流量分类控制，
	//如果第二个参数为0 ，则调用netdev_reset_tc关闭流量分类控制功能，相应的禁止硬件功能；
	//如果第二个参数不为0 ，则设置netdev_set_num_tc和netdev_set_prio_tc_map
	int			(*ndo_setup_tc)(struct net_device *dev,
						enum tc_setup_type type,
						void *type_data);
	
#if IS_ENABLED(CONFIG_FCOE)
	//打开FCOE的卸货功能（offload），更新netdev->features，调用netdev_features_change，重新分配初始化传输接收环；
	int			(*ndo_fcoe_enable)(struct net_device *dev);

	//关闭FCOE的卸货功能（offload），更新netdev->features，调用netdev_features_change，重新分配初始化传输接收环；
	int			(*ndo_fcoe_disable)(struct net_device *dev);
	
	int			(*ndo_fcoe_ddp_setup)(struct net_device *dev,
						      u16 xid,
						      struct scatterlist *sgl,
						      unsigned int sgc);
	int			(*ndo_fcoe_ddp_done)(struct net_device *dev,
						     u16 xid);
	int			(*ndo_fcoe_ddp_target)(struct net_device *dev,
						       u16 xid,
						       struct scatterlist *sgl,
						       unsigned int sgc);
	int			(*ndo_fcoe_get_hbainfo)(struct net_device *dev,
							struct netdev_fcoe_hbainfo *hbainfo);
#endif

#if IS_ENABLED(CONFIG_LIBFCOE)
#define NETDEV_FCOE_WWNN 0
#define NETDEV_FCOE_WWPN 1
	int			(*ndo_fcoe_get_wwn)(struct net_device *dev,
						    u64 *wwn, int type);
#endif

#ifdef CONFIG_RFS_ACCEL
	//设置RFS硬件过滤器，关于RFS参考《Receive flow steering》；
	int			(*ndo_rx_flow_steer)(struct net_device *dev,
						     const struct sk_buff *skb,
						     u16 rxq_index,
						     u32 flow_id);
#endif
	//创建虚拟网卡设备
	int			(*ndo_add_slave)(struct net_device *dev,
						 struct net_device *slave_dev,
						 struct netlink_ext_ack *extack);

	//删除虚拟网卡设备
	int			(*ndo_del_slave)(struct net_device *dev,
						 struct net_device *slave_dev);

	//检查并修正传递的netdev_features_t features是否满足硬件能力要求
	//register_netdev()中会调用，
	//		features = (dev->features & ~dev->hw_features) | dev->wanted_features;
	//		该函数返回的features，会影响dev->features
	netdev_features_t	(*ndo_fix_features)(struct net_device *dev, netdev_features_t features);

	//更改网卡的netdev->features并设置硬件的相应能力；
	//在register_netdev()中会调用该回调函数
	//在register_netdev()中，可能会调整features（局部变量），通过该回调函数通知驱动程序
	int			(*ndo_set_features)(struct net_device *dev, netdev_features_t features);

	//构造邻居子系统struct neighbour
	int			(*ndo_neigh_construct)(struct net_device *dev,
						       struct neighbour *n);

	//反构造邻居子系统struct neighbour
	void			(*ndo_neigh_destroy)(struct net_device *dev,
						     struct neighbour *n);

	//给指定地址添加FDB（forwarding database）实体
	int			(*ndo_fdb_add)(struct ndmsg *ndm,
					       struct nlattr *tb[],
					       struct net_device *dev,
					       const unsigned char *addr,
					       u16 vid,
					       u16 flags,
					       struct netlink_ext_ack *extack);

	//给指定地址删除FDB（forwarding database）实体；
	int			(*ndo_fdb_del)(struct ndmsg *ndm,
					       struct nlattr *tb[],
					       struct net_device *dev,
					       const unsigned char *addr,
					       u16 vid);
	
	//导出FDB实体到skb中，同时更新idx，辅助函数包括netif_addr_lock_bh、nlmsg_populate_fdb
	int			(*ndo_fdb_dump)(struct sk_buff *skb,
						struct netlink_callback *cb,
						struct net_device *dev,
						struct net_device *filter_dev,
						int *idx);
	int			(*ndo_fdb_get)(struct sk_buff *skb,
					       struct nlattr *tb[],
					       struct net_device *dev,
					       const unsigned char *addr,
					       u16 vid, u32 portid, u32 seq,
					       struct netlink_ext_ack *extack);

	//设置网卡链路信息，从struct nlmsghdr获取设置信息
	int			(*ndo_bridge_setlink)(struct net_device *dev,
						      struct nlmsghdr *nlh,
						      u16 flags,
						      struct netlink_ext_ack *extack);

	//返回网卡链路信息，填入skb中
	int			(*ndo_bridge_getlink)(struct sk_buff *skb,
						      u32 pid, u32 seq,
						      struct net_device *dev,
						      u32 filter_mask,
						      int nlflags);

	//删除网卡链路信息
	int			(*ndo_bridge_dellink)(struct net_device *dev,
						      struct nlmsghdr *nlh,
						      u16 flags);

	//虚拟网络设备使用，模拟网络载波的开关；
	int			(*ndo_change_carrier)(struct net_device *dev,
						      bool new_carrier);
	int			(*ndo_get_phys_port_id)(struct net_device *dev,
							struct netdev_phys_item_id *ppid);
	int			(*ndo_get_port_parent_id)(struct net_device *dev,
							  struct netdev_phys_item_id *ppid);
	int			(*ndo_get_phys_port_name)(struct net_device *dev,
							  char *name, size_t len);


	//若设置了该回调函数，
	//		net_device结构的features |= NETIF_F_RX_UDP_TUNNEL_PORT
	//		net_device结构的hw_features |= NETIF_F_RX_UDP_TUNNEL_PORT;
	void			(*ndo_udp_tunnel_add)(struct net_device *dev,
						      struct udp_tunnel_info *ti);
	void			(*ndo_udp_tunnel_del)(struct net_device *dev,
						      struct udp_tunnel_info *ti);
	void*			(*ndo_dfwd_add_station)(struct net_device *pdev,
							struct net_device *dev);
	void			(*ndo_dfwd_del_station)(struct net_device *pdev,
							void *priv);

	int			(*ndo_set_tx_maxrate)(struct net_device *dev,
						      int queue_index,
						      u32 maxrate);

	//NIC驱动程序可以定义自己管理的NIC的interface index，即ifindex
	//该函数返回该值
	int			(*ndo_get_iflink)(const struct net_device *dev);
	
	int			(*ndo_change_proto_down)(struct net_device *dev,
							 bool proto_down);
	int			(*ndo_fill_metadata_dst)(struct net_device *dev,
						       struct sk_buff *skb);
	void			(*ndo_set_rx_headroom)(struct net_device *dev,
						       int needed_headroom);
	int			(*ndo_bpf)(struct net_device *dev,
					   struct netdev_bpf *bpf);
	int			(*ndo_xdp_xmit)(struct net_device *dev, int n,
						struct xdp_frame **xdp,
						u32 flags);
	int			(*ndo_xsk_wakeup)(struct net_device *dev,
						  u32 queue_id, u32 flags);
	struct devlink_port *	(*ndo_get_devlink_port)(struct net_device *dev);
};

//include/linux/netdevice.h：263
//主要用于第二层头部的处理，一般由驱动提供回调函数实现
struct header_ops 
{
	//创建新的硬件首部
	//目前，一般设置为内核提供的实现eth_header函数
	int	(*create) (struct sk_buff *skb, struct net_device *dev,
			   unsigned short type, const void *daddr,
			   const void *saddr, unsigned int len);

	//解析一个给定的硬件首部
	//一般设置为内核提供的实现eth_header_parse()
	int	(*parse)(const struct sk_buff *skb, unsigned char *haddr);
	
	int	(*cache)(const struct neighbour *neigh, struct hh_cache *hh, __be16 type);
	
	void 	(*cache_update)(struct hh_cache *hh,
				const struct net_device *dev,
				const unsigned char *haddr);
	
	bool	(*validate)(const char *ll_header, unsigned int len);
	
	__be16	(*parse_protocol)(const struct sk_buff *skb);
};

//include/linux/netdevice.h：589
/*
 * __QUEUE_STATE_DRV_XOFF is used by drivers to stop the transmit queue.  The
 * netif_tx_* functions below are used to manipulate this flag.  The
 * __QUEUE_STATE_STACK_XOFF flag is used by the stack to stop the transmit
 * queue independently.  The netif_xmit_*stopped functions below are called
 * to check if the queue has been stopped by the driver or stack (either
 * of the XOFF bits are set in the state).  Drivers should not need to call
 * netif_xmit*stopped functions, they should only be using netif_tx_*.
 */
struct netdev_queue 
{
/*
 * read-mostly part
 */
	struct net_device	*dev;
	struct Qdisc __rcu	*qdisc;
	struct Qdisc		*qdisc_sleeping;
#ifdef CONFIG_SYSFS
	struct kobject		kobj;
#endif
#if defined(CONFIG_XPS) && defined(CONFIG_NUMA)
	int			numa_node;
#endif
	unsigned long		tx_maxrate;
	/*
	 * Number of TX timeouts for this queue
	 * (/sys/class/net/DEV/Q/trans_timeout)
	 */
	//若网络设备已经停止，且自最近一次发送帧以来已经超过了设定的超时值net_device.watchdog_timeo
	//该计数器会++
	unsigned long		trans_timeout;

	/* Subordinate device that the queue has been assigned to */
	struct net_device	*sb_dev;
#ifdef CONFIG_XDP_SOCKETS
	struct xdp_umem         *umem;
#endif
/*
 * write-mostly part
 */
 	//使得每个CPU一次只能对任何给定的一个设备做一次传输
	spinlock_t		_xmit_lock;// ____cacheline_aligned_in_smp;

	//持有_xmit_lock锁的cpu的ID。初始时，即没有获取锁时，为-1
	int			xmit_lock_owner;
	
	/*
	 * Time (in jiffies) of last Tx
	 */
	//最近的一个帧传输启动的时间（以jiffies测量），即调用驱动程序提供的ndo_start_xmit回调后，读取jiffies
	//内核使用定时器net_device.watchdog_timer，周期性地基于该字段进行检测：
	//			若网络设备已经停止，且自最近一次发送帧以来已经超过了设定的超时值net_device.watchdog_timeo
	//			则会调用回调函数net_device.netdev_ops->ndo_tx_timeout
	//			一般而言，驱动通常采取的措施就是复位适配卡
	unsigned long		trans_start;

	//位0（__QUEUE_STATE_DRV_XOFF）：在pcnet32_open()中，会清除该位，表明可以使用网卡发送数据
	//								因网卡发送缓冲不够时，会设置该标志
	//位1（__QUEUE_STATE_STACK_XOFF）
	//位2（__QUEUE_STATE_FROZEN）
	unsigned long		state;

	struct dql		dql;
} ____cacheline_aligned_in_smp;

/* similar to sk_buff_head, but skb->prev pointer is undefined. */
struct qdisc_skb_head 
{
	struct sk_buff	*head;
	struct sk_buff	*tail;
	__u32		qlen;
	spinlock_t	lock;
};

//网络设备层队列排队规则
struct Qdisc 
{
	//调用dev_queue_xmit()发送帧时，以下两个条件之一不满足就会调用enqueue回调函数
	//		flags字段没有设置TCQ_F_CAN_BYPASS位
	//		empty=false，即当前Qdisc结构中没有待发送的skb
	//在pfifo的实现中，对应的实现是pfifo_fast_enqueue函数。它根据待发送的skb的priority字段，选择一个发送频道，即skb_arry，然后将skb，放入该skb_array环形缓冲区中
	//
	// qdisc ->enqueue() return codes
#define NET_XMIT_SUCCESS	0x00
#define NET_XMIT_DROP		0x01	/* skb dropped			*/
#define NET_XMIT_CN			0x02	/* congestion notification	*/
#define NET_XMIT_MASK		0x0f	/* qdisc flags in net/sch_generic.h */
	int 			(*enqueue)(struct sk_buff *skb,
					   struct Qdisc *sch,
					   struct sk_buff **to_free);
	
	struct sk_buff *	(*dequeue)(struct Qdisc *sch);
	
	unsigned int		flags;
#define TCQ_F_BUILTIN		1
#define TCQ_F_INGRESS		2
#define TCQ_F_CAN_BYPASS	4
#define TCQ_F_MQROOT		8
#define TCQ_F_ONETXQUEUE	0x10 /* dequeue_skb() can assume all skbs are for
				      * q->dev_queue : It can test
				      * netif_xmit_frozen_or_stopped() before
				      * dequeueing next packet.
				      * Its true for MQ/MQPRIO slaves, or non
				      * multiqueue device.
				      */
#define TCQ_F_WARN_NONWC	(1 << 16)

//表明使用per cpu的统计信息 
//即使用cpu_qstats字段，而非qstats字段
#define TCQ_F_CPUSTATS		0x20

#define TCQ_F_NOPARENT		0x40 /* root of its hierarchy :
				      * qdisc_tree_decrease_qlen() should stop.
				      */
#define TCQ_F_INVISIBLE		0x80 /* invisible by default in dump */
#define TCQ_F_NOLOCK		0x100 /* qdisc does not require locking */
#define TCQ_F_OFFLOADED		0x200 /* qdisc is offloaded to HW */
	u32			limit;
	const struct Qdisc_ops	*ops;
	struct qdisc_size_table	__rcu *stab;
	struct hlist_node       hash;
	u32			handle;
	u32			parent;

	struct netdev_queue	*dev_queue;

	struct net_rate_estimator __rcu *rate_est;
	struct gnet_stats_basic_cpu __percpu *cpu_bstats;
	struct gnet_stats_queue	__percpu *cpu_qstats;
	int			padded;
	refcount_t		refcnt;

	/*
	 * For performance sake on SMP, we put highly modified fields at the end
	 */
	//当dev_queue_xmit()发送帧时，若检测到网卡已经停止发送数据，则将还未发送的若干skb链入到该字段
	struct sk_buff_head	gso_skb;// ____cacheline_aligned_in_smp;

	//当要从gso_skb链表中取出skb时，需要加锁q.lock
	struct qdisc_skb_head	q;
	
	struct gnet_stats_basic_packed bstats;

	//qdisc_run_begin()和qdisc_run_end()中，对其sequence字段++
	seqcount_t		running;
	
	struct gnet_stats_queue	qstats;

	//当使用软中断NET_TX_SOFTIRQ发送帧前，需要设置__QDISC_STATE_SCHED标志
	//若已经设置了__QDISC_STATE_SCHED标志，就不会重复将Qdisc结构加入softnet_data.output_queue链表中，也不会重复触发软中断
	//当使用dev_open()打开网络设备时，会清除__QDISC_STATE_DEACTIVATED标志
	unsigned long		state;

	//当dev_queue_xmit()向驱动发送帧时，驱动程序返回NETDEV_TX_BUSY，说明其内部发送队列已满
	//此时将发送帧使用的Qdisc结构，比如常常是net_device._tx[0].qdisc，加入到当前cpu的softnet_data.output_queue链表尾部
	//而softnet_data.output_queue_tailp则保存了next_sched字段的地址，代表链表尾部
	//即next_sched构成了当前cpu的softnet_data.output_queue链表节点指针
	struct Qdisc            *next_sched;
	
	struct sk_buff_head	skb_bad_txq;

	spinlock_t		busylock;// ____cacheline_aligned_in_smp;

	//qdisc_run_begin()中加锁
	//qdisc_run_end()中解锁
	spinlock_t		seqlock;

	/* for NOLOCK qdisc, true if there are no enqueued skbs */
	//当前Qdisc结构中没有待发送的skb
	//比如对于pfifo入队规则而言，
	//当pfifo私有结构pfifo_fast_priv（包含skb_arry q[3]数组）中，并无要发送的skb，该字段设为true
	bool				empty;
	
	struct rcu_head		rcu;
};

//include/uapi/linux/gen_stats.h:62
/**
 * struct gnet_stats_queue - queuing statistics
 */
struct gnet_stats_queue 
{
	//当dev_queue_xmit()发送帧时，若检测到网卡已经停止发送数据，则将还未发送的若干skb链入到Qdisc.gso_skb中
	//每放入1个skb，该字段增加1
	//类似的情况，也跟踪放入pfifo_fast_ops规则私有数据部分skb_arry环形缓冲中的skb
	//从上述链表或环形缓冲中取skb时，即进行反向操作
	__u32	qlen;			//queue length

	//当dev_queue_xmit()发送帧时，若检测到网卡已经停止发送数据，则将还未发送的若干skb链入到Qdisc.gso_skb中
	//每放入1个skb，该字段增加当前skb的.(struct qdisc_skb_cb *)cb->pkt_len，即要发送的帧长度
	//类似的情况，也跟踪放入pfifo_fast_ops规则私有数据部分skb_arry环形缓冲中的skb
	//从上述链表或环形缓冲中取skb时，即进行反向操作
	__u32	backlog;		//backlog size of queue
	
	__u32	drops;			//number of dropped packets

	//当dev_queue_xmit()发送帧时，若检测到网卡已经停止发送数据，则将还未发送的若干skb链入到Qdisc.gso_skb中
	//每放入1个skb，该字段增加1
	__u32	requeues;		//number of requeues
	
	__u32	overlimits;		//number of enqueues over the limit
};

//include/linux/netdevice.h：736
/* This structure contains an instance of an RX queue. */
struct netdev_rx_queue 
{
	struct rps_map __rcu			*rps_map;
	struct rps_dev_flow_table __rcu	*rps_flow_table;
	struct kobject					kobj;
	struct net_device				*dev;
	struct xdp_rxq_info				xdp_rxq;
	struct xdp_umem                 *umem;
} ____cacheline_aligned_in_smp;

//include/linux/inetdevice.h：25
struct in_device 
{
	struct net_device	*dev;
	refcount_t			refcnt;
	int					dead;	//是否正在销毁
	
	struct in_ifaddr	__rcu 	*ifa_list;	//ip地址信息链表，其ifa_next字段构成链表

	struct ip_mc_list __rcu		*mc_list;	/* IP multicast filter chain    */
	struct ip_mc_list __rcu	* __rcu *mc_hash;

	//多播地址数目
	int					mc_count;	/* Number of installed mcasts	*/
	
	spinlock_t			mc_tomb_lock;
	struct ip_mc_list	*mc_tomb;
	unsigned long		mr_v1_seen;
	unsigned long		mr_v2_seen;
	unsigned long		mr_maxdelay;
	unsigned long		mr_qi;		/* Query Interval */
	unsigned long		mr_qri;		/* Query Response Interval */
	unsigned char		mr_qrv;		/* Query Robustness Variable */
	unsigned char		mr_gq_running;
	unsigned char		mr_ifc_count;
	struct timer_list	mr_gq_timer;	/* general query timer */
	struct timer_list	mr_ifc_timer;	/* interface change timer */

	//arp参数
	struct neigh_parms	*arp_parms;

	///proc/sys/net/ipv4/conf中的配置信息相对应
	struct ipv4_devconf	cnf;
	
	struct rcu_head		rcu_head;
};

//include/linux/inetdevice.h：137
struct in_ifaddr 
{
	struct hlist_node	hash;				//通过该字段将in_ifaddr结构，放入了哈希表inet_addr_lst的某个冲突链表中
	struct in_ifaddr	__rcu *ifa_next;	//构成in_device结构ifa_list链表
	struct in_device	*ifa_dev;			//回指其归属的in_device结构
	struct rcu_head		rcu_head;

	//ifa_local和ifa_address都用来存储ip地址
	//？？？？ifa_local实际上是加入哈希表inet_addr_lst时，计算key所用的IP地址
	//但在不同设备接口意义不同
	//	在配置了广播的设备上，都表示本地ip地址
	//	在点对点设备上，ifa_address存储的是对端ip地址，ifa_local存储的是本地ip地址
	__be32				ifa_local;
	
	__be32				ifa_address;
	
	__be32				ifa_mask;		//子网掩码
	__u32				ifa_rt_priority;
	__be32				ifa_broadcast;	//广播地址

	//地址范围，值越小表示的范围越大
	//RT_SCOPE_UNIVERSE-在任何地方使用
	//RT_SCOPE_SITE-本地封闭系统的内部路由
	//RT_SCOPE_LINK-局域网内使用，如广播地址
	//RT_SCOPE_HOST-主机内部通信，如回环地址
	//RT_SCOPE_NOWHERE-目的地址不存在
	unsigned char		ifa_scope;

	//子网掩码长度
	unsigned char		ifa_prefixlen;

	//地址属性标记 
	//IFA_F_SECONDARY-从属ip地址
	//IFA_F_NODAD-禁止重复地址检测,ipv6使用
	//IFA_F_HOMEADDRESS-移动ipv6家乡地址，ipv6使用
	//IFA_F_DEPRECATED-此ip地址不鼓励使用，也不禁止
	//IFA_F_TENTATIVE-尝试阶段的ip地址，仍在进行地址检测工作
	//IFA_F_PERMANENT-永久性地址，无此标识，则会动态配置ip地址
	__u32				ifa_flags;

	//地址标签，通常是网络设备名或者网络设备别名
	char				ifa_label[IFNAMSIZ];

	/* In seconds, relative to tstamp. Expiry is at tstamp + HZ * lft. */
	//生命周期
	__u32				ifa_valid_lft;
	__u32				ifa_preferred_lft;
	
	unsigned long		ifa_cstamp; /* created timestamp */
	unsigned long		ifa_tstamp; /* updated timestamp */
};

//net/core/dev.c:187
/*
 * The @dev_base_head list is protected by @dev_base_lock and the rtnl
 * semaphore.
 *
 * Pure readers hold dev_base_lock for reading, or rcu_read_lock()
 *
 * Writers must hold the rtnl semaphore while they loop through the
 * dev_base_head list, and hold dev_base_lock for writing when they do the
 * actual updates.  This allows pure readers to access the list even
 * while a writer is preparing to update it.
 *
 * To put it another way, dev_base_lock is held for writing only to
 * protect against pure readers; the rtnl semaphore provides the
 * protection against other writers.
 *
 * See, for example usages, register_netdevice() and
 * unregister_netdevice(), which must be called with the rtnl
 * semaphore held.
 */
//保护net_device结构的dev_base_head链表、dev_name_head哈希表、index_hlist哈希表
DEFINE_RWLOCK(dev_base_lock);
EXPORT_SYMBOL(dev_base_lock);

//include/linux/netdevice.h：201
struct netdev_hw_addr 
{
	struct list_head	list;
	unsigned char		addr[MAX_ADDR_LEN];
	unsigned char		type;
#define NETDEV_HW_ADDR_T_LAN		1
#define NETDEV_HW_ADDR_T_SAN		2
#define NETDEV_HW_ADDR_T_SLAVE		3
#define NETDEV_HW_ADDR_T_UNICAST	4
#define NETDEV_HW_ADDR_T_MULTICAST	5
	bool				global_use;
	int					sync_cnt;
	int					refcount;
	int					synced;
	struct rcu_head		rcu_head;
};

#endif

#if 1 //net_device的管理函数

#if 1 //netdev_priv()：获得net_device关联的私有数据区域地址

//include/linux/netdevice.h：2184
/**
 *	netdev_priv - access network device private data
 *	@dev: network device
 *
 * Get network device private data
 */
//net_device结构之后，就是alloc_netdev_mqs()函数分配的驱动程序的私有数据
static inline void *netdev_priv(const struct net_device *dev)
{
	return (char *)dev + ALIGN(sizeof(struct net_device), NETDEV_ALIGN);
}

#endif

#if 1 //dev_net()：返回net_device结构所属的net结构指针

//include/linux/netdevice.h：2166
//返回net_device结构所属的net结构指针
static inline struct net *dev_net(const struct net_device *dev)
{
	//return dev->nd_net.net;
	return read_pnet(&dev->nd_net);
}

//include/net/net_namespace.h:317
static inline struct net *read_pnet(const possible_net_t *pnet)
{
	return pnet->net;
}

#endif

#if 1 //dev_get_by_name()：根据网络设备名称，如eth，查找net_device结构

//net/core/dev.c：703
/**
 *	dev_get_by_name		- find a device by its name
 *	@net: the applicable net namespace
 *	@name: name to find
 *
 *	Find an interface by name. This can be called from any
 *	context and does its own locking. The returned handle has
 *	the usage count incremented and the caller must use dev_put() to
 *	release it when it is no longer needed. %NULL is returned if no
 *	matching device is found.
 */
struct net_device *dev_get_by_name(struct net *net, const char *name)
{
	struct net_device *dev;

	rcu_read_lock();
	
	dev = dev_get_by_name_rcu(net, name);

	if (dev)
		dev_hold(dev);

	rcu_read_unlock();

	return dev;
}
EXPORT_SYMBOL(dev_get_by_name);

//net/core/dev.c：678
/**
 * dev_get_by_name_rcu	- find a device by its name
 * @net: the applicable net namespace
 * @name: name to find
 *
 * Find an interface by name.
 * If the name is found a pointer to the device is returned.
 * If the name is not found then %NULL is returned.
 * The reference counters are not incremented so the caller must be
 * careful with locks. The caller must hold RCU lock.
 */
struct net_device *dev_get_by_name_rcu(struct net *net, const char *name)
{
	struct net_device *dev;
	struct hlist_head *head = dev_name_hash(net, name);

	hlist_for_each_entry_rcu(dev, head, name_hlist)
		if (!strncmp(dev->name, name, IFNAMSIZ))
			return dev;

	return NULL;
}
EXPORT_SYMBOL(dev_get_by_name_rcu);

#endif

#if 1 //dev_get_by_index()：根据网络设备index，查找net_device结构

//net/core/dev.c:777
/**
 *	dev_get_by_index - find a device by its ifindex
 *	@net: the applicable net namespace
 *	@ifindex: index of device
 *
 *	Search for an interface by index. Returns NULL if the device
 *	is not found or a pointer to the device. The device returned has
 *	had a reference added and the pointer is safe until the user calls
 *	dev_put to indicate they have finished with it.
 */
struct net_device *dev_get_by_index(struct net *net, int ifindex)
{
	struct net_device *dev;

	rcu_read_lock();
	
	dev = dev_get_by_index_rcu(net, ifindex);
	if (dev)
		dev_hold(dev);
	
	rcu_read_unlock();

	return dev;
}
EXPORT_SYMBOL(dev_get_by_index);

//net/core/dev.c:752
/**
 *	dev_get_by_index_rcu - find a device by its ifindex
 *	@net: the applicable net namespace
 *	@ifindex: index of device
 *
 *	Search for an interface by index. Returns %NULL if the device
 *	is not found or a pointer to the device. The device has not
 *	had its reference counter increased so the caller must be careful
 *	about locking. The caller must hold RCU lock.
 */
struct net_device *dev_get_by_index_rcu(struct net *net, int ifindex)
{
	struct net_device *dev;
	struct hlist_head *head = dev_index_hash(net, ifindex);

	hlist_for_each_entry_rcu(dev, head, index_hlist)
		if (dev->ifindex == ifindex)
			return dev;

	return NULL;
}
EXPORT_SYMBOL(dev_get_by_index_rcu);

#endif

#endif

#if 1 //以以太网卡pcnet32驱动为例，说明net_device结构

void f()
{
	struct net_device *this; 

	//--------------------------
	//以下字段由alloc_etherdev()设置
	//--------------------------

	//alloc_netdev_mqs()根据驱动私有数据空间、net_device结构大小之和，32位对齐后，分配空间
	//得到的空间地址，32位对齐后，赋值给this指针
	//this指针与得到的空间地址之差，即padded字段
	this->padded =;	

	//分配一个per cpu空间，大小是int，用作per cpu的引用计数
	this->pcpu_refcnt = new int;

	//list of device hw addresses（如MAC地址）
	//初始化了该链表头，并加入第一个元素
	//元素类型是netdev_hw_addr结构，初始化的字段包括
	//	.addr数组清0
	//	.type = NETDEV_HW_ADDR_T_LAN
	//	.refcount = 1
	//	.global_use = false
	//	.synced = 0
	//	.sync_cnt = 0
	//	.list = 加入dev_addrs链表
	this->dev_addrs = ; //this->dev_addrs.count = 0, this->dev_addrs.list=初始化链表头

	//网络设备的硬件地址，比如以太网卡的MAC地址。Hw address (before bcast, because most packets are unicast)
	//实际上是.dev_addrs链表第一个元素，即netdev_hw_addr结构的addr数组地址
	this->dev_addr = this->dev_addrs.list.next->addr;

	//multicast mac addresses
	//初始化该链表头
	this->mc.list = ;
	this->mc.count = 0;

	//unicast mac addresses
	//初始化该链表头
	this->uc.list = ;
	this->uc.count = 0;

	//Network namespace this network device is inside
	this->nd_net = &init_net;

	//Maximum size of generic segmentation offload
	this->gso_max_size = GSO_MAX_SIZE;

	//Maximum number of segments that can be passed to the NIC for GSO
	this->gso_max_segs = GSO_MAX_SEGS;

	//Maximum depth level of upper devices.	
	this->upper_level = 1;

	//Maximum depth level of lower devices.
	this->lower_level = 1;

	//List entry used for polling NAPI devices
	INIT_LIST_HEAD(this->napi_list);

	//List entry  when we are unregistering the device; see the function unregister_netdev	
	INIT_LIST_HEAD(this->unreg_list);

	//List entry used when we are closing the device
	INIT_LIST_HEAD(this->close_list);
	
	INIT_LIST_HEAD(this->link_watch_list);

	//Directly linked devices, like slaves for bonding	
	INIT_LIST_HEAD(this->adj_list.upper);
	INIT_LIST_HEAD(this->adj_list.lower);

	//Device-specific packet handlers for all protocols
	INIT_LIST_HEAD(this->ptype_all);

	//Device-specific, protocol-specific packet handlers	
	INIT_LIST_HEAD(this->ptype_specific);

	//对哈希表qdisc_hash初始化，每个槽都清0
	this->qdisc_hash =;

	//this->priv_flags = IFF_XMIT_DST_RELEASE | IFF_XMIT_DST_RELEASE_PERM;

	//--------------------------
	//以下字段为ether_setup()设置
	//--------------------------

	//主要用于第二层头部的处理，一般由驱动提供回调函数实现	
	this->header_ops		= &eth_header_ops;

	//网络设备的硬件类型。Interface hardware type											
	//ARPHRD_ETHER，表示Ethernet 10Mbps
	this->type				= ARPHRD_ETHER; //1

	//Maximum hardware header length.
	//alloc_etherdev()中被设为ETH_HLEN=14，即MAC头部大小
	this->hard_header_len 	= ETH_HLEN;		//14

	//Minimum hardware header length
	this->min_header_len	= ETH_HLEN;		//14

	//Interface MTU（maximum transfer unit） value
	this->mtu				= ETH_DATA_LEN;	//1500

	//Interface Minimum MTU value
	this->min_mtu			= ETH_MIN_MTU;	//68

	//Interface Maximum MTU value
	this->max_mtu			= ETH_DATA_LEN; //1500

	//dev_addr字段代表的Hardware address length，比如MAC地址长度	
	this->addr_len			= ETH_ALEN;		//6

	//Max frames per queue allowed
	//网络设备的传送队列长度(1000个封包)
	this->tx_queue_len		= DEFAULT_TX_QUEUE_LEN;		//1000

	//接口标志（按BSD方式），包括网络设备能支持的功能、设备的状态（如IFF_UP、IFF_RUNNING）	
	this->flags				= IFF_BROADCAST|IFF_MULTICAST;
	
	//this->priv_flags		|= IFF_TX_SKB_SHARING;
	this->priv_flags = IFF_XMIT_DST_RELEASE | IFF_XMIT_DST_RELEASE_PERM | IFF_TX_SKB_SHARING;

	//硬件广播地址，hw bcast address
	this->broadcast[MAX_ADDR_LEN] = 0xffffffffffff;

	//--------------------------
	//以下字段由alloc_etherdev()设置
	//--------------------------

	//the number of TX subqueues allocated at alloc_netdev_mq() time	
	this->num_tx_queues = 1;

	//Number of TX queues currently active in device	
	this->real_num_tx_queues = 1;

 	//_tx是一个发送队列数组，不过在alloc_etherdev()中，只有一个队列
 	//alloc_netdev_mqs()中:
 	//  分配所有发送队列结构所占空间，发送队列个数，即num_tx_queues
 	//	对于每一个队列，初始化
 	//			._xmit_lock =; 初始化自旋锁
 	//			.xmit_lock_owner = -1;
 	//			.dev = 当前net_device结构地址
 	//			.numa_node = NUMA_NO_NODE
 	//			.dql->max_limit = DQL_MAX_LIMIT;
	//			.dql->min_limit = 0;
	//			.dql->slack_hold_time = HZ;
	//			.dql->limit = 0;
	//			.dql->num_queued = 0;
	//			.dql->num_completed = 0;
	//			.dql->last_obj_cnt = 0;
	//			.dql->prev_num_queued = 0;
	//			.dql->prev_last_obj_cnt = 0;
	//			.dql->prev_ovlimit = 0;
	//			.dql->lowest_slack = UINT_MAX;
	//			.dql->slack_start_time = jiffies;
	//
	//register_netdev()中的设置：
	//			.qdisc = &noop_qdisc;
	//			.qdisc_sleeping = &noop_qdisc;
	//
	//pcnet32_open()中的设置：
	//			.state 清除位0（__QUEUE_STATE_DRV_XOFF）表明可以使用网卡发送数据
	//
	//dev_open()中的设置：
	//			.qdisc_sleeping = ; 分配了（Qdisc结构+ default_qdisc_ops->priv_size）大小的空间
	//								Qdisc结构在前，priv_size部分在后
	//								不过Qdisc结构部分的地址，必须是Qdisc结构大小对齐
	//								Qdisc结构对齐的地址，与分配的内存地址之差，存放于padded字段
	//			.qdisc_sleeping->padded =;
	//			.qdisc_sleeping->gso_skb = 初始化该sk_buff_head结构;
	//			.qdisc_sleeping->skb_bad_txq = 初始化该sk_buff_head结构;
	//			.qdisc_sleeping->q = 初始化该qdisc_skb_head结构;
	//			.qdisc_sleeping->q.lokc = 初始化该锁;
	//			.qdisc_sleeping->cpu_bstats = 分配per cpu空间，大小是struct gnet_stats_basic_cpu
	//			.qdisc_sleeping->cpu_qstats = 分配per cpu空间，大小是struct gnet_stats_queue
	//			.qdisc_sleeping->busylock = 初始化该锁;
	//			.qdisc_sleeping->seqlock = 初始化该锁;
	//			.qdisc_sleeping->running.sequence = 0;
	//			.qdisc_sleeping->ops = &pfifo_fast_ops;
	//			.qdisc_sleeping->flags = pfifo_fast_ops.static_flags = TCQ_F_NOLOCK | TCQ_F_CPUSTATS
	//			.qdisc_sleeping->enqueue = pfifo_fast_ops.enqueue = pfifo_fast_enqueue;
	//			.qdisc_sleeping->dequeue = pfifo_fast_ops.dequeue = pfifo_fast_dequeue;
	//			.qdisc_sleeping->dev_queue = &_tx[0];
	//			.qdisc_sleeping->empty = true;
	//			.qdisc_sleeping->refcnt = 1;
	//			.qdisc_sleeping->parent = TC_H_ROOT;
	//
	//pfifo_fast_init()中的设置
	//			.qdisc_sleeping中pfifo_fast_ops规则私有数据部分，其类型是pfifo_fast_priv
	//					包含skb_arry q[3]数组，该数组的每个元素初始化情况如下；
	//							ring.queue = 为其分配空间，该字段指向元素类型是void*的数组，元素个数1000（tx_queue_len）
	//							ring.size = 1000（tx_queue_len）
	//							ring.batch = 16
	//							ring.producer = ring.consumer_head = ring.consumer_tail = 0;
	//							ring.producer_lock = 初始化该锁
	//							ring.consumer_lock = 初始化该锁
	//			.qdisc_sleeping->flags = TCQ_F_NOLOCK | TCQ_F_CPUSTATS | TCQ_F_CAN_BYPASS;
	//
	//dev_open()中的设置：
	//			.qdisc_sleeping->flags = TCQ_F_ONETXQUEUE | TCQ_F_NOPARENT | TCQ_F_NOLOCK | TCQ_F_CPUSTATS | TCQ_F_CAN_BYPASS;
	//			.qdisc_sleeping->refcnt++;
	//			.qdisc_sleeping->state = 该字段位__QDISC_STATE_DEACTIVATED清0
	//			.qdisc = .qdisc_sleeping
	//			.trans_start = jiffies;
	//
	//dev_queue_xmit()中的设置
	//			.qdisc->empty = false;
	//			.qdisc->running.sequence++;				//qdisc_run_begin()中++
	//			.qdisc->cpu_bstats->bstats.bytes =;		//要发送的帧长度（如果使用了GSO，则考虑了所有分段）
	//			.qdisc->cpu_bstats->bstats.packets =; 	//如果使用了GSO，则等于skb_shinfo(skb)->gso_segs；否则，等于1
	//													//即要发送的帧的个数
	//			.qdisc->running.sequence++;				//qdisc_run_end()中++
	this->_tx =;

	//初始化锁
	this->tx_global_lock =;

	//the number of RX subqueues allocated at alloc_netdev_mqs() time
	this->num_rx_queues = 1;

	//Number of RX queues currently active in device	
	this->real_num_rx_queues = 1;

	//_rx是一个接收队列数组，不过在alloc_etherdev()中，只有一个队列
 	//alloc_netdev_mqs()中:
 	//  分配所有接收队列结构所占空间，接收队列个数，即num_rx_queues
 	//	对于每一个队列，初始化
 	//			.dev = 当前net_device结构地址
 	//			.xdp_rxq->dev = 当前net_device结构地址;
	//			.xdp_rxq->queue_index = 当前接收队列在数组中的编号, 这里为0;
	//			.xdp_rxq->reg_state = REG_STATE_REGISTERED;
	//			.xdp其余字段被清0								
	this->_rx =;

	//网卡名称，如enss3、eth0、eth1等
	//在register_netdev()中，设置成完整的网络设备名，如"eth1"
	this->name[IFNAMSIZ] = "eth%d";

	this->name_assign_type = NET_NAME_UNKNOWN;

	//所有网络设备默认都属于组INIT_NETDEV_GROUP
	this->group = INIT_NETDEV_GROUP;

	//ethtool工具的操作方法的集合。
	//网卡驱动中又修改了该字段为&pcnet32_ethtool_ops
	this->ethtool_ops = &default_ethtool_ops;

	this->nf_hooks_ingress = NULL;

	//--------------------------
	//以下是网卡驱动的设置
	//--------------------------

	//设置为网卡对应的pci_dev结构的dev字段(类型是struct device *)
	this->dev.parent = ;

	//从网卡I/O端口（寄存器）读出MAC地址，并保存于dev_addr
	this->dev_addr = ;

	//保存网卡的I/O端口基地址
	this->base_addr = ;

	//该链表中加入了一个节点，即pcnet32_private结构的napi字段的dev_list字段，构成链表
	//该链表的元素类型，即napi_struct结构
	this->napi_list =;

	//设置为pci_dev结构的irp（由PCI层设置）
	this->irq =;

	this->netdev_ops = &pcnet32_netdev_ops;

	this->ethtool_ops = &pcnet32_ethtool_ops;

	//传输超时的时间值
	//watchdog_timer的超时时间
	this->watchdog_timeo = (5 * HZ);

	//--------------------------
	//以下是register_netdev()的设置
	//--------------------------

	//初始化该锁
	this->addr_list_lock =;	

	//设置成完整的网络设备名，如"eth1"
	this->name =;

	//分配未被占用的interface index
	this->ifindex =;

	/* Transfer changeable features to wanted_features and enable
	 * software offloads (GSO and GRO).
	 */
	this->hw_features |= NETIF_F_SOFT_FEATURES;
	this->features |= NETIF_F_SOFT_FEATURES;

	//this->wanted_features = dev->features & dev->hw_features;
	this->wanted_features = NETIF_F_SOFT_FEATURES;

	//this->hw_features |= NETIF_F_NOCACHE_COPY
	this->hw_features = NETIF_F_SOFT_FEATURES | NETIF_F_NOCACHE_COPY;

	//Make NETIF_F_HIGHDMA inheritable to VLAN devices.
	this->vlan_features = NETIF_F_HIGHDMA;

	// Make NETIF_F_SG inheritable to tunnel devices.
	this->hw_enc_features = NETIF_F_SG | NETIF_F_GSO_PARTIAL;

	// Make NETIF_F_SG inheritable to MPLS.
	this->mpls_features |= NETIF_F_SG;

	this->dev->kobj.kset = devices_kset;
	this->dev->kobj->kref = 1;
	this->dev->kobj->entry =;	//初始化链表
	this->dev->kobj->state_in_sysfs = 0;
	this->dev->kobj->state_add_uevent_sent = 0;
	this->dev->kobj->state_remove_uevent_sent = 0;
	this->dev->kobj->state_initialized = 1;
	this->dev->kobj->ktype = &device_ktype;
	this->dev->dma_pools =; //初始化链表
	this->dev->mutex = ;
	this->dev->devres_lock = ;
	this->dev->devres_head = ;
	this->dev->power.lock =;
	this->dev->power.qos = NULL;
	this->dev->power.early_init = true;
	this->dev->power.is_prepared = false;
	this->dev->power.is_suspended = false;
	this->dev->power.is_noirq_suspended = false;
	this->dev->power.is_late_suspended = false;
	this->dev->power.completion.done = 0;
	this->dev->power.completion.wait.lock =;
	this->dev->power.completion.wait.head =;	//初始化链表	
	this->dev->power.completion.done = UINT_MAX;
	this->dev->power.wakeup = NULL;
	this->dev->power.entry =;		//初始化链表
	this->dev->power.runtime_status = RPM_SUSPENDED;
	this->dev->power.idle_notification = false;
	this->dev->power.disable_depth = 1;
	this->dev->power.usage_count = 0;
	this->dev->power.runtime_error = 0;
	this->dev->power.child_count = 0;
	this->dev->power.ignore_children = false;
	this->dev->power.runtime_auto = true;
	this->dev->power.request_pending = false;
	this->dev->power.request = RPM_REQ_NONE;
	this->dev->power.deferred_resume = false;
	this->dev->power.work.data =  WORK_STRUCT_NO_POOL;
	this->dev->power.work.entry = ; //初始化链表
	this->dev->power.work.func = pm_runtime_work;
	this->dev->power.timer_expires = 0;
	hrtimer_init(&this->dev->power.suspend_timer, CLOCK_MONOTONIC, HRTIMER_MODE_ABS);
	this->dev->power.suspend_timer.function = pm_suspend_timer_fn;
	init_waitqueue_head(&this->dev->power.wait_queue);
	this->dev->numa_node = -1;
	this->dev->msi_list =;		//初始化链表
	this->dev->links.consumers =;	//初始化链表
	this->dev->links.suppliers = ;//初始化链表
	this->dev->links.status = DL_DEV_NO_DRIVER;
	this->dev->class = &net_class;
	this->dev->platform_data = this;
	this->dev->groups = this->sysfs_groups;
	this->dev->kobj->name = this->name; //如eth2
	//.............
	
	this->sysfs_groups[0] = &netstat_group;

	this->reg_state = NETREG_REGISTERED;
	
	this->features = NETIF_F_GRO;

	//表明设备存在
	//位__LINK_STATE_PRESENT被设置
	this->state = ;

	this->qdisc = &noop_qdisc;

	//初始化该定时器，超时时调用的回调函数设置为dev_watchdog，其内部会调用netdev_ops->ndo_tx_timeout
	this->watchdog_timer =;

	//此时等于1
	this->pcpu_refcnt++;

	//net_device结构加入到所属net结构的dev_base_head链表中
	this->dev_list=;

	//net_device结构加入到所属net结构的dev_name_head哈希表中
	this->name_hlist =;

	//net_device结构加入到所属net结构的dev_index_head哈希表中
	this->index_hlist =;

	//从dev_addr字段复制得到MAC地址
	this->perm_addr =;

	//--------------------------
	//以下是dev_open()的设置
	//--------------------------

	//位__LINK_STATE_START、位__LINK_STATE_PRESENT被设置
	this->state =;
	
	this->flags	= IFF_BROADCAST | IFF_MULTICAST | IFF_UP;

	this->qdisc = this->_tx[0].qdisc_sleeping;

	//超时时间设置为 round_jiffies(jiffies + watchdog_timeo)
	this->watchdog_timer =;
};

//net/ethernet/eth.c：358
const struct header_ops eth_header_ops = 
{
	.create		= eth_header,
	.parse		= eth_header_parse,
	.cache		= eth_header_cache,
	.cache_update	= eth_header_cache_update,
	.parse_protocol	= eth_header_parse_protocol,
};

static const struct net_device_ops pcnet32_netdev_ops = 
{
	//当网络设备被转变成UP状态时调用
	.ndo_open		= pcnet32_open,

	//当网络设备被转变成DOWN状态时调用
	.ndo_stop 		= pcnet32_close,

	//当发送帧dev_queue_xmit()时被调用
	.ndo_start_xmit		= pcnet32_start_xmit,

	//传输失败（超时）时调用此函数
	.ndo_tx_timeout		= pcnet32_tx_timeout,

	//用户调用此函数以查询网络设备使用统计数据
	.ndo_get_stats		= pcnet32_get_stats,

	/*	This function is called device changes address list filtering.
 	 *	If driver handles unicast address filtering, it should set
 	 *	IFF_UNICAST_FLT in its priv_flags.
 	 */
 	//dev_open()调用完ndo_open()后，会调用此回调
	.ndo_set_rx_mode	= pcnet32_set_multicast_list,

	//该函数将特定io控制命令发送给网络设备
	.ndo_do_ioctl		= pcnet32_ioctl,

	/*	This function  is called when the Media Access Control address
	 *	needs to be changed. If this interface is not defined, the
 	 *	MAC address can not be changed.
	 */
	.ndo_set_mac_address 	= eth_mac_addr,

	//Test if Media Access Control address is valid for the device.
	.ndo_validate_addr	= eth_validate_addr,

	//使用查询方式代替中断方式处理网卡数据包收发事件
	//注意必须禁止中断，实际上直接调用中断函数，也可以直接调度NAPI去处理
	.ndo_poll_controller	= pcnet32_poll_controller,
};

static const struct ethtool_ops pcnet32_ethtool_ops = 
{
	/*
	 * @get_drvinfo: Report driver/device information.  Should only set the
	 *	@driver, @version, @fw_version and @bus_info fields.  If not
	 *	implemented, the @driver and @bus_info fields will be filled in
	 *	according to the netdev's parent device.
	 */
	.get_drvinfo		= pcnet32_get_drvinfo,

	/*
	 * @get_msglevel: Report driver message level.  This should be the value
	 *	of the @msg_enable field used by netif logging functions.
	*/
	.get_msglevel		= pcnet32_get_msglevel,

	//Set driver message level
	.set_msglevel		= pcnet32_set_msglevel,

	//Restart autonegotiation.  Returns a negative error code or zero.
	.nway_reset		= pcnet32_nway_reset,

	/*
	 * @get_link: Report whether physical link is up.  Will only be called if
	 *	the netdev is up.  Should usually be set to ethtool_op_get_link(),
	 *	which uses netif_carrier_ok().
	*/
	.get_link		= pcnet32_get_link,

	//Report ring sizes
	.get_ringparam		= pcnet32_get_ringparam,

	//Set ring sizes.  Returns a negative error code or zero.
	.set_ringparam		= pcnet32_set_ringparam,

	//Return a set of strings that describe the requested objects
	.get_strings		= pcnet32_get_strings,

	//Run specified self-tests
	.self_test		= pcnet32_ethtool_test,

	/*
	 * @set_phys_id: Identify the physical devices, e.g. by flashing an LED
	 *	attached to it.  The implementation may update the indicator
	 *	asynchronously or synchronously, but in either case it must return
	 *	quickly.  It is initially called with the argument %ETHTOOL_ID_ACTIVE,
	 *	and must either activate asynchronous updates and return zero, return
	 *	a negative error or return a positive frequency for synchronous
	 *	indication (e.g. 1 for one on/off cycle per second).  If it returns
	 *	a frequency then it will be called again at intervals with the
	 *	argument %ETHTOOL_ID_ON or %ETHTOOL_ID_OFF and should set the state of
	 *	the indicator accordingly.  Finally, it is called with the argument
	 *	%ETHTOOL_ID_INACTIVE and must deactivate the indicator.  Returns a
	 *	negative error code or zero.
	 */
	.set_phys_id		= pcnet32_set_phys_id,

	// Get buffer length required for @get_regs
	.get_regs_len		= pcnet32_get_regs_len,

	//Get device registers
	.get_regs		= pcnet32_get_regs,

	//Get number of strings that @get_strings will write.
	.get_sset_count		= pcnet32_get_sset_count,

	/*
	 * @get_link_ksettings: Get various device settings including Ethernet link
	 *	settings. The %cmd and %link_mode_masks_nwords fields should be
	 *	ignored (use %__ETHTOOL_LINK_MODE_MASK_NBITS instead of the latter),
	 *	any change to them will be overwritten by kernel. Returns a negative
	 *	error code or zero.
	 */
	.get_link_ksettings	= pcnet32_get_link_ksettings,

	/*
	 * @set_link_ksettings: Set various device settings including Ethernet link
	 *  settings. The %cmd and %link_mode_masks_nwords fields should be
	 *  ignored (use %__ETHTOOL_LINK_MODE_MASK_NBITS instead of the latter),
	 *  any change to them will be overwritten by kernel. Returns a negative
	 *  error code or zero.
	*/
	.set_link_ksettings	= pcnet32_set_link_ksettings,
};

//pcnet32驱动私有数据
struct pcnet32_private 
{
	//以太网卡会读取该结构，因此该结构需要从DMA区域分配
	//在.probe()中，该字段保存了新分配的DMA内存对应的线性地址
	//	.mode = 0x0003; 	对应MODE 0x0003 设置了两位  1. loopback enable  2.Disable Transmit
	//						Disable Rx and Tx. 
	//	.mode = bit 7 置位
	//	.tlen_rlen = tx_len_bits | lp->rx_len_bits;
	//	.phys_addr = 从net_device结构dev_addr数组复制MAC地址;
	//				 pcnet32_open()中也会复制一次
	//	.filter = 数组清0;	设置LADRF(Logical Address Filter)，有对应I/O端口
	//				该filter和多播地址相关
	//	.rx_ring = rx_ring_dma_addr;  	该字段保存了rx_ring数组（pcnet32_rx_head结构数组）对应的（cache一致性DMA内存区域对应的）、用于DMA操作的物理地址
	//				pcnet32_open()中也会复制一次
	//	.tx_ring = tx_ring_dma_addr;	该字段保存了tx_ring数组（pcnet32_tx_head结构数组）对应的（cache一致性DMA内存区域对应的）、用于DMA操作的物理地址
	//				pcnet32_open()中也会复制一次
	struct pcnet32_init_block 	*init_block;

	/* The Tx and Rx ring entries must be aligned on 16-byte boundaries in 32bit mode. */
	//由于接收缓冲区的若干skb构成了环形缓冲，该字段用于管理接收环形缓冲区描述结构？？
	//在.probe()中，从cache一致性DMA区域分配内存，得到的线性地址保存于该字段
	//分配的大小是：sizeof(struct pcnet32_rx_head) * lp->rx_ring_size（32）
	//即，rx_ring指向了pcnet32_rx_head构成数组，元素个数32
	//即，rx_ring是32个接收缓冲区的描述结构
	struct pcnet32_rx_head		*rx_ring;

	//由于发送缓冲区的若干skb构成了环形缓冲，该字段用于管理发送环形缓冲区描述结构？？？
	//在.probe()中，从cache一致性DMA区域分配内存，得到的线性地址保存于该字段
	//分配的大小是：sizeof(struct pcnet32_tx_head) * tx_ring_size（16）
	//即，tx_ring指向了pcnet32_tx_head构成数组，元素个数16
	//即，tx_ring是16个发送缓冲区的描述结构
	struct pcnet32_tx_head		*tx_ring;

	//在.probe()中，该字段保存了init_block对应的DMA内存的DMA所用物理地址
	dma_addr_t					init_dma_addr;

	//在.probe()中，该字段保存了PCI层传递而来的PCI设备
	struct pci_dev				*pci_dev;

	//在.probe()中，该字段保存了芯片名称
	//本机测试得"PCnet/PCI II 79C970A"
	const char					*name;
	
	/* The saved address of a sent-in-place packet/buffer, for skfree(). */
	//在.probe()中，从内核堆分配了tx_ring_size * sizeof(struct sk_buff *)的空间
	//即，tx_skbuff指向了skb结构指针数组，元素个数16
	//即，tx_skbuff数组保存了16个skb结构的指针
	//这里的16个skb，构成了发送环形缓冲区
	struct sk_buff				**tx_skbuff;

	//在.probe()中，从内核堆分配了rx_ring_size * sizeof(struct sk_buff *)的空间
	//即，rx_skbuff指向了skb结构指针数组，元素个数32
	//即，rx_skbuff数组保存了32个skb结构的指针
	//这里的32个skb，构成了接收环形缓冲区
	//在接收过程中，每个skb会保存一个完整的帧
	//在pcnet32_open()中：
	//	为该数组申请32个skb缓冲
	//	申请的每个skb对应的缓冲区（线性缓冲区）大小是1544字节，再外加netdev_alloc_skb保留的64字节，共1608字节
	struct sk_buff				**rx_skbuff;

	//在.probe()中，从内核堆中分配了tx_ring_size * sizeof(dma_addr_t)大小的空间
	//即，tx_dma_addr指向了dma_addr_t类型的数组，数组元素为16
	//即，该数组保存了16个发送缓冲区对应的、用于DMA操作的物理地址
	//在pcnet32_open()中，该数组清0
	dma_addr_t					*tx_dma_addr;

	//在.probe()中，从内核堆中分配了rx_ring_size            * sizeof(dma_addr_t)大小的空间
	//即，rx_dma_addr指向了dma_addr_t类型的数组，数组元素为32
	//即，该数组保存了32个接收缓冲区对应的、用于DMA操作的物理地址
	//在pcnet32_open()中
	//	该数组的每个元素，实际保存了rx_skbuff数组中，对应skb->data，对应的、用于DMA的地址
	dma_addr_t					*rx_dma_addr;

	//在.probe()中，初始化为&pcnet32_wio
	const struct pcnet32_access *a;

	//在.probe()中，初始化该锁
	spinlock_t					lock;		/* Guard lock */

	//标识当前正在使用的skb缓冲区编号
	//cur_rx：从cur_rx开始的若干skb缓冲区，包含有接收到的帧
	//cur_tx：从cur_tx开始的若干skb缓冲区，可以存放上层应用新发送的数据
	//在pcnet32_open()中，设为0
	unsigned int				cur_rx, cur_tx;	/* The next free ring entry */

	//接收环形缓冲区大小，即skb的个数
	//在.probe()中，设置为32
	unsigned int				rx_ring_size;	

	//环形发送缓冲大小，即skb的个数
	//在.probe()中，初始化为16
	unsigned int				tx_ring_size;

	//rx ring modular mask
	//在环形缓冲中绕圈时，通过该字段取余来获得当前在环中的位置
	//在.probe()中，该字段=rx_ring_size-1，即0x1f
	unsigned int				rx_mod_mask;	

	//tx ring modular mask
	//在环形缓冲中绕圈时，通过该字段取余来获得当前在环中的位置
	//在.probe()中，该字段=tx_ring_size-1，即0xf
	unsigned int				tx_mod_mask;

	//在.probe()中，该字段=5<<4
	//见pcnet32_init_block结构的tlen_rlen字段
	//即32个接收缓冲区（skb）
	unsigned short				rx_len_bits;

	//在.probe()中，该字段被设置为=4           << 12
	//见pcnet32_init_block结构的tlen_rlen字段
	//即16个发送缓冲区（skb）
	//注意：驱动发送上层传来的skb时并不会复制，因此16个发送缓冲区本质上只是skb结构的描述，并不会实际分配缓冲内存
	unsigned short				tx_len_bits;

	//该字段保存了rx_ring数组（pcnet32_rx_head结构数组）对应的（cache一致性DMA内存区域对应的）、用于DMA操作的物理地址
	dma_addr_t					rx_ring_dma_addr;

	//该字段保存了tx_ring数组（pcnet32_tx_head结构数组）对应的（cache一致性DMA内存区域对应的）、用于DMA操作的物理地址
	dma_addr_t					tx_ring_dma_addr;

	//缓冲区的使用情况统计
	//在pcnet32_open()中，设为0
	unsigned int				dirty_rx,	/* ring entries to be freed. */
								dirty_tx;	//表示第1个脏的缓冲区，脏是指该缓冲区中包含有未发出的数据
											//脏的缓冲区位于[dirty_tx, cur_tx)之间

	//在.probe()中，该字段保存了分配的net_device结构地址
	struct net_device			*dev;

	//在.probe()中，
	//	.weight = rx_ring_size / 2; 即16。权重越大，一次中断中能够完成的工作就越多
	//								权重指的是该设备所要准备接收的包数量
	//	.poll_list =; 	对链表初始化
	//	.timer =; 		对定时器初始化
	//	.timer.function = napi_watchdog;
	//	.gro_hash[i] =;	初始化每个哈希槽
	//	.gro_bitmask = 0;
	//	.skb = NULL;
	//	.rx_list =;		初始化链表
	//	.rx_count = 0;
	//	.poll = pcnet32_poll;
	//	.dev_list =;	加入到net_device结构的字段napi_list链表中
	//	.dev = 当前的net_device结构
	//	.poll_owner = -1;
	//	.state = BIT(NAPIF_STATE_SCHED) | BIT(NAPI_STATE_HASHED), NAPI_STATE_HASHED代表的bit的被设置，即bit4;
	//	.napi_id = 当前未被占用的napi_gen_id++
	//	.napi_hash_node =;	哈希表napi_hash的基本单元，即napi_struct结构
	//						该字段加入哈希表内部冲突链表中
	//						该哈希表的key就是napi_id
	//
	//dev_open()调用到驱动程序pcnet32_open()中
	//	.state = BIT(NAPI_STATE_HASHED)
	//
	//接收到数据包的中断处理例程（pcnet32_interrupt()）中：
	//	.state = BIT(NAPI_STATE_HASHED) | BIT(NAPIF_STATE_SCHED)
	//	.poll_list =; 	加入到链表softnet_data.poll_list中
	//
	//软中断NET_RX_SOFTIRQ处理例程net_rx_action()中：
	//	调用完驱动程序的poll回调后，.state = BIT(NAPI_STATE_HASHED)
	struct napi_struct			napi;
	
	char						tx_full;	//在pcnet32_open()中，设为0
											//判断16个发送缓冲位置是否已经用完
	
	char						phycount;	/* number of phys found */

	//在.probe()中，该字段=PCNET32_PORT_10BT, 即  1
	int							options;

	unsigned int				shared_irq:1,	//在.probe()中，该字段=1，表示可共享IRQ线
								dxsuflo:1,   	//在.probe()中，该字段=0，disable transmit stop on uflo
								mii:1,			//在.probe()中，该字段=0，mii port available
								autoneg:1,		//在pcnet32_open()中，该字段=0，autoneg enabled
								port_tp:1,		//在pcnet32_open()中，该字段=1，port set to TP
								fdx:1;			//在pcnet32_open()中，该字段=0     	full duplex enabled

	struct net_device			*next;

	//在.probe()中，初始化该结构：
	//	.full_duplex = 1;	即网卡设备是全双工的
	//	.phy_id_mask = 0x1f;
	//	.reg_num_mask = 0x1f;
	//	.dev = 分配的net_device结构指针
	//	.mdio_read = mdio_read;
	//	.mdio_write = mdio_write;
	struct mii_if_info			mii_if;

	//在.probe()中，初始化该定时器，超时时调用的回调函数设置为pcnet32_watchdog
	//该定时器用于定期检测硬件链路状态，如拔掉网线等。
	//发现上述事件将通知上层。该通知机制是通过workqueue实现的。
	struct timer_list			watchdog_timer;

	//在.probe()中，被设为NETIF_MSG_DRV | NETIF_MSG_PROBE | NETIF_MSG_LINK
	//任何网卡驱动都需要提供该字段，名称也要一致
	u32							msg_enable;	/* debug message level */

	u32							phymask;

	//在.probe()中，该字段=0x2621	
	unsigned short				chip_version;	/* which variant this is */

	u16 						save_regs[4];
};

struct pcnet32_init_block
{
	__le16	mode;			//小端顺序

	/*
     * pcnet32_private结构的tx_len_bits和rx_len_bits是用来填充itlen_rlen成员的
	 * tlen_rlen成员的bit12~big15用来存放tx_len_bits，
     * bit4~bit7用来存放rx_len_bigs，
     * tlen_rlen = lp->tx_len_bits | lp->rx_len_bits,
     */
	__le16	tlen_rlen;
	
	u8		phys_addr[6];	//保存MAC地址

	__le16	reserved;

	__le32	filter[2];		//对应LADRF(Logical Address Filter)，有对应I/O端口
							//和多播地址相关
	
	__le32	rx_ring;		//小端顺序，接收环形缓冲区数组的首地址
	__le32	tx_ring;		//小端顺序，发送环形缓冲区数组的首地址
};

#endif

#if 1 //softnet_data结构、网络软中断和NAPI

/*
 * 网络设备帧接收使用软中断类型是NET_RX_SOFTIRQ，对应的软中断处理函数为net_rx_action
 * 网络设备帧发送使用软中断类型是NET_TX_SOFTIRQ，对应的软中断处理函数为net_tx_action
 * net_dev_init()函数中设置：
 * 		softirq_vec[NET_TX_SOFTIRQ].action = net_tx_action;
 * 		softirq_vec[NET_RX_SOFTIRQ].action = net_rx_action;
 *		static struct softirq_action softirq_vec[NR_SOFTIRQS];
 * 
 * 当上述软中断发生，导致net_rx_action被调用时，会遍历softnet_data链表，接收数据包
 */

//include/linux/netdevice.h：3032
//DECLARE_PER_CPU_ALIGNED(struct softnet_data, softnet_data);
//每个CPU拥有一个接收数据包的队列
//其poll_list字段指向一个链表，而链表元素，即napi_struct结构（其poll_list字段组成链表）
//net_dev_init()中初始化：
//	.input_pkt_queue =;		初始化该sk_buff_head
//	.process_queue =;		初始化该sk_buff_head
//	.xfrm_backlog =;		初始化该sk_buff_head
//	.poll_list = ;			初始化该链表
//	.output_queue_tailp = &.output_queue;		针对的是同一个softnet_data实例
//	.csd.func = rps_trigger_softirq
//	.csd.info =;			将当前的softnet_data实例的地址赋予该字段，相当于this指针
//	.cpu =;					设置当前CPU编号，因为是per cpu结构
//	.backlog.gro_hash =;	初始化该哈希表
//	.backlog.gro_bitmask = 0;
//	.backlog.poll = process_backlog;
//	.backlog.weight = weight_p
struct softnet_data softnet_data;

//include/linux/netdevice.h：2974
/*
 * Incoming packets are placed on per-CPU queues
 */
//每个CPU拥有一个接收发送帧的队列
struct softnet_data 
{
	//指向一个链表，而链表元素，即napi_struct结构（其poll_list字段组成链表）
	struct list_head	poll_list;				
	
	struct sk_buff_head	process_queue;

	/* stats */
	unsigned int		processed;				//记录接收过程中，处理过的帧数目
												//__netif_receive_skb_core()中加1
												
	unsigned int		time_squeeze;			//net_rx_action()调用若干驱动程序poll接收帧数目超过额度，或超过时间额度，的次数

	unsigned int		received_rps;

	struct softnet_data	*rps_ipi_list;

	struct sd_flow_limit __rcu *flow_limit;

	//当dev_queue_xmit()向驱动发送帧时，驱动程序返回NETDEV_TX_BUSY，说明其内部发送队列已满
	//此时将发送帧使用的Qdisc结构，比如常常是net_device._tx[0].qdisc，加入到output_queue链表尾部
	//而output_queue_tailp则保存了Qdisc结构next_sched字段的地址，代表链表尾部
	struct Qdisc		*output_queue;
	struct Qdisc		**output_queue_tailp;

	//pcnet32中，被发送帧对应的skb，是在NIC驱动程序中释放的（中断通知->软中断->poll回调）
	//这种情况下，被释放的skb是不会放入到completion_queue链表
	//不过若是在硬件中断上下文，或硬件中断关闭的情况下，调用dev_kfree_skb_any函数释放skb，
	//就会将skb放入completion_queue链表首部
	//在net_tx_action软中断处理例程中遍历completion_queue链表，真正释放skb
	struct sk_buff		*completion_queue;		//该缓冲区中的数据已经成功发送，可以释放掉

	struct sk_buff_head	xfrm_backlog;
	/* written and read only by owning cpu: */
	
	struct 
	{
		u16 recursion;
		u8  more;			//发送帧时，该标志指示后续是否还有帧要发送，为true表示还有
							//dev_queue_xmit()在调用NIC驱动提供的ndo_start_xmit()之前设置
	} xmit;
	
	/* input_queue_head should be written by cpu owning this struct,
	 * and only read by other cpus. Worth using a cache line.
	 */
	unsigned int		input_queue_head;// ____cacheline_aligned_in_smp;

	/* Elements below can be accessed between CPUs for RPS/RFS */
	call_single_data_t	csd;// ____cacheline_aligned_in_smp;
	struct softnet_data	*rps_ipi_next;
	unsigned int		cpu;
	unsigned int		input_queue_tail;

	unsigned int		dropped;
	
	struct sk_buff_head	input_pkt_queue;	//非NAPI和RPS时，用来保存接收到的帧
	
	struct napi_struct	backlog;
};

//include/linux/netdevice.h：311
/*
 * size of gro hash buckets, must less than bit number of
 * napi_struct::gro_bitmask
 */
#define GRO_HASH_BUCKETS	8

//include/linux/netdevice.h：316
/*
 * Structure for NAPI scheduling similar to tasklet but with weighting
 */
struct napi_struct 
{
	/* The poll_list must only be managed by the entity which
	 * changes the state of the NAPI_STATE_SCHED bit.  This means
	 * whoever atomically sets that bit can add this napi_struct
	 * to the per-CPU poll_list, and whoever clears that bit
	 * can remove from the list right before clearing the bit.
	 */
	//per cpu变量softnet_data，代表每个CPU拥有的一个接收数据包的队列（链表）
	//poll_list字段组成该链表
	struct list_head	poll_list;

	unsigned long		state;			//NAPI的调度状态
	int					weight;			//驱动程序注册的poll回调函数，一次轮询的最大处理报文数（接收时）
	unsigned long		gro_bitmask;	

	//接收到帧后，软中断处理例程net_rx_action()调用此回调
	int			(*poll)(struct napi_struct *, int);
	
	int					poll_owner;
	struct net_device	*dev;
	struct gro_list		gro_hash[GRO_HASH_BUCKETS];
	struct sk_buff		*skb;
	struct list_head	rx_list; /* Pending GRO_NORMAL skbs */
	int					rx_count; /* length of rx_list */

	struct hrtimer		timer;

	struct list_head	dev_list;		//该字段被链入到net_device结构的napi_list链表
	
	struct hlist_node	napi_hash_node;	//哈希表napi_hash的基本单元，即napi_struct结构
										//该字段加入哈希表内部冲突链表中
										//该哈希表的key就是napi_id
										
	unsigned int		napi_id;		//该字段是当前未被占用的napi_gen_id，之后napi_gen_id++
};

#endif

#if 1 //softnet_data结构的管理函数

//net/core/dev.c：6224
//初始化napi，并将其加入net_devive结构的napi_list链表，以及全局哈希表napi_hash
void netif_napi_add(struct net_device *dev, struct napi_struct *napi,
		    int (*poll)(struct napi_struct *, int), int weight)
{
	INIT_LIST_HEAD(&napi->poll_list);
	
	hrtimer_init(&napi->timer, CLOCK_MONOTONIC, HRTIMER_MODE_REL_PINNED);
	
	napi->timer.function = napi_watchdog;
	init_gro_hash(napi);
	
	napi->skb = NULL;
	
	INIT_LIST_HEAD(&napi->rx_list);
	
	napi->rx_count = 0;
	napi->poll = poll;
	
	if (weight > NAPI_POLL_WEIGHT)
		netdev_err_once(dev, "%s() called with weight %d\n", __func__, weight);
	
	napi->weight = weight;
	
	list_add(&napi->dev_list, &dev->napi_list);
	
	napi->dev = dev;

	napi->poll_owner = -1;

	set_bit(NAPI_STATE_SCHED, &napi->state);
	
	napi_hash_add(napi);
}
EXPORT_SYMBOL(netif_napi_add);

//net/core/dev.c：6158
static void napi_hash_add(struct napi_struct *napi)
{
	if (test_bit(NAPI_STATE_NO_BUSY_POLL, &napi->state) ||
	    test_and_set_bit(NAPI_STATE_HASHED, &napi->state))
		return;

	spin_lock(&napi_hash_lock);

	/* 0..NR_CPUS range is reserved for sender_cpu use */
	//搜索一个没有被占用的napi_gen_id
	do {
		if (unlikely(++napi_gen_id < MIN_NAPI_ID))
			napi_gen_id = MIN_NAPI_ID;
	} while (napi_by_id(napi_gen_id));
		
	napi->napi_id = napi_gen_id;

	hlist_add_head_rcu(&napi->napi_hash_node,
			   &napi_hash[napi->napi_id % HASH_SIZE(napi_hash)]);

	spin_unlock(&napi_hash_lock);
}

//该哈希表的key就是napi_id，哈希表的基本元素即napi_struct结构
static DEFINE_READ_MOSTLY_HASHTABLE(napi_hash, 8);

//net/core/dev.c：6031
/* must be called under rcu_read_lock(), as we dont take a reference */
//在napi_hash哈希表中查找napi_id是否已经被某个napi_struct结构占据
//若占据则返回该结构地址，否则返回NULL
static struct napi_struct *napi_by_id(unsigned int napi_id)
{
	unsigned int hash = napi_id % HASH_SIZE(napi_hash);
	struct napi_struct *napi;

	hlist_for_each_entry_rcu(napi, &napi_hash[hash], napi_hash_node)
		if (napi->napi_id == napi_id)
			return napi;

	return NULL;
}


/* Default NAPI poll() weight
 * Device drivers are strongly advised to not use bigger value
 */
#define NAPI_POLL_WEIGHT 64

static void init_gro_hash(struct napi_struct *napi)
{
	int i;

	for (i = 0; i < GRO_HASH_BUCKETS; i++) 
	{
		INIT_LIST_HEAD(&napi->gro_hash[i].list);
		napi->gro_hash[i].count = 0;
	}
	
	napi->gro_bitmask = 0;
}
#endif

#if 1 //ptype_base、ptype_all和dev_add_pack()

//net/core/dev.c：154
static DEFINE_SPINLOCK(ptype_lock);

//net/core/dev.c：156
//net_dev_init()中完成初始化链表头数组
//ptype为packet type
//该数组保存网络层中各类协议注册的处理例程
//数组的每个元素，对应一种协议
//比如IP协议，对应的数组元素索引是：ntohs(ETH_P_IP=0x0800) & 0xf = 8
//数组元素的类型，应该是packet_type结构链表
//__netif_receive_skb_core()中会调用注册的回调
struct list_head ptype_base[PTYPE_HASH_SIZE];// __read_mostly;

//net/core/dev.c：157
//net_dev_init()中完成初始化
//功能同ptype_base类似，只是协议类型是ETH_P_ALL（通配符）的packet_type结构，均放入ptype_all链表
//也就是说ptype_all上注册的回调函数，可以监听所有类型的MAC帧
//__netif_receive_skb_core()中会调用注册的回调
//注意：若网卡驱动接收到帧时，使用了紧急内存，则其中保存的数据包，不会传递给ptype_all链表
struct list_head ptype_all;// __read_mostly;	/* Taps */

//net/ipv4/af_inet.c:1903
static struct packet_type ip_packet_type = // __read_mostly = 
{
	.type = cpu_to_be16(ETH_P_IP),
	.func = ip_rcv,
	.list_func = ip_list_rcv,
};

//include/linux/netdevice.h:2348
struct packet_type 
{
	//该packet_type针对的第三层协议，如cpu_to_be16(ETH_P_IP)、通配符cpu_to_be16(ETH_P_ALL)
	__be16				type;	/* This is really htons(ether_type). */

	//若等于true，发送帧时，将不会调用回调func；否则发送帧时也会调用
	bool				ignore_outgoing;

	//如果指定了dev，则该packet_type结构会挂载到net_device结构的ptype_all或ptype_specific链表
	struct net_device	*dev;	/* NULL is wildcarded here	     */

	//接收帧netif_receive_skb()、发送帧dev_queue_xmit()时，内核会调用func通知截获者
	int					(*func) (struct sk_buff *,
					 			 struct net_device *,
					 			 struct packet_type *,
					 			 struct net_device *);

	//驱动程序接收到若干帧时，可以一次性调用netif_receive_skb_list，其内部会调用list_func
	void				(*list_func) (struct list_head *,
					      			  struct packet_type *,
					      			  struct net_device *);

	//如果设置了该回调，发送帧dev_queue_xmit()时，将会调用该函数
	//该函数返回false，则不会调用func回调函数
	bool				(*id_match)(struct packet_type *ptype, struct sock *sk);

	//若该字段等于0，则发送帧dev_queue_xmit()时，不会调用回调函数func
	//若该字段不为0，且等于帧所在skb、对应的sock结构地址，则会调用回调函数func
	void				*af_packet_priv;

	//构成ptype_base或ptype_all链表
	struct list_head	list;
};

//net/core/dev.c:3225
/**
 *	dev_add_pack - add packet handler
 *	@pt: packet type declaration
 *
 *	Add a protocol handler to the networking stack. The passed &packet_type
 *	is linked into kernel lists and may not be freed until it has been
 *	removed from the kernel lists.
 *
 *	This call does not sleep therefore it can not
 *	guarantee all CPU's that are in middle of receiving packets
 *	will see the new packet type (until the next received packet).
 */
//添加网络层的处理例程，到ptype_base数组相应元素对应的链表中
void dev_add_pack(struct packet_type *pt)
{
	struct list_head *head = ptype_head(pt);

	spin_lock(&ptype_lock);
	
	list_add_rcu(&pt->list, head);
	
	spin_unlock(&ptype_lock);
}
EXPORT_SYMBOL(dev_add_pack);

//net/core/dev.c:303
//IP协议注册ip_rcv处理函数等时，返回&ptype_base[ntohs(pt->type) & PTYPE_HASH_MASK]
//	即返回ptype_base数组中，IP协议对应的元素地址
static inline struct list_head *ptype_head(const struct packet_type *pt)
{
	if (pt->type == htons(ETH_P_ALL))
		return pt->dev ? &pt->dev->ptype_all : &ptype_all;
	else
		return pt->dev ? &pt->dev->ptype_specific :
				 &ptype_base[ntohs(pt->type) & PTYPE_HASH_MASK];
}

//net/core/dev.c:380
/**
 *	dev_remove_pack	 - remove packet handler
 *	@pt: packet type declaration
 *
 *	Remove a protocol handler that was previously added to the kernel
 *	protocol handlers by dev_add_pack(). The passed &packet_type is removed
 *	from the kernel lists and can be freed or reused once this function
 *	returns.
 *
 *	This call sleeps to guarantee that no CPU is looking at the packet
 *	type after return.
 */
void dev_remove_pack(struct packet_type *pt)
{
	__dev_remove_pack(pt);

	//这里调用的目的是确保被删除的pt，没有谁还持有它的引用
	synchronize_net();
}
EXPORT_SYMBOL(dev_remove_pack);

/**
 *	synchronize_net -  Synchronize with packet receive processing
 *
 *	Wait for packets currently being received to be done.
 *	Does not block later packets from starting.
 */
void synchronize_net(void)
{
	might_sleep();
	if (rtnl_is_locked())
		synchronize_rcu_expedited();
	else
		synchronize_rcu();
}
EXPORT_SYMBOL(synchronize_net);

//net/core/dev.c:348
/**
 *	__dev_remove_pack	 - remove packet handler
 *	@pt: packet type declaration
 *
 *	Remove a protocol handler that was previously added to the kernel
 *	protocol handlers by dev_add_pack(). The passed &packet_type is removed
 *	from the kernel lists and can be freed or reused once this function
 *	returns.
 *
 *      The packet type might still be in use by receivers
 *	and must not be freed until after all the CPU's have gone
 *	through a quiescent state.
 */
void __dev_remove_pack(struct packet_type *pt)
{
	struct list_head *head = ptype_head(pt);
	struct packet_type *pt1;

	spin_lock(&ptype_lock);

	list_for_each_entry(pt1, head, list) {
		if (pt == pt1) {
			list_del_rcu(&pt->list);
			goto out;
		}
	}

	pr_warn("dev_remove_pack: %p not found\n", pt);
out:
	spin_unlock(&ptype_lock);
}
EXPORT_SYMBOL(__dev_remove_pack);

#endif

