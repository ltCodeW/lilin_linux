#if 1 //alloc_netdev()和alloc_netdev_mqs()

//include/linux/netdevice.h：4087
//分配新的net_device结构
#define alloc_netdev(sizeof_priv, name, name_assign_type, setup) \
	alloc_netdev_mqs(sizeof_priv, name, name_assign_type, setup, 1, 1)

//net/core/dev.c：9469
//任务：
//分配net_device结构和私有数据所占用空间
//为网络设备上的每个队列，分配若干子队列结构
//完成初始化
struct net_device *alloc_netdev_mqs(
					int sizeof_priv, 		//自定义数据的大小
					const char *name, 		//device name format string
					unsigned char name_assign_type,	//origin of device name
					void (*setup)(struct net_device *), 	//callback to initialize device
					unsigned int txqs, 		//the number of TX subqueues to allocate
					unsigned int rxqs		//the number of RX subqueues to allocate
					)
{
	struct net_device *dev;
	unsigned int alloc_size;
	struct net_device *p;

	BUG_ON(strlen(name) >= sizeof(dev->name));

	if (txqs < 1) 
	{
		pr_err("alloc_netdev: Unable to allocate device with zero queues\n");
		return NULL;
	}

	if (rxqs < 1) 
	{
		pr_err("alloc_netdev: Unable to allocate device with zero RX queues\n");
		return NULL;
	}

	alloc_size = sizeof(struct net_device);

	if (sizeof_priv) 
	{
		/* ensure 32-byte alignment of private area */
		alloc_size = ALIGN(alloc_size, NETDEV_ALIGN);
		alloc_size += sizeof_priv;
	}
	/* ensure 32-byte alignment of whole construct */
	alloc_size += NETDEV_ALIGN - 1;

	p = kvzalloc(alloc_size, GFP_KERNEL | __GFP_RETRY_MAYFAIL);
	if (!p)
		return NULL;

	dev = PTR_ALIGN(p, NETDEV_ALIGN);
	dev->padded = (char *)dev - (char *)p;

	dev->pcpu_refcnt = alloc_percpu(int);
	if (!dev->pcpu_refcnt)
		goto free_dev;

	if (dev_addr_init(dev))
		goto free_pcpu;

	//Init multicast address list
	dev_mc_init(dev);

	//Init unicast address list
	dev_uc_init(dev);

	//即dev->nd_net=&init_net
	dev_net_set(dev, &init_net);

	//未定义CONFIG_LOCKDEP，该函数等价为空
	netdev_register_lockdep_key(dev);

	dev->gso_max_size = GSO_MAX_SIZE;
	dev->gso_max_segs = GSO_MAX_SEGS;
	dev->upper_level = 1;
	dev->lower_level = 1;

	INIT_LIST_HEAD(&dev->napi_list);
	INIT_LIST_HEAD(&dev->unreg_list);
	INIT_LIST_HEAD(&dev->close_list);
	INIT_LIST_HEAD(&dev->link_watch_list);
	INIT_LIST_HEAD(&dev->adj_list.upper);
	INIT_LIST_HEAD(&dev->adj_list.lower);
	INIT_LIST_HEAD(&dev->ptype_all);
	INIT_LIST_HEAD(&dev->ptype_specific);
	
	hash_init(dev->qdisc_hash);

	dev->priv_flags = IFF_XMIT_DST_RELEASE | IFF_XMIT_DST_RELEASE_PERM;

	//调用参数：回调函数
	setup(dev);

	if (!dev->tx_queue_len) 
	{
		dev->priv_flags |= IFF_NO_QUEUE;
		dev->tx_queue_len = DEFAULT_TX_QUEUE_LEN;
	}

	dev->num_tx_queues = txqs;
	dev->real_num_tx_queues = txqs;

	//分配发送队列结构netdev_queue所占空间
	if (netif_alloc_netdev_queues(dev))
		goto free_all;

	dev->num_rx_queues = rxqs;
	dev->real_num_rx_queues = rxqs;

	//分配接收队列结构所占用空间
	if (netif_alloc_rx_queues(dev))
		goto free_all;

	strcpy(dev->name, name);
	
	dev->name_assign_type = name_assign_type;

	//所有网络设备默认都属于组INIT_NETDEV_GROUP
	dev->group = INIT_NETDEV_GROUP;
	
	if (!dev->ethtool_ops)
		dev->ethtool_ops = &default_ethtool_ops;

	nf_hook_ingress_init(dev);

	return dev;

free_all:
	free_netdev(dev);
	return NULL;

free_pcpu:
	free_percpu(dev->pcpu_refcnt);
free_dev:
	netdev_freemem(dev);
	return NULL;
}
EXPORT_SYMBOL(alloc_netdev_mqs);

//include/linux/netfilter_ingress.h：41
static inline void nf_hook_ingress_init(struct net_device *dev)
{
	RCU_INIT_POINTER(dev->nf_hooks_ingress, NULL);
}

//net/core/dev.c：8837
static int netif_alloc_rx_queues(struct net_device *dev)
{
	unsigned int i, count = dev->num_rx_queues;
	struct netdev_rx_queue *rx;
	size_t sz = count * sizeof(*rx);
	int err = 0;

	BUG_ON(count < 1);

	rx = kvzalloc(sz, GFP_KERNEL | __GFP_RETRY_MAYFAIL);
	if (!rx)
		return -ENOMEM;

	dev->_rx = rx;

	for (i = 0; i < count; i++) 
	{
		rx[i].dev = dev;

		/* XDP RX-queue setup */
		err = xdp_rxq_info_reg(&rx[i].xdp_rxq, dev, i);

		if (err < 0)
			goto err_rxq_info;
	}
	return 0;

err_rxq_info:
	/* Rollback successful reg's and free other resources */
	while (i--)
		xdp_rxq_info_unreg(&rx[i].xdp_rxq);
	kvfree(dev->_rx);
	dev->_rx = NULL;
	return err;
}

//net/core/xdp.c：213
int xdp_rxq_info_reg(struct xdp_rxq_info *xdp_rxq,
		     struct net_device *dev, u32 queue_index)
{
	//alloc_netdev_mqs()调用而来，xdp_rxq全部清0
	if (xdp_rxq->reg_state == REG_STATE_UNUSED) {
		WARN(1, "Driver promised not to register this");
		return -EINVAL;
	}

	if (xdp_rxq->reg_state == REG_STATE_REGISTERED) {
		WARN(1, "Missing unregister, handled but fix driver");
		xdp_rxq_info_unreg(xdp_rxq);
	}

	if (!dev) {
		WARN(1, "Missing net_device from driver");
		return -ENODEV;
	}

	/* State either UNREGISTERED or NEW */
	xdp_rxq_info_init(xdp_rxq);
	xdp_rxq->dev = dev;
	xdp_rxq->queue_index = queue_index;

	xdp_rxq->reg_state = REG_STATE_REGISTERED;
	return 0;
}
EXPORT_SYMBOL_GPL(xdp_rxq_info_reg);

//net/core/xdp.c：207
static void xdp_rxq_info_init(struct xdp_rxq_info *xdp_rxq)
{
	memset(xdp_rxq, 0, sizeof(*xdp_rxq));
}
			 
//net/core/dev.c：8904
static int netif_alloc_netdev_queues(struct net_device *dev)
{
	unsigned int count = dev->num_tx_queues;
	struct netdev_queue *tx;
	size_t sz = count * sizeof(*tx);

	if (count < 1 || count > 0xffff)
		return -EINVAL;

	tx = kvzalloc(sz, GFP_KERNEL | __GFP_RETRY_MAYFAIL);
	if (!tx)
		return -ENOMEM;

	dev->_tx = tx;

	netdev_for_each_tx_queue(dev, netdev_init_one_queue, NULL);
	spin_lock_init(&dev->tx_global_lock);

	return 0;
}

//include/linux/netdevice.h：2125
static inline void netdev_for_each_tx_queue(struct net_device *dev,
					    void (*f)(struct net_device *,
						      struct netdev_queue *,
						      void *),
					    void *arg)
{
	unsigned int i;

	for (i = 0; i < dev->num_tx_queues; i++)
		f(dev, &dev->_tx[i], arg);
}

//net/core/dev.c：8885
static void netdev_init_one_queue(struct net_device *dev,
				  struct netdev_queue *queue, void *_unused)
{
	/* Initialize queue lock */
	spin_lock_init(&queue->_xmit_lock);
	
	lockdep_set_class(&queue->_xmit_lock, &dev->qdisc_xmit_lock_key);
	
	queue->xmit_lock_owner = -1;
	
	netdev_queue_numa_node_write(queue, NUMA_NO_NODE);

	queue->dev = dev;

	dql_init(&queue->dql, HZ);
}

//lib/dynamic_queue_limits.c：131
void dql_init(struct dql *dql, unsigned int hold_time)
{
	dql->max_limit = DQL_MAX_LIMIT;
	dql->min_limit = 0;
	dql->slack_hold_time = hold_time;
	dql_reset(dql);
}
EXPORT_SYMBOL(dql_init);

//lib/dynamic_queue_limits.c：116
void dql_reset(struct dql *dql)
{
	/* Reset all dynamic values */
	dql->limit = 0;
	dql->num_queued = 0;
	dql->num_completed = 0;
	dql->last_obj_cnt = 0;
	dql->prev_num_queued = 0;
	dql->prev_last_obj_cnt = 0;
	dql->prev_ovlimit = 0;
	dql->lowest_slack = UINT_MAX;
	dql->slack_start_time = jiffies;
}
EXPORT_SYMBOL(dql_reset);
//include/linux/netdevice.h：650
static inline void netdev_queue_numa_node_write(struct netdev_queue *q, int node)
{
	q->numa_node = node;
}

//net/core/dev_addr_lists.c：722
/**
 *	dev_uc_flush - Init unicast address list
 *	@dev: device
 *
 *	Init unicast address list.
 */
void dev_uc_init(struct net_device *dev)
{
	__hw_addr_init(&dev->uc);
}
EXPORT_SYMBOL(dev_uc_init);

//net/core/dev_addr_lists.c：943
/**
 *	dev_mc_init - Init multicast address list
 *	@dev: device
 *
 *	Init multicast address list.
 */
void dev_mc_init(struct net_device *dev)
{
	__hw_addr_init(&dev->mc);
}
EXPORT_SYMBOL(dev_mc_init);

//net/core/dev_addr_lists.c：417
void __hw_addr_init(struct netdev_hw_addr_list *list)
{
	INIT_LIST_HEAD(&list->list);
	list->count = 0;
}
EXPORT_SYMBOL(__hw_addr_init);

//net/core/dev_addr_lists.c：454
/**
 *	dev_addr_init - Init device address list
 *	@dev: device
 *
 *	Init device address list and create the first element,
 *	used by ->dev_addr.
 *
 *	The caller must hold the rtnl_mutex.
 */
int dev_addr_init(struct net_device *dev)
{
	unsigned char addr[MAX_ADDR_LEN];
	struct netdev_hw_addr *ha;
	int err;

	/* rtnl_mutex must be held here */

	//初始化dev->dev_addrs链表头和count字段
	__hw_addr_init(&dev->dev_addrs);

	memset(addr, 0, sizeof(addr));
	
	err = __hw_addr_add(&dev->dev_addrs, addr, sizeof(addr), NETDEV_HW_ADDR_T_LAN);
	if (!err) 
	{
		/*
		 * Get the first (previously created) address from the list
		 * and set dev_addr pointer to this location.
		 */
		ha = list_first_entry(&dev->dev_addrs.list, struct netdev_hw_addr, list);
		dev->dev_addr = ha->addr;
	}
	return err;
}
EXPORT_SYMBOL(dev_addr_init);

//net/core/dev_addr_lists.c：80
static int __hw_addr_add(struct netdev_hw_addr_list *list,
			 const unsigned char *addr, int addr_len,
			 unsigned char addr_type)
{
	return __hw_addr_add_ex(list, addr, addr_len, addr_type, false, false, 0);
}

//net/core/dev_addr_lists.c：45
static int __hw_addr_add_ex(struct netdev_hw_addr_list *list,
			    const unsigned char *addr, int addr_len,
			    unsigned char addr_type, bool global, bool sync,
			    int sync_count)
{
	struct netdev_hw_addr *ha;

	if (addr_len > MAX_ADDR_LEN)
		return -EINVAL;

	//由alloc_netdev_mqs()调用而来时，刚分配net_device结构
	//dev->dev_addrs即list，为空
	list_for_each_entry(ha, &list->list, list) 
	{
		if (ha->type == addr_type && !memcmp(ha->addr, addr, addr_len)) 
		{
			if (global) 
			{
				/* check if addr is already used as global */
				if (ha->global_use)
					return 0;
				else
					ha->global_use = true;
			}
			if (sync) 
			{
				if (ha->synced && sync_count)
					return -EEXIST;
				else
					ha->synced++;
			}
			ha->refcount++;
			return 0;
		}
	}

	return __hw_addr_create_ex(list, addr, addr_len, addr_type, global, sync);
}

//net/core/dev_addr_lists.c：45
static int __hw_addr_create_ex(struct netdev_hw_addr_list *list,
			       const unsigned char *addr, int addr_len,
			       unsigned char addr_type, bool global,
			       bool sync)
{
	struct netdev_hw_addr *ha;
	int alloc_size;

	alloc_size = sizeof(*ha);
	
	if (alloc_size < L1_CACHE_BYTES)
		alloc_size = L1_CACHE_BYTES;
	
	ha = kmalloc(alloc_size, GFP_ATOMIC);
	if (!ha)
		return -ENOMEM;
	
	memcpy(ha->addr, addr, addr_len);
	ha->type = addr_type;
	ha->refcount = 1;
	ha->global_use = global;
	ha->synced = sync ? 1 : 0;
	ha->sync_cnt = 0;
	list_add_tail_rcu(&ha->list, &list->list);
	list->count++;

	return 0;
}

#endif

#if 1 //alloc_etherdev()、alloc_etherdev_mq()和ether_setup()

//include/linux/etherdevice.h：51
#define alloc_etherdev(sizeof_priv) alloc_etherdev_mq(sizeof_priv, 1)
#define alloc_etherdev_mq(sizeof_priv, count) alloc_etherdev_mqs(sizeof_priv, count, count)

//net/ethernet/eth.c：406
/**
 * alloc_etherdev_mqs - Allocates and sets up an Ethernet device
 * @sizeof_priv: Size of additional driver-private structure to be allocated
 *	for this Ethernet device
 * @txqs: The number of TX queues this device has.
 * @rxqs: The number of RX queues this device has.
 *
 * Fill in the fields of the device structure with Ethernet-generic
 * values. Basically does everything except registering the device.
 *
 * Constructs a new net device, complete with a private data area of
 * size (sizeof_priv).  A 32-byte (not bit) alignment is enforced for
 * this private data area.
 */

struct net_device *alloc_etherdev_mqs(int sizeof_priv, unsigned int txqs, unsigned int rxqs)
{
	//注意测试环境中：/sys/class/net/ens33/name_assign_type中的值为4，即NET_NAME_RENAMED，用户空间修改了名称
	return alloc_netdev_mqs(sizeof_priv, "eth%d", NET_NAME_UNKNOWN, ether_setup, txqs, rxqs);
}
EXPORT_SYMBOL(alloc_etherdev_mqs);

//net/ethernet/eth.c：372
/**
 * ether_setup - setup Ethernet network device
 * @dev: network device
 *
 * Fill in the fields of the device structure with Ethernet-generic values.
 */
void ether_setup(struct net_device *dev)
{
	dev->header_ops			= &eth_header_ops;
	dev->type				= ARPHRD_ETHER;
	dev->hard_header_len 	= ETH_HLEN;
	dev->min_header_len		= ETH_HLEN;
	dev->mtu				= ETH_DATA_LEN;
	dev->min_mtu			= ETH_MIN_MTU;
	dev->max_mtu			= ETH_DATA_LEN;
	dev->addr_len			= ETH_ALEN;
	dev->tx_queue_len		= DEFAULT_TX_QUEUE_LEN;
	
	dev->flags				= IFF_BROADCAST|IFF_MULTICAST;
	dev->priv_flags			|= IFF_TX_SKB_SHARING;

	eth_broadcast_addr(dev->broadcast);

}
EXPORT_SYMBOL(ether_setup);

/**
 * eth_broadcast_addr - Assign broadcast address
 * @addr: Pointer to a six-byte array containing the Ethernet address
 *
 * Assign the broadcast address to the given address array.
 */
static inline void eth_broadcast_addr(u8 *addr)
{
	memset(addr, 0xff, ETH_ALEN);
}

#endif

#if 1 //register_netdev()

//net/core/dev.c：9200
/**
 *	register_netdev	- register a network device
 *	@dev: device to register
 *
 *	Take a completed network device structure and add it to the kernel
 *	interfaces. A %NETDEV_REGISTER message is sent to the netdev notifier
 *	chain. 0 is returned on success. A negative errno code is returned
 *	on a failure to set up the device, or if the name is a duplicate.
 *
 *	This is a wrapper around register_netdevice that takes the rtnl semaphore
 *	and expands the device name if you passed a format string to
 *	alloc_netdev.
 */
//初始化net_device结构部分字段，特别是对网络设备的各种features等字段进行设置，包括其上下层网络设备
//遍历当前网络设备所属的net结构的所有net_device结构，查看同类设备（如eth）中，未被占用的设备编号，形成完整设备名（如eth1）
//在当前网络设备所属的net结构的dev_index_head哈希表，查找并分配一个未被占用的interface index（ifindex）
//netdev_chain通知链表上发布NETDEV_POST_INIT消息
//将网络设备注册到设备模型中，用户态的/sys/class/net目录下会有该设备目录
//将net_device结构加入到所属net结构的:
//		dev_base_head链表
//		dev_name_head哈希表
//		dev_index_head哈希表
//在netdev_chain通知链发布NETDEV_REGISTER消息
//向rtnetlink发送新的链路出现的消息RTM_NEWLINK
int register_netdev(struct net_device *dev)
{
	int err;

	if (rtnl_lock_killable())
		return -EINTR;
	
	err = register_netdevice(dev);

	rtnl_unlock();

	return err;
}
EXPORT_SYMBOL(register_netdev);

//net/core/dev.c：8991
/**
 *	register_netdevice	- register a network device
 *	@dev: device to register
 *
 *	Take a completed network device structure and add it to the kernel
 *	interfaces. A %NETDEV_REGISTER message is sent to the netdev notifier
 *	chain. 0 is returned on success. A negative errno code is returned
 *	on a failure to set up the device, or if the name is a duplicate.
 *
 *	Callers must hold the rtnl semaphore. You may want
 *	register_netdev() instead of this.
 *
 *	BUGS:
 *	The locking appears insufficient to guarantee two parallel registers
 *	will not get the same name.
 */
int register_netdevice(struct net_device *dev)
{
	int ret;
	struct net *net = dev_net(dev);

	BUILD_BUG_ON(sizeof(netdev_features_t) * BITS_PER_BYTE < NETDEV_FEATURE_COUNT);
	BUG_ON(dev_boot_phase);
	ASSERT_RTNL();

	might_sleep();

	/* When net_device's are persistent, this will be fatal. */
	BUG_ON(dev->reg_state != NETREG_UNINITIALIZED);
	BUG_ON(!net);

	spin_lock_init(&dev->addr_list_lock);
	
	lockdep_set_class(&dev->addr_list_lock, &dev->addr_list_lock_key);

	//该函数遍历net结构的所有net_device结构，查看同类设备（如eth）中，未被占用的设备编号，形成完整设备名（如eth1）
	ret = dev_get_valid_name(net, dev, dev->name);
	if (ret < 0)
		goto out;

	/* Init, if this function is available */
	//pcnet32中未定义该回调函数
	if (dev->netdev_ops->ndo_init) 
	{
		ret = dev->netdev_ops->ndo_init(dev);
		if (ret) 
		{
			if (ret > 0)
				ret = -EIO;
			goto out;
		}
	}

	if (((dev->hw_features | dev->features) & NETIF_F_HW_VLAN_CTAG_FILTER) &&
	    (!dev->netdev_ops->ndo_vlan_rx_add_vid ||!dev->netdev_ops->ndo_vlan_rx_kill_vid)) 
	{
		netdev_WARN(dev, "Buggy VLAN acceleration in driver!\n");
		ret = -EINVAL;
		goto err_uninit;
	}

	ret = -EBUSY;
	
	if (!dev->ifindex)//进入此分支
		//在当前网络设备所属的net结构的dev_index_head哈希表，查找并分配一个未被占用的interface index（ifindex）
		dev->ifindex = dev_new_index(net);	
	else if (__dev_get_by_index(net, dev->ifindex))
		goto err_uninit;

	/* Transfer changeable features to wanted_features and enable
	 * software offloads (GSO and GRO).
	 */
	dev->hw_features |= NETIF_F_SOFT_FEATURES;
	dev->features |= NETIF_F_SOFT_FEATURES;

	//pcnet32未设置
	if (dev->netdev_ops->ndo_udp_tunnel_add) 
	{
		dev->features |= NETIF_F_RX_UDP_TUNNEL_PORT;
		dev->hw_features |= NETIF_F_RX_UDP_TUNNEL_PORT;
	}

	dev->wanted_features = dev->features & dev->hw_features;

	if (!(dev->flags & IFF_LOOPBACK))
		dev->hw_features |= NETIF_F_NOCACHE_COPY;


	/* If IPv4 TCP segmentation offload is supported we should also
	 * allow the device to enable segmenting the frame with the option
	 * of ignoring a static IP ID value.  This doesn't enable the
	 * feature itself but allows the user to enable it later.
	 */
	//pcnet32中未设置NETIF_F_TSO
	if (dev->hw_features & NETIF_F_TSO)
		dev->hw_features |= NETIF_F_TSO_MANGLEID;
	if (dev->vlan_features & NETIF_F_TSO)
		dev->vlan_features |= NETIF_F_TSO_MANGLEID;	
	if (dev->mpls_features & NETIF_F_TSO)
		dev->mpls_features |= NETIF_F_TSO_MANGLEID;	
	if (dev->hw_enc_features & NETIF_F_TSO)
		dev->hw_enc_features |= NETIF_F_TSO_MANGLEID;

	/* Make NETIF_F_HIGHDMA inheritable to VLAN devices.
	 */
	dev->vlan_features |= NETIF_F_HIGHDMA;

	/* Make NETIF_F_SG inheritable to tunnel devices.
	 */
	dev->hw_enc_features |= NETIF_F_SG | NETIF_F_GSO_PARTIAL;

	/* Make NETIF_F_SG inheritable to MPLS.
	 */
	dev->mpls_features |= NETIF_F_SG;

	//netdev_chain通知链表上发布NETDEV_POST_INIT消息
	//通常情况下，此时该通知链上有fib_rules_event、inetdev_event、fib_netdev_event三个回调函数
	//它们对此消息均未做处理
	ret = call_netdevice_notifiers(NETDEV_POST_INIT, dev);

	ret = notifier_to_errno(ret);
	if (ret)
		goto err_uninit;

	//将网络设备注册到设备模型中，用户态的/sys/class/net目录下会有该设备目录
	ret = netdev_register_kobject(dev);
	if (ret)
		goto err_uninit;
	
	dev->reg_state = NETREG_REGISTERED;

	//根据规则更新features字段
	__netdev_update_features(dev);

	/*
	 *	Default initial state at registry is that the
	 *	device is present.
	 */
	set_bit(__LINK_STATE_PRESENT, &dev->state);

	linkwatch_init_dev(dev);

	dev_init_scheduler(dev);

	dev_hold(dev);
	
	//将net_device结构加入到所属net结构的dev_base_head链表中，加入字段是net_device结构的dev_list
	//将net_device结构加入到所属net结构的dev_name_head哈希表中，加入字段是net_device结构的name_hlist
	//将net_device结构加入到所属net结构的dev_index_head哈希表中，加入字段是net_device结构的index_hlist
	list_netdevice(dev);

	//增加设备随机性
	add_device_randomness(dev->dev_addr, dev->addr_len);

	/* If the device has permanent device address, driver should
	 * set dev_addr and also addr_assign_type should be set to
	 * NET_ADDR_PERM (default value).
	 */
	//pcnet32中为0，会执行memcpy
	if (dev->addr_assign_type == NET_ADDR_PERM)
		memcpy(dev->perm_addr, dev->dev_addr, dev->addr_len);

	/* Notify protocols, that a new device appeared. */
	//在netdev_chain通知链发布NETDEV_REGISTER消息
	//该通知链上包括：
	//fib_rules_event()
	//inetdev_event()：该函数中更新了net_device结构的ip_ptr字段（in_device结构），后续分析
	//fib_netdev_event()
	ret = call_netdevice_notifiers(NETDEV_REGISTER, dev);
	ret = notifier_to_errno(ret);
	if (ret) 
	{
		rollback_registered(dev);
		rcu_barrier();

		dev->reg_state = NETREG_UNREGISTERED;
	}
	
	/*
	 *	Prevent userspace races by waiting until the network
	 *	device is fully setup before sending notifications.
	 */
	//pcnet32中dev->rtnl_link_ops=NULL
	//此时向rtnetlink发送新的链路出现的消息RTM_NEWLINK，后续分析
	if (!dev->rtnl_link_ops || dev->rtnl_link_state == RTNL_LINK_INITIALIZED)
		rtmsg_ifinfo(RTM_NEWLINK, dev, ~0U, GFP_KERNEL);

out:
	return ret;

err_uninit:
	if (dev->netdev_ops->ndo_uninit)
		dev->netdev_ops->ndo_uninit(dev);
	if (dev->priv_destructor)
		dev->priv_destructor(dev);
	goto out;
}
EXPORT_SYMBOL(register_netdevice);

//net/core/dev.c:233
/* Device list insertion */
//将net_device结构加入到所属net结构的dev_base_head链表中，加入字段是net_device结构的dev_list
//将net_device结构加入到所属net结构的dev_name_head哈希表中，加入字段是net_device结构的name_hlist
//将net_device结构加入到所属net结构的dev_index_head哈希表中，加入字段是net_device结构的index_hlist
static void list_netdevice(struct net_device *dev)
{
	struct net *net = dev_net(dev);

	ASSERT_RTNL();

	write_lock_bh(&dev_base_lock);

	list_add_tail_rcu(&dev->dev_list, &net->dev_base_head);
	
	hlist_add_head_rcu(&dev->name_hlist, dev_name_hash(net, dev->name));
	
	hlist_add_head_rcu(&dev->index_hlist, dev_index_hash(net, dev->ifindex));
	
	write_unlock_bh(&dev_base_lock);

	dev_base_seq_inc(net);
}

//net/core/dev.c:200
static inline void dev_base_seq_inc(struct net *net)
{
	while (++net->dev_base_seq == 0)
		;
}

//include/linux/netdevice.h:3740
/**
 *	dev_hold - get reference to device
 *	@dev: network device
 *
 * Hold reference to device to keep it from being freed.
 */
static inline void dev_hold(struct net_device *dev)
{
	this_cpu_inc(*dev->pcpu_refcnt);
}

//net/sched/sch_generic.c:1281
void dev_init_scheduler(struct net_device *dev)
{
	dev->qdisc = &noop_qdisc;

	//调用dev_init_scheduler_queue()，传递的参数是dev、dev->_tx[0](pcnet32的唯一一个发送队列)、&noop_qdisc
	netdev_for_each_tx_queue(dev, dev_init_scheduler_queue, &noop_qdisc);	

	//pcnet32中条件判断返回0
	if (dev_ingress_queue(dev))
		dev_init_scheduler_queue(dev, dev_ingress_queue(dev), &noop_qdisc);

	timer_setup(&dev->watchdog_timer, dev_watchdog, 0);
}

//include/linux/rtnetlink.h:83
static inline struct netdev_queue *dev_ingress_queue(struct net_device *dev)
{
	return rtnl_dereference(dev->ingress_queue);
}

//net/sched/sch_generic.c:1271
//参数是dev、dev->_tx[0](pcnet32的唯一一个发送队列)、&noop_qdisc
static void dev_init_scheduler_queue(struct net_device *dev,
				     struct netdev_queue *dev_queue,
				     void *_qdisc)
{
	struct Qdisc *qdisc = _qdisc;

	rcu_assign_pointer(dev_queue->qdisc, qdisc);
	dev_queue->qdisc_sleeping = qdisc;
}

//net/core/link_watch.c:74
void linkwatch_init_dev(struct net_device *dev)
{
	/* Handle pre-registration link state changes */
	//pcnet32中，不会进入if子句
	if (!netif_carrier_ok(dev) || netif_dormant(dev))
		rfc2863_policy(dev);
}

//net/core/dev.c：8689
//根据规则更新features字段
int __netdev_update_features(struct net_device *dev)
{
	struct net_device *upper, *lower;
	netdev_features_t features;
	struct list_head *iter;
	int err = -1;

	ASSERT_RTNL();

	//本环境中，此时为=NETIF_F_SOFT_FEATURES
	features = netdev_get_wanted_features(dev);

	//pcnet32未定义该回调
	if (dev->netdev_ops->ndo_fix_features)
		features = dev->netdev_ops->ndo_fix_features(dev, features);

	/* driver might be less strict about feature dependencies */
	//本环境中，此时为=NETIF_F_GRO
	features = netdev_fix_features(dev, features);

	/* some features can't be enabled if they're off an an upper device */
	//遍历当前net_device结构的所有上层net_device结构
	//若某个上层net_device结构的wanted_features，没有设置features中置1的位，则取消features中的该位
	//pcnet32中并无上层结构
	netdev_for_each_upper_dev_rcu(dev, upper, iter)
		features = netdev_sync_upper_features(dev, upper, features);

	if (dev->features == features)
		goto sync_lower;

	netdev_dbg(dev, "Features changed: %pNF -> %pNF\n", &dev->features, &features);

	//pcnet32未设置该回调
	if (dev->netdev_ops->ndo_set_features)
		err = dev->netdev_ops->ndo_set_features(dev, features);
	else
		err = 0;

	if (unlikely(err < 0)) 
	{
		netdev_err(dev,
			"set_features() failed (%d); wanted %pNF, left %pNF\n",
			err, &features, &dev->features);
		/* return non-0 since some features might have changed and
		 * it's better to fire a spurious notification than miss it
		 */
		return -1;
	}

sync_lower:
	/* some features must be disabled on lower devices when disabled
	 * on an upper device (think: bonding master or bridge)
	 */
	//上层的net_device设备关闭了的标志，下层net_device结构也应该关闭
	//即修改下层的wanted_features字段
	netdev_for_each_lower_dev(dev, lower, iter)
		netdev_sync_lower_features(dev, lower, features);	//递归调用__netdev_update_features

	if (!err) 
	{
		//pcnet32中，标志差异=NETIF_F_GSO
		netdev_features_t diff = features ^ dev->features;
		
		if (diff & NETIF_F_RX_UDP_TUNNEL_PORT) {
			/* udp_tunnel_{get,drop}_rx_info both need
			 * NETIF_F_RX_UDP_TUNNEL_PORT enabled on the
			 * device, or they won't do anything.
			 * Thus we need to update dev->features
			 * *before* calling udp_tunnel_get_rx_info,
			 * but *after* calling udp_tunnel_drop_rx_info.
			 */
			if (features & NETIF_F_RX_UDP_TUNNEL_PORT) {
				dev->features = features;
				udp_tunnel_get_rx_info(dev);
			} else {
				udp_tunnel_drop_rx_info(dev);
			}
		}

		if (diff & NETIF_F_HW_VLAN_CTAG_FILTER) {
			if (features & NETIF_F_HW_VLAN_CTAG_FILTER) {
				dev->features = features;
				err |= vlan_get_rx_ctag_filter_info(dev);
			} else {
				vlan_drop_rx_ctag_filter_info(dev);
			}
		}

		if (diff & NETIF_F_HW_VLAN_STAG_FILTER) {
			if (features & NETIF_F_HW_VLAN_STAG_FILTER) {
				dev->features = features;
				err |= vlan_get_rx_stag_filter_info(dev);
			} else {
				vlan_drop_rx_stag_filter_info(dev);
			}
		}

		//pcnet32中，features = NETIF_F_GRO
		dev->features = features;
	}

	return err < 0 ? 0 : 1;
}

//net/core/dev.c:8588
static void netdev_sync_lower_features(struct net_device *upper,
	struct net_device *lower, netdev_features_t features)
{
	netdev_features_t upper_disables = NETIF_F_UPPER_DISABLES;
	netdev_features_t feature;
	int feature_bit;

	for_each_netdev_feature(upper_disables, feature_bit) 
	{
		feature = __NETIF_F_BIT(feature_bit);
		if (!(features & feature) && (lower->features & feature)) 
		{
			netdev_dbg(upper, "Disabling feature %pNF on lower dev %s.\n", &feature, lower->name);
			
			lower->wanted_features &= ~feature;
			
			netdev_update_features(lower);

			if (unlikely(lower->features & feature))
				netdev_WARN(upper, "failed to disable %pNF on %s!\n",
					    &feature, lower->name);
		}
	}
}

//net/core/dev.c:6790
/**
 * netdev_lower_get_next - Get the next device from the lower neighbour
 *                         list
 * @dev: device
 * @iter: list_head ** of the current position
 *
 * Gets the next netdev_adjacent from the dev's lower neighbour
 * list, starting from iter position. The caller must hold RTNL lock or
 * its own locking that guarantees that the neighbour lower
 * list will remain unchanged.
 */
void *netdev_lower_get_next(struct net_device *dev, struct list_head **iter)
{
	struct netdev_adjacent *lower;

	lower = list_entry(*iter, struct netdev_adjacent, list);

	if (&lower->list == &dev->adj_list.lower)
		return NULL;

	*iter = lower->list.next;

	return lower->dev;
}
EXPORT_SYMBOL(netdev_lower_get_next);

//net/core/dev.c：8789
/**
 *	netdev_update_features - recalculate device features
 *	@dev: the device to check
 *
 *	Recalculate dev->features set and send notifications if it
 *	has changed. Should be called after driver or hardware dependent
 *	conditions might have changed that influence the features.
 */
void netdev_update_features(struct net_device *dev)
{
	if (__netdev_update_features(dev))
		netdev_features_change(dev);
}
EXPORT_SYMBOL(netdev_update_features);


//nclude/linux/netdevice.h:4284
#define netdev_for_each_lower_dev(dev, ldev, iter) \
	for (iter = (dev)->adj_list.lower.next, \
	     ldev = netdev_lower_get_next(dev, &(iter)); \
	     ldev; \
	     ldev = netdev_lower_get_next(dev, &(iter)))


//net/core/dev.c：8568
static netdev_features_t netdev_sync_upper_features(struct net_device *lower,
	struct net_device *upper, netdev_features_t features)
{
	netdev_features_t upper_disables = NETIF_F_UPPER_DISABLES;
	netdev_features_t feature;
	int feature_bit;

	//逐bit
	for_each_netdev_feature(upper_disables, feature_bit) 
	{
		feature = __NETIF_F_BIT(feature_bit);
		if (!(upper->wanted_features & feature) && (features & feature)) 
		{
			netdev_dbg(lower, "Dropping feature %pNF, upper dev %s has it off.\n", &feature, upper->name);
			features &= ~feature;
		}
	}

	return features;
}

//net/core/dev.c:6557
/**
 * netdev_upper_get_next_dev_rcu - Get the next dev from upper list
 * @dev: device
 * @iter: list_head ** of the current position
 *
 * Gets the next device from the dev's upper list, starting from iter
 * position. The caller must hold RCU read lock.
 */
struct net_device *netdev_upper_get_next_dev_rcu(struct net_device *dev,
						 struct list_head **iter)
{
	struct netdev_adjacent *upper;

	WARN_ON_ONCE(!rcu_read_lock_held() && !lockdep_rtnl_is_held());

	upper = list_entry_rcu((*iter)->next, struct netdev_adjacent, list);

	if (&upper->list == &dev->adj_list.upper)
		return NULL;

	*iter = &upper->list;

	return upper->dev;
}
EXPORT_SYMBOL(netdev_upper_get_next_dev_rcu);

//include/linux/netdevice.h：4248
/* iterate through upper list, must be called under RCU read lock */
////遍历当前net_device结构的所有上层net_device结构
#define netdev_for_each_upper_dev_rcu(dev, updev, iter) \
	for (iter = &(dev)->adj_list.upper, \
	     updev = netdev_upper_get_next_dev_rcu(dev, &(iter)); \
	     updev; \
	     updev = netdev_upper_get_next_dev_rcu(dev, &(iter)))

//net/core/dev.c：8610
static netdev_features_t netdev_fix_features(struct net_device *dev,
	netdev_features_t features)
{
	/* Fix illegal checksum combinations */
	if ((features & NETIF_F_HW_CSUM) &&
	    (features & (NETIF_F_IP_CSUM|NETIF_F_IPV6_CSUM))) {
		netdev_warn(dev, "mixed HW and IP checksum settings.\n");
		features &= ~(NETIF_F_IP_CSUM|NETIF_F_IPV6_CSUM);
	}

	/* TSO requires that SG is present as well. */
	if ((features & NETIF_F_ALL_TSO) && !(features & NETIF_F_SG)) {
		netdev_dbg(dev, "Dropping TSO features since no SG feature.\n");
		features &= ~NETIF_F_ALL_TSO;
	}

	if ((features & NETIF_F_TSO) && !(features & NETIF_F_HW_CSUM) &&
					!(features & NETIF_F_IP_CSUM)) {
		netdev_dbg(dev, "Dropping TSO features since no CSUM feature.\n");
		features &= ~NETIF_F_TSO;
		features &= ~NETIF_F_TSO_ECN;
	}

	if ((features & NETIF_F_TSO6) && !(features & NETIF_F_HW_CSUM) &&
					 !(features & NETIF_F_IPV6_CSUM)) {
		netdev_dbg(dev, "Dropping TSO6 features since no CSUM feature.\n");
		features &= ~NETIF_F_TSO6;
	}

	/* TSO with IPv4 ID mangling requires IPv4 TSO be enabled */
	if ((features & NETIF_F_TSO_MANGLEID) && !(features & NETIF_F_TSO))
		features &= ~NETIF_F_TSO_MANGLEID;

	/* TSO ECN requires that TSO is present as well. */
	if ((features & NETIF_F_ALL_TSO) == NETIF_F_TSO_ECN)
		features &= ~NETIF_F_TSO_ECN;

	/* Software GSO depends on SG. */
	if ((features & NETIF_F_GSO) && !(features & NETIF_F_SG)) 
	{
		netdev_dbg(dev, "Dropping NETIF_F_GSO since no SG feature.\n");
		features &= ~NETIF_F_GSO;
	}

	/* GSO partial features require GSO partial be set */
	if ((features & dev->gso_partial_features) &&
	    !(features & NETIF_F_GSO_PARTIAL)) {
		netdev_dbg(dev,
			   "Dropping partially supported GSO features since no GSO partial.\n");
		features &= ~dev->gso_partial_features;
	}

	if (!(features & NETIF_F_RXCSUM)) 
	{
		/* NETIF_F_GRO_HW implies doing RXCSUM since every packet
		 * successfully merged by hardware must also have the
		 * checksum verified by hardware.  If the user does not
		 * want to enable RXCSUM, logically, we should disable GRO_HW.
		 */
		if (features & NETIF_F_GRO_HW) 
		{
			netdev_dbg(dev, "Dropping NETIF_F_GRO_HW since no RXCSUM feature.\n");
			features &= ~NETIF_F_GRO_HW;
		}
	}

	/* LRO/HW-GRO features cannot be combined with RX-FCS */
	if (features & NETIF_F_RXFCS) {
		if (features & NETIF_F_LRO) {
			netdev_dbg(dev, "Dropping LRO feature since RX-FCS is requested.\n");
			features &= ~NETIF_F_LRO;
		}

		if (features & NETIF_F_GRO_HW) {
			netdev_dbg(dev, "Dropping HW-GRO feature since RX-FCS is requested.\n");
			features &= ~NETIF_F_GRO_HW;
		}
	}

	return features;
}


//include/linux/netdevice.h:4468
static inline netdev_features_t netdev_get_wanted_features(struct net_device *dev)
{
	return (dev->features & ~dev->hw_features) | dev->wanted_features;
}


//net/core/net-sysfs.c：1719
/* Create sysfs entries for network device. */
int netdev_register_kobject(struct net_device *ndev)
{
	struct device *dev = &ndev->dev;
	const struct attribute_group **groups = ndev->sysfs_groups;
	int error = 0;

	device_initialize(dev);

	dev->class = &net_class;
	dev->platform_data = ndev;
	dev->groups = groups;

	dev_set_name(dev, "%s", ndev->name);

	/* Allow for a device specific group */
	if (*groups)
		groups++;

	*groups++ = &netstat_group;

	//此时为0
	if (ndev->ieee80211_ptr)
		*groups++ = &wireless_group;
	else if (ndev->wireless_handlers)	//此时为0
		*groups++ = &wireless_group;

	error = device_add(dev);
	if (error)
		return error;

	error = register_queue_kobjects(ndev);
	if (error) {
		device_del(dev);
		return error;
	}

	pm_runtime_set_memalloc_noio(dev, true);

	return error;
}

//drivers/base/core.c:1697
/**
 * device_initialize - init device structure.
 * @dev: device.
 *
 * This prepares the device for use by other layers by initializing
 * its fields.
 * It is the first half of device_register(), if called by
 * that function, though it can also be called separately, so one
 * may use @dev's fields. In particular, get_device()/put_device()
 * may be used for reference counting of @dev after calling this
 * function.
 *
 * All fields in @dev must be initialized by the caller to 0, except
 * for those explicitly set to some other value.  The simplest
 * approach is to use kzalloc() to allocate the structure containing
 * @dev.
 *
 * NOTE: Use put_device() to give up your reference instead of freeing
 * @dev directly once you have called this function.
 */
void device_initialize(struct device *dev)
{
	dev->kobj.kset = devices_kset;
	
	kobject_init(&dev->kobj, &device_ktype);
	
	INIT_LIST_HEAD(&dev->dma_pools);
	
	mutex_init(&dev->mutex);
	
	lockdep_set_novalidate_class(&dev->mutex);
	
	spin_lock_init(&dev->devres_lock);
	
	INIT_LIST_HEAD(&dev->devres_head);
	
	device_pm_init(dev);
	
	set_dev_node(dev, -1);
	
	INIT_LIST_HEAD(&dev->msi_list);
	INIT_LIST_HEAD(&dev->links.consumers);
	INIT_LIST_HEAD(&dev->links.suppliers);
	dev->links.status = DL_DEV_NO_DRIVER;
}
EXPORT_SYMBOL_GPL(device_initialize);

//net/core/dev.c：8449
/**
 *	dev_new_index	-	allocate an ifindex
 *	@net: the applicable net namespace
 *
 *	Returns a suitable unique value for a new device interface
 *	number.  The caller must hold the rtnl semaphore or the
 *	dev_base_lock to be sure it remains unique.
 */
//在当前网络设备所属的net结构的dev_index_head哈希表，查找并分配一个未被占用的interface index（ifindex）
static int dev_new_index(struct net *net)
{
	int ifindex = net->ifindex;

	for (;;) 
	{
		if (++ifindex <= 0)
			ifindex = 1;

		//在net结构的dev_index_head哈希表中查找ifindex
		//若找到返回对应denet_device结构指针，否则返回NULL
		if (!__dev_get_by_index(net, ifindex))
			return net->ifindex = ifindex;
	}
}

/**
 *	__dev_get_by_index - find a device by its ifindex
 *	@net: the applicable net namespace
 *	@ifindex: index of device
 *
 *	Search for an interface by index. Returns %NULL if the device
 *	is not found or a pointer to the device. The device has not
 *	had its reference counter increased so the caller must be careful
 *	about locking. The caller must hold either the RTNL semaphore
 *	or @dev_base_lock.
 */
//在net结构的dev_index_head哈希表中查找ifindex
//若找到返回对应denet_device结构指针，否则返回NULL
struct net_device *__dev_get_by_index(struct net *net, int ifindex)
{
	struct net_device *dev;
	struct hlist_head *head = dev_index_hash(net, ifindex);

	hlist_for_each_entry(dev, head, index_hlist)
		if (dev->ifindex == ifindex)
			return dev;

	return NULL;
}
EXPORT_SYMBOL(__dev_get_by_index);

//net/core/dev.c：213
static inline struct hlist_head *dev_index_hash(struct net *net, int ifindex)
{
	return &net->dev_index_head[ifindex & (NETDEV_HASHENTRIES - 1)];
}

//net/core/dev.c：1063
//该函数遍历net结构的所有net_device结构，查看同类设备（如eth）中，未被占用的设备编号，形成完整设备名（如eth1）
int dev_get_valid_name(struct net *net, struct net_device *dev, const char *name)
{
	BUG_ON(!net);

	if (!dev_valid_name(name))
		return -EINVAL;

	if (strchr(name, '%'))//进入此分支
		return dev_alloc_name_ns(net, dev, name);
	else if (__dev_get_by_name(net, name))
		return -EEXIST;
	else if (dev->name != name)
		strlcpy(dev->name, name, IFNAMSIZ);

	return 0;
}
EXPORT_SYMBOL(dev_get_valid_name);

//net/core/dev.c：1029
static int dev_alloc_name_ns(struct net *net, struct net_device *dev, const char *name)
{
	char buf[IFNAMSIZ];
	int ret;

	BUG_ON(!net);

	//该函数遍历net结构的所有net_device结构，查看同类设备（如eth）中，未被占用的设备编号并返回	
	//buf中保存新的完整的设备名：如"eth1"
	ret = __dev_alloc_name(net, name, buf);

	if (ret >= 0)
		strlcpy(dev->name, buf, IFNAMSIZ);
	
	return ret;
}

//net/core/dev.c：976
/**
 *	__dev_alloc_name - allocate a name for a device
 *	@net: network namespace to allocate the device name in
 *	@name: name format string
 *	@buf:  scratch buffer and result name string
 *
 *	Passed a format string - eg "lt%d" it will try and find a suitable
 *	id. It scans list of devices to build up a free map, then chooses
 *	the first empty slot. The caller must hold the dev_base or rtnl lock
 *	while allocating the name and adding the device in order to avoid
 *	duplicates.
 *	Limited to bits_per_byte * page size devices (ie 32K on most platforms).
 *	Returns the number of the unit assigned or a negative errno code.
 */
//name如："eth%d"
//该函数遍历net结构的所有net_device结构，查看同类设备（如eth）中，未被占用的设备编号并返回
//buf中保存新的完整的设备名：如"eth1"
static int __dev_alloc_name(struct net *net, const char *name, char *buf)
{
	int i = 0;
	const char *p;
	const int max_netdevices = 8*PAGE_SIZE;
	unsigned long *inuse;
	struct net_device *d;

	if (!dev_valid_name(name))
		return -EINVAL;

	p = strchr(name, '%');
	if (p) 
	{
		/*
		 * Verify the string as this thing may have come from
		 * the user.  There must be either one "%d" and no other "%"
		 * characters.
		 */
		if (p[1] != 'd' || strchr(p + 2, '%'))
			return -EINVAL;

		/* Use one page as a bit array of possible slots */
		inuse = (unsigned long *) get_zeroed_page(GFP_ATOMIC);
		if (!inuse)
			return -ENOMEM;

		//遍历所属net结构的所有net_device结构
		//链表头是net结构的dev_base_head字段
		//inuse是一个位向量，每一个位的索引对应一个设备编号
		//某位为1，表示该位对应的设备编号被占用
		//下面的循环，即分析当前name的类型（如eth），哪些设备编号被占用了
		//即设置inuse位向量
		for_each_netdev(net, d) 
		{
			//判断前缀是否是符合要求，比如是否是"eth"
			if (!sscanf(d->name, name, &i))
				continue;
			
			if (i < 0 || i >= max_netdevices)
				continue;

			/*  avoid cases where sscanf is not exact inverse of printf */
			snprintf(buf, IFNAMSIZ, name, i);
			
			if (!strncmp(buf, d->name, IFNAMSIZ))
				set_bit(i, inuse);
		}

		//i即没有占用的第一个设备编号
		i = find_first_zero_bit(inuse, max_netdevices);
		free_page((unsigned long) inuse);
	}

	snprintf(buf, IFNAMSIZ, name, i);

	//检测新计算出来的名称，是否已经被占用
	//若未被占用，此处返回i，即未占用的设备编号
	if (!__dev_get_by_name(net, buf))
		return i;

	/* It is possible to run out of possible slots
	 * when the name is long and there isn't enough space left
	 * for the digits, or if all bits are used.
	 */
	return -ENFILE;
}

//net/core/dev.c：653
/**
 *	__dev_get_by_name	- find a device by its name
 *	@net: the applicable net namespace
 *	@name: name to find
 *
 *	Find an interface by name. Must be called under RTNL semaphore
 *	or @dev_base_lock. If the name is found a pointer to the device
 *	is returned. If the name is not found then %NULL is returned. The
 *	reference counters are not incremented so the caller must be
 *	careful with locks.
 */
//在哈希表net->dev_name_head中搜索name，若找到返回对应的net_device结构，否则返回NULL
struct net_device *__dev_get_by_name(struct net *net, const char *name)
{
	struct net_device *dev;
	struct hlist_head *head = dev_name_hash(net, name);

	hlist_for_each_entry(dev, head, name_hlist)
		if (!strncmp(dev->name, name, IFNAMSIZ))
			return dev;

	return NULL;
}
EXPORT_SYMBOL(__dev_get_by_name);

//net/core/dev.c：206
static inline struct hlist_head *dev_name_hash(struct net *net, const char *name)
{
	unsigned int hash = full_name_hash(net, name, strnlen(name, IFNAMSIZ));

	return &net->dev_name_head[hash_32(hash, NETDEV_HASHBITS)];
}

//fs/namei.c：1928
/*
 * Return the hash of a string of known length.  This is carfully
 * designed to match hash_name(), which is the more critical function.
 * In particular, we must end by hashing a final word containing 0..7
 * payload bytes, to match the way that hash_name() iterates until it
 * finds the delimiter after the name.
 */
unsigned int full_name_hash(const void *salt, const char *name, unsigned int len)
{
	unsigned long a, x = 0, y = (unsigned long)salt;

	for (;;) {
		if (!len)
			goto done;
		a = load_unaligned_zeropad(name);
		if (len < sizeof(unsigned long))
			break;
		HASH_MIX(x, y, a);
		name += sizeof(unsigned long);
		len -= sizeof(unsigned long);
	}
	x ^= a & bytemask_from_count(len);
done:
	return fold_hash(x, y);
}
EXPORT_SYMBOL(full_name_hash);


//net/core/dev.c：943
/**
 *	dev_valid_name - check if name is okay for network device
 *	@name: name string
 *
 *	Network device names need to be valid file names to
 *	to allow sysfs to work.  We also disallow any kind of
 *	whitespace.
 */
bool dev_valid_name(const char *name)
{
	if (*name == '\0')
		return false;
	
	if (strnlen(name, IFNAMSIZ) == IFNAMSIZ)
		return false;
		
	if (!strcmp(name, ".") || !strcmp(name, ".."))
		return false;

	while (*name) 
	{
		if (*name == '/' || *name == ':' || isspace(*name))
			return false;
		name++;
	}
	return true;
}
EXPORT_SYMBOL(dev_valid_name);

#endif

#if 1 //unregister_netdev()

//net/core/dev.c:9694
/**
 *	unregister_netdev - remove device from the kernel
 *	@dev: device
 *
 *	This function shuts down a device interface and removes it
 *	from the kernel tables.
 *
 *	This is just a wrapper for unregister_netdevice that takes
 *	the rtnl semaphore.  In general you want to use this and not
 *	unregister_netdevice.
 */
void unregister_netdev(struct net_device *dev)
{
	rtnl_lock();

	//pcnet32测试中，将net_device结构加入到链表net_todo_list中
	unregister_netdevice(dev);

	//内部在通知链netdev_chain上发布消息NETDEV_UNREGISTER
	//删除设备
	rtnl_unlock();
}
EXPORT_SYMBOL(unregister_netdev);

//net/core/rtnetlink.c:109
void rtnl_unlock(void)
{
	/* This fellow will unlock it for us. */
	netdev_run_todo();
}
EXPORT_SYMBOL(rtnl_unlock);

//net/core/dev.c:9307
/* The sequence is:
 *
 *	rtnl_lock();
 *	...
 *	register_netdevice(x1);
 *	register_netdevice(x2);
 *	...
 *	unregister_netdevice(y1);
 *	unregister_netdevice(y2);
 *      ...
 *	rtnl_unlock();
 *	free_netdev(y1);
 *	free_netdev(y2);
 *
 * We are invoked by rtnl_unlock().
 * This allows us to deal with problems:
 * 1) We can delete sysfs objects which invoke hotplug
 *    without deadlocking with linkwatch via keventd.
 * 2) Since we run with the RTNL semaphore not held, we can sleep
 *    safely in order to wait for the netdev refcnt to drop to zero.
 *
 * We must not return until all unregister events added during
 * the interval the lock was held have been completed.
 */
void netdev_run_todo(void)
{
	struct list_head list;

	/* Snapshot list, allow later requests */
	//将net_todo_list链表中要unregister的设备，移动到list中
	//之后即可解锁，不影响其他进程对net_todo_list的操作
	list_replace_init(&net_todo_list, &list);

	__rtnl_unlock();

	/* Wait for rcu callbacks to finish before next phase */
	if (!list_empty(&list))
		rcu_barrier();

	while (!list_empty(&list)) 
	{
		struct net_device *dev = list_first_entry(&list, struct net_device, todo_list);
		list_del(&dev->todo_list);

		if (unlikely(dev->reg_state != NETREG_UNREGISTERING)) 
		{
			pr_err("network todo '%s' but state %d\n",
			       dev->name, dev->reg_state);
			dump_stack();
			continue;
		}

		dev->reg_state = NETREG_UNREGISTERED;

		//等待对该设备的所有引用都释放
		//内部在通知链netdev_chain上发布消息NETDEV_UNREGISTER
		netdev_wait_allrefs(dev);

		/* paranoia */
		BUG_ON(netdev_refcnt_read(dev));
		BUG_ON(!list_empty(&dev->ptype_all));
		BUG_ON(!list_empty(&dev->ptype_specific));
		WARN_ON(rcu_access_pointer(dev->ip_ptr));
		WARN_ON(rcu_access_pointer(dev->ip6_ptr));
#if IS_ENABLED(CONFIG_DECNET)
		WARN_ON(dev->dn_ptr);
#endif
		if (dev->priv_destructor)
			dev->priv_destructor(dev);
		
		if (dev->needs_free_netdev)
			free_netdev(dev);

		/* Report a network device has been unregistered */
		rtnl_lock();
		dev_net(dev)->dev_unreg_count--;
		__rtnl_unlock();
		
		wake_up(&netdev_unregistering_wq);

		/* Free network device */
		kobject_put(&dev->dev.kobj);
	}
}

//include/linux/netdevice.h:2635
static inline void unregister_netdevice(struct net_device *dev)
{
	unregister_netdevice_queue(dev, NULL);
}

//net/core/dev.c:9649
/**
 *	unregister_netdevice_queue - remove device from the kernel
 *	@dev: device
 *	@head: list
 *
 *	This function shuts down a device interface and removes it
 *	from the kernel tables.
 *	If head not NULL, device is queued to be unregistered later.
 *
 *	Callers must hold the rtnl semaphore.  You may want
 *	unregister_netdev() instead of this.
 */
void unregister_netdevice_queue(struct net_device *dev, struct list_head *head)
{
	ASSERT_RTNL();

	if (head) 
	{
		list_move_tail(&dev->unreg_list, head);
	} 
	else 
	{
		rollback_registered(dev);
		
		/* Finish processing unregister after unlock */
		net_set_todo(dev);
	}
}
EXPORT_SYMBOL(unregister_netdevice_queue);

//net/core/dev.c:8462
/* Delayed registration/unregisteration */
//static LIST_HEAD(net_todo_list);
static struct list_head net_todo_list;

//net/core/dev.c:8465
static void net_set_todo(struct net_device *dev)
{
	list_add_tail(&dev->todo_list, &net_todo_list);
	dev_net(dev)->dev_unreg_count++;
}

//net/core/dev.c:8559
static void rollback_registered(struct net_device *dev)
{
	LIST_HEAD(single);

	//将dev->unreg_list链表，加入到single链表中
	//pcnet32测试情况下dev->unreg_list为空
	list_add(&dev->unreg_list, &single);

	//pcnet32测试情况下single为空
	rollback_registered_many(&single);
	
	list_del(&single);
}

//net/core/dev.c:8471
static void rollback_registered_many(struct list_head *head)
{
	struct net_device *dev, *tmp;
	LIST_HEAD(close_head);

	BUG_ON(dev_boot_phase);
	ASSERT_RTNL();

	list_for_each_entry_safe(dev, tmp, head, unreg_list) 
	{
		/* Some devices call without registering
		 * for initialization unwind. Remove those
		 * devices and proceed with the remaining.
		 */
		if (dev->reg_state == NETREG_UNINITIALIZED) 
		{
			pr_debug("unregister_netdevice: device %s/%p never was registered\n", dev->name, dev);

			WARN_ON(1);
			list_del(&dev->unreg_list);
			continue;
		}
		
		dev->dismantle = true;

		BUG_ON(dev->reg_state != NETREG_REGISTERED);
	}

	/* If device is running, close it first. */
	//pcnet32测试情况下，dev->close_list为空
	list_for_each_entry(dev, head, unreg_list)
		list_add_tail(&dev->close_list, &close_head);
	
	dev_close_many(&close_head, true);

	list_for_each_entry(dev, head, unreg_list) 
	{
		/* And unlink it from device chain. */
		unlist_netdevice(dev);

		dev->reg_state = NETREG_UNREGISTERING;
	}
	
	flush_all_backlogs();


	

	synchronize_net();

	list_for_each_entry(dev, head, unreg_list) 
	{
		struct sk_buff *skb = NULL;

		/* Shutdown queueing discipline. */
		dev_shutdown(dev);

		dev_xdp_uninstall(dev);

		/* Notify protocols, that we are about to destroy
		 * this device. They should clean all the things.
		 */
		call_netdevice_notifiers(NETDEV_UNREGISTER, dev);

		if (!dev->rtnl_link_ops ||
		    dev->rtnl_link_state == RTNL_LINK_INITIALIZED)
			skb = rtmsg_ifinfo_build_skb(RTM_DELLINK, dev, ~0U, 0,
						     GFP_KERNEL, NULL, 0);

		/*
		 *	Flush the unicast and multicast chains
		 */
		dev_uc_flush(dev);
		dev_mc_flush(dev);

		if (dev->netdev_ops->ndo_uninit)
			dev->netdev_ops->ndo_uninit(dev);

		if (skb)
			rtmsg_ifinfo_send(skb, dev, GFP_KERNEL);

		/* Notifier chain MUST detach us all upper devices. */
		WARN_ON(netdev_has_any_upper_dev(dev));
		WARN_ON(netdev_has_any_lower_dev(dev));

		/* Remove entries from kobject tree */
		netdev_unregister_kobject(dev);
#ifdef CONFIG_XPS
		/* Remove XPS queueing entries */
		netif_reset_xps_queues_gt(dev, 0);
#endif
	}

	synchronize_net();

	list_for_each_entry(dev, head, unreg_list)
		dev_put(dev);
}

/**
 * list_move_tail - delete from one list and add as another's tail
 * @list: the entry to move
 * @head: the head that will follow our entry
 */
//从list所在的链表中删除list，然后将head加入该链表末尾
static inline void list_move_tail(struct list_head *list, struct list_head *head)
{
	__list_del_entry(list);
	list_add_tail(list, head);
}

#endif

#if 1 //dev_open()

//net/core/dev.c:1353
/**
 *	dev_open	- prepare an interface for use.
 *	@dev: device to open
 *	@extack: netlink extended ack
 *
 *	Takes a device from down to up state. The device's private open
 *	function is invoked and then the multicast lists are loaded. Finally
 *	the device is moved into the up state and a %NETDEV_UP message is
 *	sent to the netdev notifier chain.
 *
 *	Calling this function on an active interface is a nop. On a failure
 *	a negative errno code is returned.
 */
/*
1、在netdev_chain通知链上发布NETDEV_PRE_UP消息
2、调用ndo_validate_addr回调函数，检测MAC地址是否合法
3、调用ndo_open回调函数
4、调用ndo_set_rx_mode回调函数，设置接收模式等（比如混杂模式）
5、设置网卡层次的流控机制，即队列排队规则，默认使用pfifo_fast_ops排队规则
6、设置传输超时定时器
7、向rtnetlink发送链路IFF_UP|IFF_RUNNING消息
8、向netdev_chain通知链，发布消息NETDEV_UP
*/
int dev_open(struct net_device *dev, struct netlink_ext_ack *extack)
{
	int ret;

	if (dev->flags & IFF_UP)
		return 0;

	ret = __dev_open(dev, extack);
	if (ret < 0)
		return ret;

	//此时向rtnetlink发送链路IFF_UP|IFF_RUNNING消息，后续分析
	rtmsg_ifinfo(RTM_NEWLINK, dev, IFF_UP|IFF_RUNNING, GFP_KERNEL);

	//向netdev_chain通知链，发布消息NETDEV_UP
	call_netdevice_notifiers(NETDEV_UP, dev);

	return ret;
}
EXPORT_SYMBOL(dev_open);

//net/core/dev.c:1297
static int __dev_open(struct net_device *dev, struct netlink_ext_ack *extack)
{
	const struct net_device_ops *ops = dev->netdev_ops;
	int ret;

	ASSERT_RTNL();

	if (!netif_device_present(dev))
		return -ENODEV;

	/* Block netpoll from trying to do any rx path servicing.
	 * If we don't do this there is a chance ndo_poll_controller
	 * or ndo_poll may be running while we open the device
	 */
	netpoll_poll_disable(dev);

	//目前情况来看，当前netdev_chain通知链上的回调函数，不对该消息感兴趣
	ret = call_netdevice_notifiers_extack(NETDEV_PRE_UP, dev, extack);
	ret = notifier_to_errno(ret);
	if (ret)
		return ret;

	set_bit(__LINK_STATE_START, &dev->state);

	//pcnet32中，该回调设置成了eth_validate_addr()，即调用该函数
	if (ops->ndo_validate_addr)
		ret = ops->ndo_validate_addr(dev);

	if (!ret && ops->ndo_open)
		ret = ops->ndo_open(dev);

	netpoll_poll_enable(dev);

	if (ret)
		clear_bit(__LINK_STATE_START, &dev->state);
	else 
	{
		dev->flags |= IFF_UP;

		//调用ndo_set_rx_mode回调函数，设置接收模式等（比如混杂模式）		
		dev_set_rx_mode(dev);

		dev_activate(dev);

		add_device_randomness(dev->dev_addr, dev->addr_len);
	}

	return ret;
}

//net/sched/sch_generic.c:1096
//设置网卡层次的流控机制，即队列排队规则，默认使用pfifo_fast_ops排队规则
//设置传输超时定时器
void dev_activate(struct net_device *dev)
{
	int need_watchdog;

	/* No queueing discipline is attached to device;
	 * create default one for devices, which need queueing
	 * and noqueue_qdisc for virtual interfaces
	 */

	if (dev->qdisc == &noop_qdisc)
	{
		//初始化net_device._tx[0].qdisc_sleeping，使用pfifo_fast_ops排队规则
		attach_default_qdiscs(dev);
	}

	if (!netif_carrier_ok(dev))
		/* Delay activation until next carrier-on event */
		return;

	need_watchdog = 0;

	//导致调用transition_one_qdisc()
	netdev_for_each_tx_queue(dev, transition_one_qdisc, &need_watchdog);

	//pcnet32测试条件返回0
	if (dev_ingress_queue(dev))
		transition_one_qdisc(dev, dev_ingress_queue(dev), NULL);

	if (need_watchdog) 
	{
		netif_trans_update(dev);

		//设置传输超时定时器
		dev_watchdog_up(dev);
	}
}
EXPORT_SYMBOL(dev_activate);

//net/sched/sch_generic.c:473
static void dev_watchdog_up(struct net_device *dev)
{
	__netdev_watchdog_up(dev);
}

//net/sched/sch_generic.c:462
void __netdev_watchdog_up(struct net_device *dev)
{
	//pcnet32设为pcnet32_tx_timeout
	if (dev->netdev_ops->ndo_tx_timeout) 
	{
		if (dev->watchdog_timeo <= 0)
			dev->watchdog_timeo = 5*HZ;
		
		if (!mod_timer(&dev->watchdog_timer, round_jiffies(jiffies + dev->watchdog_timeo)))
			dev_hold(dev);
	}
}

//include/linux/netdevice.h:3945
/* legacy drivers only, netdev_start_xmit() sets txq->trans_start */
static inline void netif_trans_update(struct net_device *dev)
{
	struct netdev_queue *txq = netdev_get_tx_queue(dev, 0);

	if (txq->trans_start != jiffies)
		txq->trans_start = jiffies;
}

//net/sched/sch_generic.c:1079
static void transition_one_qdisc(struct net_device *dev,
				 struct netdev_queue *dev_queue,
				 void *_need_watchdog)
{
	struct Qdisc *new_qdisc = dev_queue->qdisc_sleeping;
	
	int *need_watchdog_p = _need_watchdog;

	if (!(new_qdisc->flags & TCQ_F_BUILTIN))
		clear_bit(__QDISC_STATE_DEACTIVATED, &new_qdisc->state);

	rcu_assign_pointer(dev_queue->qdisc, new_qdisc);
	
	if (need_watchdog_p) 
	{
		dev_queue->trans_start = 0;
		*need_watchdog_p = 1;
	}
}

//net/core/dev.c:7806
void dev_set(struct net_device *dev)
{
	netif_addr_lock_bh(dev);
	
	__dev_set_rx_mode(dev);
	
	netif_addr_unlock_bh(dev);
}

//net/core/dev.c:7778
/*
 *	Upload unicast and multicast address lists to device and
 *	configure RX filtering. When the device doesn't support unicast
 *	filtering it is put in promiscuous mode while unicast addresses
 *	are present.
 */
//调用ndo_set_rx_mode回调函数，设置接收模式等（比如混杂模式）
void __dev_set_rx_mode(struct net_device *dev)
{
	const struct net_device_ops *ops = dev->netdev_ops;

	/* dev_open will call this function so the list will stay sane. */
	if (!(dev->flags & IFF_UP))
		return;

	if (!netif_device_present(dev))
		return;

	if (!(dev->priv_flags & IFF_UNICAST_FLT)) 
	{
		/* Unicast addresses changes may only happen under the rtnl,
		 * therefore calling __dev_set_promiscuity here is safe.
		 */
		if (!netdev_uc_empty(dev) && !dev->uc_promisc) 
		{
			__dev_set_promiscuity(dev, 1, false);
			dev->uc_promisc = true;
		} 
		else if (netdev_uc_empty(dev) && dev->uc_promisc) 
		{
			__dev_set_promiscuity(dev, -1, false);
			dev->uc_promisc = false;
		}
	}

	if (ops->ndo_set_rx_mode)
		ops->ndo_set_rx_mode(dev);
}

//net/core/netpoll.c:214
void netpoll_poll_enable(struct net_device *dev)
{
	struct netpoll_info *ni;
	rcu_read_lock();
	ni = rcu_dereference(dev->npinfo);
	if (ni)
		up(&ni->dev_lock);
	rcu_read_unlock();
}
EXPORT_SYMBOL(netpoll_poll_enable);

//include/linux/netdevice.h:512
/**
 *	napi_enable - enable NAPI scheduling
 *	@n: NAPI context
 *
 * Resume NAPI from being scheduled on this context.
 * Must be paired with napi_disable.
 */
static inline void napi_enable(struct napi_struct *n)
{
	BUG_ON(!test_bit(NAPI_STATE_SCHED, &n->state));
	
	smp_mb__before_atomic();
	
	clear_bit(NAPI_STATE_SCHED, &n->state);
	clear_bit(NAPI_STATE_NPSVC, &n->state);
}

//include/linux/netdevice.h:3078
/**
 *	netif_start_queue - allow transmit
 *	@dev: network device
 *
 *	Allow upper layers to call the device hard_start_xmit routine.
 */
static inline void netif_start_queue(struct net_device *dev)
{
	netif_tx_start_queue(netdev_get_tx_queue(dev, 0));
}

//include/linux/netdevice.h:3067
static __always_inline void netif_tx_start_queue(struct netdev_queue *dev_queue)
{
	clear_bit(__QUEUE_STATE_DRV_XOFF, &dev_queue->state);
}

//include/linux/netdevice.h:2112
static inline struct netdev_queue *netdev_get_tx_queue(const struct net_device *dev,
					 unsigned int index)
{
	return &dev->_tx[index];
}

//net/ethernet/eth.c:349
int eth_validate_addr(struct net_device *dev)
{
	if (!is_valid_ether_addr(dev->dev_addr))
		return -EADDRNOTAVAIL;

	return 0;
}
EXPORT_SYMBOL(eth_validate_addr);

//include/linux/etherdevice.h:191
/**
 * is_valid_ether_addr - Determine if the given Ethernet address is valid
 * @addr: Pointer to a six-byte array containing the Ethernet address
 *
 * Check that the Ethernet address (MAC) is not 00:00:00:00:00:00, is not
 * a multicast address, and is not FF:FF:FF:FF:FF:FF.
 *
 * Return true if the address is valid.
 *
 * Please note: addr must be aligned to u16.
 */
static inline bool is_valid_ether_addr(const u8 *addr)
{
	/* FF:FF:FF:FF:FF:FF is a multicast address so we don't need to
	 * explicitly check for it here. */
	return !is_multicast_ether_addr(addr) && !is_zero_ether_addr(addr);
}

//include/linux/etherdevice.h:98
/**
 * is_zero_ether_addr - Determine if give Ethernet address is all zeros.
 * @addr: Pointer to a six-byte array containing the Ethernet address
 *
 * Return true if the address is all zeroes.
 *
 * Please note: addr must be aligned to u16.
 */
static inline bool is_zero_ether_addr(const u8 *addr)
{
	return ((*(const u32 *)addr) | (*(const u16 *)(addr + 4))) == 0;
}

//include/linux/etherdevice.h:116
/**
 * is_multicast_ether_addr - Determine if the Ethernet address is a multicast.
 * @addr: Pointer to a six-byte array containing the Ethernet address
 *
 * Return true if the address is a multicast address.
 * By definition the broadcast address is also a multicast address.
 */
static inline bool is_multicast_ether_addr(const u8 *addr)
{
	u32 a = *(const u32 *)addr;

	return 0x01 & a;
}

#endif

#if 1 //链路状态检测与通知netif_carrier_on和netif_carrier_off

/*
 * 网络设备链路状态改变的事件的检测：
 * 		网卡驱动程序负责读取网卡设备I/O端口，获取当前链路状态，如链路是否断开
 *		网卡驱动程序再结合net_device结构的state字段，判断网络设备链路状态改变的具体事件
 * 		具体事件，比如从有载波（信号）到无载波，或者反过来
 *
 * 网络设备链路状态改变的事件的传递：
 * 		当网卡驱动程序检测到上述事件后，将会调用netif_carrier_on或netif_carrier_off函数，发出通知
 * 		netif_carrier_off针对从有载波（信号）到无载波，而netif_carrier_on则反过来
 *
 * netif_carrier_on和netif_carrier_off中的处理：
 *		产生事件的net_device结构（其中的link_watch_list字段），将会加入到lweventlist链表中
 *		然后，使用延迟工作队列调度机制，经过指定延迟后，
 *		将代表事件的delayed_work全局结构linkwatch_work（工作项）加入到全局工作队列system_wq
 *		linkwatch_work中内含定时器（超时调用函数delayed_work_timer_fn），以实现延迟加入system_wq的逻辑
 *
 * linkwatch_event回调函数的处理：
 *		system_wq工作队列将会导致linkwatch_work设置的linkwatch_event回调函数被调用
 *		该回调函数根据net_device结构的state字段判断具体的事件类型，以做出相关动作
 *		但是，这些动作并不会通知上层链路状态改变
 */

//net/core/link_watch.c:32
//网络设备链路状态改变事件组成的链表
//常见事件包括载波从无到有，从有到无
//链表元素为net_device结构的link_watch_list字段
//static LIST_HEAD(lweventlist);
static struct list_head lweventlist;
static DEFINE_SPINLOCK(lweventlist_lock);

//net/core/link_watch.c:26
static unsigned long linkwatch_flags;
static unsigned long linkwatch_nextevent;

//net/core/link_watch.c:30
//linkwatch_work：处理网络设备链路状态改变事件的工作项work
//当发生网络设备链路状态改变事件时，它将会添加到system_wq工作队列中
//内核线程会从system_wq工作队列中取出该work，然后间接调用linkwatch_event
//由于该工作项是delayed，会保证至少经过delayed的延期事件后，才会处理工作项
//static DECLARE_DELAYED_WORK(linkwatch_work, linkwatch_event);
static struct delayed_work linkwatch_work;	//设置回调linkwatch_event、初始化timer
										 	//该timer回调delayed_work_timer_fn

//net/sched/sch_generic.c：492
/**
 *	netif_carrier_on - set carrier
 *	@dev: network device
 *
 * Device has detected acquisition of carrier.
 */
//通常，驱动程序检测到载波从无到有时，会调用此函数以发出通知
void netif_carrier_on(struct net_device *dev)
{
	//清除__LINK_STATE_NOCARRIER位
	//若之前设置了__LINK_STATE_NOCARRIER，则会进入if子句，发送通知
	//即状态是从载波丢失，到检测到载波
	if (test_and_clear_bit(__LINK_STATE_NOCARRIER, &dev->state)) 
	{
		if (dev->reg_state == NETREG_UNINITIALIZED)
			return;

		atomic_inc(&dev->carrier_up_count);

		linkwatch_fire_event(dev);

		//若网络设备已经被调用过dev_open()，则重置net_device结构的watchdog_timer开门狗定时器
		if (netif_running(dev))
			__netdev_watchdog_up(dev);
	}
}
EXPORT_SYMBOL(netif_carrier_on);

//net/sched/sch_generic.c:511
/**
 *	netif_carrier_off - clear carrier
 *	@dev: network device
 *
 * Device has detected loss of carrier.
 */
//发出通知有载波丢失
//这将触发一个消息，通知上层链路已断，该功能是通过workqueue完成的。
void netif_carrier_off(struct net_device *dev)
{
	//从检测到载波到载波丢失时，会进入if子句，发送载波丢失消息
	if (!test_and_set_bit(__LINK_STATE_NOCARRIER, &dev->state)) 
	{
		if (dev->reg_state == NETREG_UNINITIALIZED)
			return;
		
		atomic_inc(&dev->carrier_down_count);
		
		linkwatch_fire_event(dev);
	}
}
EXPORT_SYMBOL(netif_carrier_off);

//include/linux/netdevice.h:3837
/**
 *	netif_device_present - is device available or removed
 *	@dev: network device
 *
 * Check if device has not been removed from system.
 */
static inline bool netif_device_present(struct net_device *dev)
{
	return test_bit(__LINK_STATE_PRESENT, &dev->state);
}

//include/linux/netdevice.h:3813
/**
 *	netif_dormant - test if device is dormant
 *	@dev: network device
 *
 * Check if device is dormant.
 */
static inline bool netif_dormant(const struct net_device *dev)
{
	return test_bit(__LINK_STATE_DORMANT, &dev->state);
}

//include/linux/netdevice.h:3764
/**
 *	netif_carrier_ok - test if carrier present
 *	@dev: network device
 *
 * Check if carrier is present on device
 */
static inline bool netif_carrier_ok(const struct net_device *dev)
{
	return !test_bit(__LINK_STATE_NOCARRIER, &dev->state);
}

//net/core/link_watch.c:248
void linkwatch_fire_event(struct net_device *dev)
{
	//pcnet32中一般返回false
	bool urgent = linkwatch_urgent_event(dev);

	//一般之前没有设置__LINK_STATE_LINKWATCH_PENDING
	if (!test_and_set_bit(__LINK_STATE_LINKWATCH_PENDING, &dev->state)) 
	{
		//该网络设备是否还有其他未决的事件，若无，则将其加入链表lweventlist
		linkwatch_add_event(dev);
	} 
	else if (!urgent)
		return;

	linkwatch_schedule_work(urgent);
}
EXPORT_SYMBOL(linkwatch_fire_event);

//net/core/link_watch.c
//网络设备链路事件的处理不能太频繁，1秒处理1次
//使用工作队列延迟调度机制，将代表链路状态事件的工作项linkwatch_work，加入到工作队列system_=q中
//之后工作项对应的system_wq回调函数会被调用
static void linkwatch_schedule_work(int urgent)
{
	unsigned long delay = linkwatch_nextevent - jiffies;

	if (test_bit(LW_URGENT, &linkwatch_flags))
		return;

	/* Minimise down-time: drop delay for up event. */
	if (urgent) 
	{
		if (test_and_set_bit(LW_URGENT, &linkwatch_flags))
			return;
		delay = 0;
	}

	/* If we wrap around we'll delay it by at most HZ. */
	if (delay > HZ)
		delay = 0;

	/*
	 * If urgent, schedule immediate execution; otherwise, don't
	 * override the existing timer.
	 */
	if (test_bit(LW_URGENT, &linkwatch_flags))
		mod_delayed_work(system_wq, &linkwatch_work, 0);
	else
		//将
		schedule_delayed_work(&linkwatch_work, delay);
}

//net/core/link_watch.c:240
static void linkwatch_event(struct work_struct *dummy)
{
	rtnl_lock();
	__linkwatch_run_queue(time_after(linkwatch_nextevent, jiffies));
	rtnl_unlock();
}

//net/core/link_watch.c:164
static void __linkwatch_run_queue(int urgent_only)
{
#define MAX_DO_DEV_PER_LOOP	100

	int do_dev = MAX_DO_DEV_PER_LOOP;
	struct net_device *dev;
	LIST_HEAD(wrk);

	/* Give urgent case more budget */
	if (urgent_only)
		do_dev += MAX_DO_DEV_PER_LOOP;

	/*
	 * Limit the number of linkwatch events to one
	 * per second so that a runaway driver does not
	 * cause a storm of messages on the netlink
	 * socket.  This limit does not apply to up events
	 * while the device qdisc is down.
	 */
	if (!urgent_only)
		linkwatch_nextevent = jiffies + HZ;
	/* Limit wrap-around effect on delay. */
	else if (time_after(linkwatch_nextevent, jiffies + HZ))
		linkwatch_nextevent = jiffies;

	clear_bit(LW_URGENT, &linkwatch_flags);

	spin_lock_irq(&lweventlist_lock);

	//将lweventlist加入到wrk中
	list_splice_init(&lweventlist, &wrk);

	while (!list_empty(&wrk) && do_dev > 0) 
	{

		dev = list_first_entry(&wrk, struct net_device, link_watch_list);
		list_del_init(&dev->link_watch_list);

		if (urgent_only && !linkwatch_urgent_event(dev)) 
		{
			list_add_tail(&dev->link_watch_list, &lweventlist);
			continue;
		}
		
		spin_unlock_irq(&lweventlist_lock);
		linkwatch_do_dev(dev);
		do_dev--;
		spin_lock_irq(&lweventlist_lock);
	}

	/* Add the remaining work back to lweventlist */
	list_splice_init(&wrk, &lweventlist);

	if (!list_empty(&lweventlist))
		linkwatch_schedule_work(0);
	spin_unlock_irq(&lweventlist_lock);
}

//net/core/link_watch.c:139
static void linkwatch_do_dev(struct net_device *dev)
{
	/*
	 * Make sure the above read is complete since it can be
	 * rewritten as soon as we clear the bit below.
	 */
	smp_mb__before_atomic();

	/* We are about to handle this device,
	 * so new events can be accepted
	 */
	clear_bit(__LINK_STATE_LINKWATCH_PENDING, &dev->state);

	rfc2863_policy(dev);
	if (dev->flags & IFF_UP && netif_device_present(dev)) 
	{
		if (netif_carrier_ok(dev))
			dev_activate(dev);
		else
			dev_deactivate(dev);

		netdev_state_change(dev);
	}
	dev_put(dev);
}

//net/core/link_watch.c:97
//该网络设备是否还有其他未决的事件，若无，则将其加入链表lweventlist
static void linkwatch_add_event(struct net_device *dev)
{
	unsigned long flags;

	spin_lock_irqsave(&lweventlist_lock, flags);

	//该网络设备是否还有其他未决的事件，若无，则将其加入链表lweventlist
	if (list_empty(&dev->link_watch_list)) 
	{
		//将net_device结构加入链表lweventlist
		list_add_tail(&dev->link_watch_list, &lweventlist);
		dev_hold(dev);
	}
	
	spin_unlock_irqrestore(&lweventlist_lock, flags);
}

//net/core/link_watch.c:82
static bool linkwatch_urgent_event(struct net_device *dev)
{
	if (!netif_running(dev))
		return false;

	if (dev->ifindex != dev_get_iflink(dev))
		return true;

	if (netif_is_lag_port(dev) || netif_is_lag_master(dev))
		return true;

	//对于载波从有到无，该函数返回false          	    && false
	//对于载波从无到有，该函数返回true && false
	return netif_carrier_ok(dev) &&	qdisc_tx_changing(dev);
}

//include/net/sch_generic.h:748
/* Are any of the TX qdiscs changing?  */
static inline bool qdisc_tx_changing(const struct net_device *dev)
{
	unsigned int i;

	for (i = 0; i < dev->num_tx_queues; i++) 
	{
		struct netdev_queue *txq = netdev_get_tx_queue(dev, i);
		
		if (rcu_access_pointer(txq->qdisc) != txq->qdisc_sleeping)
			return true;
	}
	return false;
}

//include/linux/netdevice.h:4573
static inline bool netif_is_bond_master(const struct net_device *dev)
{
	return dev->flags & IFF_MASTER && dev->priv_flags & IFF_BONDING;
}

//include/linux/netdevice.h:4633
static inline bool netif_is_lag_master(const struct net_device *dev)
{
	//pcnet32均返回false
	return netif_is_bond_master(dev) || netif_is_team_master(dev);
}

//include/linux/netdevice.h:4623
static inline bool netif_is_team_master(const struct net_device *dev)
{
	return dev->priv_flags & IFF_TEAM;
}

//include/linux/netdevice.h:4638
static inline bool netif_is_lag_port(const struct net_device *dev)
{
	//pcnet32均返回false
	return netif_is_bond_slave(dev) || netif_is_team_port(dev);
}

//include/linux/netdevice.h:4628
static inline bool netif_is_team_port(const struct net_device *dev)
{
	return dev->priv_flags & IFF_TEAM_PORT;
}

//include/linux/netdevice.h:4578
static inline bool netif_is_bond_slave(const struct net_device *dev)
{
	return dev->flags & IFF_SLAVE && dev->priv_flags & IFF_BONDING;
}

//net/core/dev.c:606
/**
 *	dev_get_iflink	- get 'iflink' value of a interface
 *	@dev: targeted interface
 *
 *	Indicates the ifindex the interface is linked to.
 *	Physical interfaces have the same 'ifindex' and 'iflink' values.
 */
int dev_get_iflink(const struct net_device *dev)
{
	//pcnet32中没有定义该回调函数
	if (dev->netdev_ops && dev->netdev_ops->ndo_get_iflink)
		return dev->netdev_ops->ndo_get_iflink(dev);

	return dev->ifindex;
}
EXPORT_SYMBOL(dev_get_iflink);

//include/linux/netdevice.h:3350
/**
 *	netif_running - test if up
 *	@dev: network device
 *
 *	Test if the device has been brought up.
 */
static inline bool netif_running(const struct net_device *dev)
{
	return test_bit(__LINK_STATE_START, &dev->state);
}

#endif

#if 1 //NAPI、net_rx_action()、netif_receive_skb()

//net/core/dev.c:5932
/**
 *	napi_schedule_prep - check if napi can be scheduled
 *	@n: napi context
 *
 * Test if NAPI routine is already running, and if not mark
 * it as running.  This is used as a condition variable
 * insure only one NAPI poll instance runs.  We also make
 * sure there is no pending NAPI disable.
 */
//检测当前napi_struct结构是否已经在调度执行
//若没有，则设置调度标志，并会返回true
bool napi_schedule_prep(struct napi_struct *n)
{
	unsigned long val, new;

	do 
	{
		val = READ_ONCE(n->state);
		
		if (unlikely(val & NAPIF_STATE_DISABLE))
			return false;
		
		new = val | NAPIF_STATE_SCHED;

		/* Sets STATE_MISSED bit if STATE_SCHED was already set
		 * This was suggested by Alexander Duyck, as compiler
		 * emits better code than :
		 * if (val & NAPIF_STATE_SCHED)
		 *     new |= NAPIF_STATE_MISSED;
		 */
		new |= (val & NAPIF_STATE_SCHED) / NAPIF_STATE_SCHED * NAPIF_STATE_MISSED;
	} while (cmpxchg(&n->state, val, new) != val);

	return !(val & NAPIF_STATE_SCHED);
}
EXPORT_SYMBOL(napi_schedule_prep);

//net/core/dev.c:5913
/**
 * __napi_schedule - schedule for receive
 * @n: entry to schedule
 *
 * The entry's receive function will be scheduled to run.
 * Consider using __napi_schedule_irqoff() if hard irqs are masked.
 */
//将当前napi_struct结构加入到本地CPU softnet_data.poll_list链表中
//并设置软中断NET_RX_SOFTIRQ到达标志
void __napi_schedule(struct napi_struct *n)
{
	unsigned long flags;

	local_irq_save(flags);
	
	____napi_schedule(this_cpu_ptr(&softnet_data), n);
	
	local_irq_restore(flags);
}
EXPORT_SYMBOL(__napi_schedule);

//net/core/dev.c:3893
/* Called with irq disabled */
static inline void ____napi_schedule(struct softnet_data *sd, struct napi_struct *napi)
{
	list_add_tail(&napi->poll_list, &sd->poll_list);
	
	__raise_softirq_irqoff(NET_RX_SOFTIRQ);
}

//kernel/softirq.c:449
void __raise_softirq_irqoff(unsigned int nr)
{
	trace_softirq_raise(nr);
	
	or_softirq_pending(1UL << nr);
}

//include/linux/interrupt.h:493
//设置per cpu变量irq_stat的__softirq_pending字段的第x位
//__softirq_pending字段的每一位，对应一种软IRQ，该位被设置位1，表示至少有一个对应的软IRQ未决（即调度准备执行）
#define or_softirq_pending(x)	(__this_cpu_or(local_softirq_pending_ref, (x)))

//include/linux/interrupt.h:488
#define local_softirq_pending_ref irq_stat.__softirq_pending

DEFINE_PER_CPU_SHARED_ALIGNED(irq_cpustat_t, irq_stat);
EXPORT_PER_CPU_SYMBOL(irq_stat);

//net/core/dev.c:3883
unsigned int __read_mostly netdev_budget_usecs = 2000;

//net/core/dev.c:3882
int netdev_budget  = 300;//__read_mostly

//net/core/dev.c:6356
static __latent_entropy void net_rx_action(struct softirq_action *h)
{
	struct softnet_data *sd = this_cpu_ptr(&softnet_data);

	//绝对时间，若当前函数运行时刻超过该时间则应退出
	//实际上，net_rx_action()能运行的时间限制是2000us
	unsigned long time_limit = jiffies + usecs_to_jiffies(netdev_budget_usecs);

	//轮询配额。当接收的帧数超过此值，则结束轮询。默认值为300
	//这个配额不是针对一个napi_struct结构，而是针对softnet_data.poll_list链表中的所有napi_struct结构
	int budget = netdev_budget;
	
	LIST_HEAD(list);

	//repoll链表存放还需要记录轮询的napi_struct结构
	LIST_HEAD(repoll);

	local_irq_disable();

	//将softnet_data.poll_list链表中的元素，加入到list中，并重新初始化softnet_data.poll_list链表
	list_splice_init(&sd->poll_list, &list);
	
	local_irq_enable();

	for (;;) 
	{
		struct napi_struct *n;

		if (list_empty(&list)) 
		{
			//暂时不考虑RPS
			if (!sd_has_rps_ipi_waiting(sd) && list_empty(&repoll))
				goto out;
			
			break;
		}

		n = list_first_entry(&list, struct napi_struct, poll_list);
		
		budget -= napi_poll(n, &repoll);

		/* If softirq window is exhausted then punt.
		 * Allow this to run for 2 jiffies since which will allow
		 * an average latency of 1.5/HZ.
		 */
		if (unlikely(budget <= 0 || time_after_eq(jiffies, time_limit))) 
		{
			sd->time_squeeze++;
			break;
		}
	}

	local_irq_disable();

	//将softnet_data.poll_list链表中的元素，加入到list尾部，并重新初始化softnet_data.poll_list链表
	list_splice_tail_init(&sd->poll_list, &list);

	//将repoll链表中的元素，加入到list尾部
	list_splice_tail(&repoll, &list);

	//将list链表中的元素，加入到softnet_data.poll_list链表
	list_splice(&list, &sd->poll_list);

	//再次设置软中断到达标志
	if (!list_empty(&sd->poll_list))
		__raise_softirq_irqoff(NET_RX_SOFTIRQ);

	net_rps_action_and_irq_enable(sd);
out:
	__kfree_skb_flush();
}

//net/core/dev.c:6292
//从链表中摘除当前napi_struct结构
//调用当前napi_struct结构中，NIC驱动程序注册的poll回调函数
static int napi_poll(struct napi_struct *n, struct list_head *repoll)
{
	void *have;
	int work, weight;

	list_del_init(&n->poll_list);

	//pcnet32中测得返回NULL
	have = netpoll_poll_lock(n);

	weight = n->weight;

	/* This NAPI_STATE_SCHED test is for avoiding a race
	 * with netpoll's poll_napi().  Only the entity which
	 * obtains the lock and sees NAPI_STATE_SCHED set will
	 * actually make the ->poll() call.  Therefore we avoid
	 * accidentally calling ->poll() when NAPI is not scheduled.
	 */
	 
	work = 0;
	
	if (test_bit(NAPI_STATE_SCHED, &n->state)) 
	{
		//调用pcnet32_poll
		work = n->poll(n, weight);

		trace_napi_poll(n, work, weight);
	}

	WARN_ON_ONCE(work > weight);

	if (likely(work < weight))
		goto out_unlock;

	/* Drivers must not modify the NAPI state if they
	 * consume the entire weight.  In such cases this code
	 * still "owns" the NAPI instance and therefore can
	 * move the instance around on the list at-will.
	 */
	if (unlikely(napi_disable_pending(n))) 
	{
		napi_complete(n);
		goto out_unlock;
	}

	gro_normal_list(n);

	if (n->gro_bitmask) 
	{
		/* flush too old packets
		 * If HZ < 1000, flush all packets.
		 */
		napi_gro_flush(n, HZ >= 1000);
	}

	/* Some drivers may have called napi_schedule
	 * prior to exhausting their budget.
	 */
	if (unlikely(!list_empty(&n->poll_list))) 
	{
		pr_warn_once("%s: Budget exhausted after napi rescheduled\n",
			     n->dev ? n->dev->name : "backlog");
		goto out_unlock;
	}

	//pcnet32接收到的帧数目等于上限weight=16时，将该驱动的napi_struct结构加入repoll
	//可能还有帧没收上来，可以继续repoll
	list_add_tail(&n->poll_list, repoll);

out_unlock:
	netpoll_poll_unlock(have);

	return work;
}

//include/linux/netdevice.h:426
static inline bool napi_disable_pending(struct napi_struct *n)
{
	return test_bit(NAPI_STATE_DISABLE, &n->state);
}

//net/core/dev.c:5968
bool napi_complete_done(struct napi_struct *n, int work_done)
{
	unsigned long flags, val, new;

	/*
	 * 1) Don't let napi dequeue from the cpu poll list
	 *    just in case its running on a different cpu.
	 * 2) If we are busy polling, do nothing here, we have
	 *    the guarantee we will be called later.
	 */
	if (unlikely(n->state & (NAPIF_STATE_NPSVC | NAPIF_STATE_IN_BUSY_POLL)))
		return false;

	gro_normal_list(n);

	//暂时不考虑GRO
	if (n->gro_bitmask) 
	{
		unsigned long timeout = 0;

		if (work_done)
			timeout = n->dev->gro_flush_timeout;

		/* When the NAPI instance uses a timeout and keeps postponing
		 * it, we need to bound somehow the time packets are kept in
		 * the GRO layer
		 */
		napi_gro_flush(n, !!timeout);
		if (timeout)
			hrtimer_start(&n->timer, ns_to_ktime(timeout),
				      HRTIMER_MODE_REL_PINNED);
	}

	if (unlikely(!list_empty(&n->poll_list))) 
	{
		/* If n->poll_list is not empty, we need to mask irqs */
		local_irq_save(flags);
		list_del_init(&n->poll_list);
		local_irq_restore(flags);
	}

	//将n->state还原成接收帧之前的值，BIT(NAPI_STATE_HASHED)
	do 
	{
		val = READ_ONCE(n->state);

		WARN_ON_ONCE(!(val & NAPIF_STATE_SCHED));

		new = val & ~(NAPIF_STATE_MISSED | NAPIF_STATE_SCHED);

		/* If STATE_MISSED was set, leave STATE_SCHED set,
		 * because we will call napi->poll() one more time.
		 * This C code was suggested by Alexander Duyck to help gcc.
		 */
		new |= (val & NAPIF_STATE_MISSED) / NAPIF_STATE_MISSED *
						    NAPIF_STATE_SCHED;
	} while (cmpxchg(&n->state, val, new) != val);

	if (unlikely(val & NAPIF_STATE_MISSED))
	{
		__napi_schedule(n);
		return false;
	}

	return true;
}
EXPORT_SYMBOL(napi_complete_done);

//net/core/dev.c:5676
/* Pass the currently batched GRO_NORMAL SKBs up to the stack. */
static void gro_normal_list(struct napi_struct *napi)
{
	//暂时不考虑GRO
	if (!napi->rx_count)
		return;
	
	netif_receive_skb_list_internal(&napi->rx_list);
	INIT_LIST_HEAD(&napi->rx_list);
	napi->rx_count = 0;
}


//net/core/dev.c:5186
/**
 *	netif_receive_skb - process receive buffer from network
 *	@skb: buffer to process
 *
 *	netif_receive_skb() is the main receive data processing function.
 *	It always succeeds. The buffer may be dropped during processing
 *	for congestion control or by the protocol layers.
 *
 *	This function may only be called from softirq context and interrupts
 *	should be enabled.
 *
 *	Return values (usually ignored):
 *	NET_RX_SUCCESS: no congestion
 *	NET_RX_DROP: packet was dropped
 */
int netif_receive_skb(struct sk_buff *skb)
{
	int ret;

	trace_netif_receive_skb_entry(skb);

	ret = netif_receive_skb_internal(skb);
	
	trace_netif_receive_skb_exit(ret);

	return ret;
}
EXPORT_SYMBOL(netif_receive_skb);

//net/core/dev.c:5111
static int netif_receive_skb_internal(struct sk_buff *skb)
{
	int ret;

	//设置接收帧的时间
	net_timestamp_check(netdev_tstamp_prequeue, skb);

	//pcnet32中返回false
	if (skb_defer_rx_timestamp(skb))
		return NET_RX_SUCCESS;

	rcu_read_lock();

//网卡多队列，每个CPU上有多个输入队列，网卡驱动接收到数据包后，负载均衡的分发到这些队列中
#ifdef CONFIG_RPS
	//可以通过sysctl设置rps_needed，默认情况下不会进入if子句
	if (static_branch_unlikely(&rps_needed)) 
	{
		struct rps_dev_flow voidflow, *rflow = &voidflow;

		//选择一个cpu，处理该帧
		int cpu = get_rps_cpu(skb->dev, skb, &rflow);

		if (cpu >= 0) 
		{
			//将接收到的帧放入相应CPU的积压（backlog)队列中
			ret = enqueue_to_backlog(skb, cpu, &rflow->last_qtail);
			rcu_read_unlock();
			return ret;
		}
	}
#endif

	ret = __netif_receive_skb(skb);

	rcu_read_unlock();
	return ret;
}

//net/core/dev.c:5023
static int __netif_receive_skb(struct sk_buff *skb)
{
	int ret;

	//skb缓冲区的分配，是否使用了紧急内存
	if (sk_memalloc_socks() && skb_pfmemalloc(skb)) 
	{
		unsigned int noreclaim_flag;

		/*
		 * PFMEMALLOC skbs are special, they should
		 * - be delivered to SOCK_MEMALLOC sockets only
		 * - stay away from userspace
		 * - have bounded memory usage
		 *
		 * Use PF_MEMALLOC as this saves us from propagating the allocation
		 * context down to all allocation sites.
		 */
		noreclaim_flag = memalloc_noreclaim_save();
		ret = __netif_receive_skb_one_core(skb, true);
		memalloc_noreclaim_restore(noreclaim_flag);
	} else
		ret = __netif_receive_skb_one_core(skb, false);

	return ret;
}

//net/core/dev.c:4921
static int __netif_receive_skb_one_core(struct sk_buff *skb, bool pfmemalloc)
{
	struct net_device *orig_dev = skb->dev;
	struct packet_type *pt_prev = NULL;
	int ret;

	//pt_prev保存ptype_base等中最后一个没有被执行的packet_type
	ret = __netif_receive_skb_core(skb, pfmemalloc, &pt_prev);
	
	/*
	 *	ret = likely(pt_prev->func == ipv6_rcv) ? ipv6_rcv(skb, skb->dev, pt_prev, orig_dev) :
	 *				likely(pt_prev->func == ip_rcv) ? ip_rcv(skb, skb->dev, pt_prev, orig_dev) : 
	 *				     pt_prev->func(skb, skb->dev, pt_prev, orig_dev);
	 */
	if (pt_prev)
		ret = INDIRECT_CALL_INET(pt_prev->func, ipv6_rcv, ip_rcv, skb, skb->dev, pt_prev, orig_dev);
	
	return ret;
}

#define INDIRECT_CALL_INET(f, f2, f1, ...) \
	INDIRECT_CALL_2(f, f2, f1, __VA_ARGS__)

#define INDIRECT_CALL_2(f, f2, f1, ...)					\
	({								\
		likely(f == f2) ? f2(__VA_ARGS__) :			\
				  INDIRECT_CALL_1(f, f1, __VA_ARGS__);	\
	})

#define INDIRECT_CALL_1(f, f1, ...)					\
	({								\
		likely(f == f1) ? f1(__VA_ARGS__) : f(__VA_ARGS__);	\
	})

//net/core/dev.c:4732
static int __netif_receive_skb_core(struct sk_buff *skb, bool pfmemalloc,
				    struct packet_type **ppt_prev)
{
	struct packet_type *ptype, *pt_prev;
	rx_handler_func_t *rx_handler;
	struct net_device *orig_dev;
	bool deliver_exact = false;
	int ret = NET_RX_DROP;
	__be16 type;

	//设置接收帧的时间
	net_timestamp_check(!netdev_tstamp_prequeue, skb);

	trace_netif_receive_skb(skb);

	//net_device结构的rx_handler回调函数可能会修改该字段
	orig_dev = skb->dev;

	skb_reset_network_header(skb);

	//构建skb时，并未设置传输层头部
	if (!skb_transport_header_was_set(skb))
		skb_reset_transport_header(skb);

	skb_reset_mac_len(skb);

	pt_prev = NULL;

another_round:
	skb->skb_iif = skb->dev->ifindex;

	__this_cpu_inc(softnet_data.processed);

	if (static_branch_unlikely(&generic_xdp_needed_key)) 
	{
		int ret2;

		preempt_disable();
		ret2 = do_xdp_generic(rcu_dereference(skb->dev->xdp_prog), skb);
		preempt_enable();

		if (ret2 != XDP_PASS)
			return NET_RX_DROP;
		skb_reset_mac_len(skb);
	}

	//vxlan报文处理，剥除vxlan头
	if (skb->protocol == cpu_to_be16(ETH_P_8021Q) || skb->protocol == cpu_to_be16(ETH_P_8021AD)) 
	{
		//剥除vxlan头
		skb = skb_vlan_untag(skb);
		if (unlikely(!skb))
			goto out;
	}

	//返回false
	//和封包接收中的流控有关，流量分类动作
	if (skb_skip_tc_classify(skb))
		goto skip_classify;

	//从紧急内存中分开的skb，不允许ptype_all和net_device结构的ptype_all处理，即tcpdump也抓不到
	if (pfmemalloc)
		goto skip_taps;

	//触发监听MAC帧的所有监听者
	//注意ptype_all链表最后一个元素没有被调用
	list_for_each_entry_rcu(ptype, &ptype_all, list) 
	{
		if (pt_prev)
			//调用pt_prev->func(skb, skb->dev, pt_prev, orig_dev);
			ret = deliver_skb(skb, pt_prev, orig_dev);
		
		pt_prev = ptype;
	}

	//触发监听MAC帧的所有监听者，只不过帧是从skb->dev上接收到的
	list_for_each_entry_rcu(ptype, &skb->dev->ptype_all, list) 
	{
		if (pt_prev)
			ret = deliver_skb(skb, pt_prev, orig_dev);
		
		pt_prev = ptype;
	}

skip_taps:

//针对输入数据的流控处理
#ifdef CONFIG_NET_INGRESS
	if (static_branch_unlikely(&ingress_needed_key)) 
	{
		skb = sch_handle_ingress(skb, &pt_prev, &ret, orig_dev);
		if (!skb)
			goto out;

		if (nf_ingress(skb, &pt_prev, &ret, orig_dev) < 0)
			goto out;
	}
#endif

	skb_reset_tc(skb);

skip_classify:
	if (pfmemalloc && !skb_pfmemalloc_protocol(skb))
		goto drop;

	//针对vlan包 
	if (skb_vlan_tag_present(skb)) 
	{
		if (pt_prev) {
			ret = deliver_skb(skb, pt_prev, orig_dev);
			pt_prev = NULL;
		}
		if (vlan_do_receive(&skb))
			goto another_round;
		else if (unlikely(!skb))
			goto out;
	}

	/*如果一个dev被添加到一个bridge（做为bridge的一个接口)，
	 *这个接口设备的rx_handler将被设置为br_handle_frame函数，
	 *这是在br_add_if函数中设置的，而br_add_if是在向网桥设备上添加接口时设置的。
	 *进入br_handle_frame也就进入了bridge的逻辑代码。
	 */
	/*内核提供了netdev_rx_handler_register接口函数向接口注册rx_handler 
	 *比如为网桥下的接口注册br_handle_frame函数 
	 *为bonding接口注册bond_handle_frame函数
	 *网桥的处理包括向上层提交和转发 
	 *发往本地的报文会修改入接口为网桥虚接口如br0 
	 *调用netif_receive_skb重新进入协议栈处理 
	 *对于上层协议栈见到的只有桥虚接口 
	 *需要转发的报文根据转发表进行单播或广播发送 
	 */
	rx_handler = rcu_dereference(skb->dev->rx_handler);
	if (rx_handler) 
	{
		if (pt_prev) 
		{
			ret = deliver_skb(skb, pt_prev, orig_dev);
			pt_prev = NULL;
		}
		
		switch (rx_handler(&skb)) 
		{		
		case RX_HANDLER_CONSUMED:
			ret = NET_RX_SUCCESS;
			goto out;
		
		case RX_HANDLER_ANOTHER:
			goto another_round;
			
		case RX_HANDLER_EXACT:
			deliver_exact = true;
			
		case RX_HANDLER_PASS:
			break;
			
		default:
			BUG();
		}
	}
	
	//还有vlan标记，说明找不到vlanid对应的设备 
	if (unlikely(skb_vlan_tag_present(skb))) 
	{
check_vlan_id:
		//存在vlanid，则判定是到其他设备的包 
		if (skb_vlan_tag_get_id(skb)) {
			/* Vlan id is non 0 and vlan_do_receive() above couldn't
			 * find vlan device.
			 */
			skb->pkt_type = PACKET_OTHERHOST;
		} else if (skb->protocol == cpu_to_be16(ETH_P_8021Q) ||
			   skb->protocol == cpu_to_be16(ETH_P_8021AD)) {
			/* Outer header is 802.1P with vlan 0, inner header is
			 * 802.1Q or 802.1AD and vlan_do_receive() above could
			 * not find vlan dev for vlan id 0.
			 */
			__vlan_hwaccel_clear_tag(skb);
			skb = skb_vlan_untag(skb);
			if (unlikely(!skb))
				goto out;
			if (vlan_do_receive(&skb))
				/* After stripping off 802.1P header with vlan 0
				 * vlan dev is found for inner header.
				 */
				goto another_round;
			else if (unlikely(!skb))
				goto out;
			else
				/* We have stripped outer 802.1P vlan 0 header.
				 * But could not find vlan dev.
				 * check again for vlan id to set OTHERHOST.
				 */
				goto check_vlan_id;
		}
		/* Note: we might in the future use prio bits
		 * and set skb->priority like in vlan_do_receive()
		 * For the time being, just ignore Priority Code Point
		 */
		__vlan_hwaccel_clear_tag(skb);
	}

	type = skb->protocol;

	/* deliver only exact match when indicated */
	//遍历ptype_base[接收到的帧承载的第三层协议编号]链表，调用其中注册的网络层协议处理函数
	if (likely(!deliver_exact)) 
	{
		deliver_ptype_list_skb(skb, &pt_prev, orig_dev, type,
				       &ptype_base[ntohs(type) & PTYPE_HASH_MASK]);		   
	}

	//遍历orig_dev->ptype_specific链表，调用其中注册的网络层协议处理函数
	deliver_ptype_list_skb(skb, &pt_prev, orig_dev, type,
			       &orig_dev->ptype_specific);

	//遍历skb->dev->ptype_specific链表，调用其中注册的网络层协议处理函数
	if (unlikely(skb->dev != orig_dev)) 
	{
		deliver_ptype_list_skb(skb, &pt_prev, orig_dev, type,
				       &skb->dev->ptype_specific);
	}

	if (pt_prev) 
	{
		if (unlikely(skb_orphan_frags_rx(skb, GFP_ATOMIC)))
			goto drop;
		
		*ppt_prev = pt_prev;
	} 
	else 
	{
drop:
		if (!deliver_exact)
			atomic_long_inc(&skb->dev->rx_dropped);
		else
			atomic_long_inc(&skb->dev->rx_nohandler);
		
		kfree_skb(skb);
		/* Jamal, now you will not able to escape explaining
		 * me how you were going to use this. :-)
		 */
		ret = NET_RX_DROP;
	}

out:
	return ret;
};

//net/core/dev.c:4697
/*
 * Limit the use of PFMEMALLOC reserves to those protocols that implement
 * the special handling of PFMEMALLOC skbs.
 */
static bool skb_pfmemalloc_protocol(struct sk_buff *skb)
{
	switch (skb->protocol) {
	case htons(ETH_P_ARP):
	case htons(ETH_P_IP):
	case htons(ETH_P_IPV6):
	case htons(ETH_P_8021Q):
	case htons(ETH_P_8021AD):
		return true;
	default:
		return false;
	}
}

//net/core/dev.c:1891
static inline void deliver_ptype_list_skb(struct sk_buff *skb,
					  struct packet_type **pt,
					  struct net_device *orig_dev,
					  __be16 type,
					  struct list_head *ptype_list)
{
	struct packet_type *ptype, *pt_prev = *pt;

	list_for_each_entry_rcu(ptype, ptype_list, list) 
	{
		if (ptype->type != type)
			continue;
		
		if (pt_prev)
			deliver_skb(skb, pt_prev, orig_dev);
		
		pt_prev = ptype;
	}
	*pt = pt_prev;
};

#define list_for_each_entry_rcu(pos, head, member, cond...)		\
	for (__list_check_rcu(dummy, ## cond, 0),			\
	     pos = list_entry_rcu((head)->next, typeof(*pos), member);	\
		&pos->member != (head);					\
		pos = list_entry_rcu(pos->member.next, typeof(*pos), member))

//include/net/sch_generic.h:672
static inline void skb_reset_tc(struct sk_buff *skb)
{
#ifdef CONFIG_NET_CLS_ACT
	skb->tc_redirected = 0;
#endif
}

//net/core/dev.c:1881
static inline int deliver_skb(struct sk_buff *skb,
			      struct packet_type *pt_prev,
			      struct net_device *orig_dev)
{
	if (unlikely(skb_orphan_frags_rx(skb, GFP_ATOMIC)))
		return -ENOMEM;
	
	refcount_inc(&skb->users);
	
	return pt_prev->func(skb, skb->dev, pt_prev, orig_dev);
}

//include/linux/skbuff.h:2733
/* Frags must be orphaned, even if refcounted, if skb might loop to rx path */
static inline int skb_orphan_frags_rx(struct sk_buff *skb, gfp_t gfp_mask)
{
	if (likely(!skb_zcopy(skb)))
		return 0;
	
	return skb_copy_ubufs(skb, gfp_mask);
}				  

//include/net/sch_generic.h:697
static inline bool skb_skip_tc_classify(struct sk_buff *skb)
{
	//初始化skb时设置为0
	if (skb->tc_skip_classify) 
	{
		skb->tc_skip_classify = 0;
		return true;
	}
	
	return false;
}

//include/linux/skbuff.h:2390
static inline void skb_reset_mac_len(struct sk_buff *skb)
{
	skb->mac_len = skb->network_header - skb->mac_header;
}

//include/linux/skbuff.h:2461
static inline void skb_reset_transport_header(struct sk_buff *skb)
{
	skb->transport_header = skb->data - skb->head;
}

//include/linux/skbuff.h:2451					
static inline bool skb_transport_header_was_set(const struct sk_buff *skb)
{
	//skb刚才创建时，transport_header=0xffff
	return skb->transport_header != (typeof(skb->transport_header))~0U;
}

//include/linux/skbuff.h:2478
static inline void skb_reset_network_header(struct sk_buff *skb)
{
	skb->network_header = skb->data - skb->head;
}

//net/core/timestamping.c:45
//pcnet32中返回false
bool skb_defer_rx_timestamp(struct sk_buff *skb)
{
	struct phy_device *phydev;
	unsigned int type;

	//pcnet32中返回false
	if (!skb->dev || !skb->dev->phydev || !skb->dev->phydev->drv)
		return false;

	if (skb_headroom(skb) < ETH_HLEN)
		return false;

	__skb_push(skb, ETH_HLEN);

	type = ptp_classify_raw(skb);

	__skb_pull(skb, ETH_HLEN);

	if (type == PTP_CLASS_NONE)
		return false;

	phydev = skb->dev->phydev;
	if (likely(phydev->drv->rxtstamp))
		return phydev->drv->rxtstamp(phydev, skb, type);

	return false;
}
EXPORT_SYMBOL_GPL(skb_defer_rx_timestamp);


//net/core/dev.c:3881
int netdev_tstamp_prequeue = 1; // __read_mostly

//net/core/dev.c:1752
static DEFINE_STATIC_KEY_FALSE(netstamp_needed_key);

//include/linux/skbuff.h:3673
static inline void __net_timestamp(struct sk_buff *skb)
{
	skb->tstamp = ktime_get_real();
}

//net/core/dev.c:1817
#define net_timestamp_check(COND, SKB)				\
	if (static_branch_unlikely(&netstamp_needed_key)) {	\
		if ((COND) && !(SKB)->tstamp)			\
			__net_timestamp(SKB);			\
	}							\

//net/ethernet/eth.c:155
/**
 * eth_type_trans - determine the packet's protocol ID.
 * @skb: received socket data
 * @dev: receiving network device
 *
 * The rule here is that we
 * assume 802.3 if the type field is short enough to be a length.
 * This is normal practice and works for any 'now in use' protocol.
 */
__be16 eth_type_trans(struct sk_buff *skb, struct net_device *dev)
{
	unsigned short _service_access_point;
	const unsigned short *sap;
	const struct ethhdr *eth;

	skb->dev = dev;
	
	skb_reset_mac_header(skb);

	eth = (struct ethhdr *)skb->data;
	
	skb_pull_inline(skb, ETH_HLEN);

	if (unlikely(!ether_addr_equal_64bits(eth->h_dest, dev->dev_addr))) 
	{
		//0x01 & (*(const u64 *)addr);
		if (unlikely(is_multicast_ether_addr_64bits(eth->h_dest))) 
		{
			if (ether_addr_equal_64bits(eth->h_dest, dev->broadcast))
				skb->pkt_type = PACKET_BROADCAST;
			else
				skb->pkt_type = PACKET_MULTICAST;
		} 
		else 
		{
			skb->pkt_type = PACKET_OTHERHOST;
		}
	}

	/*
	 * Some variants of DSA tagging don't have an ethertype field
	 * at all, so we check here whether one of those tagging
	 * variants has been configured on the receiving interface,
	 * and if so, set skb->protocol without looking at the packet.
	 * The DSA tagging protocol may be able to decode some but not all
	 * traffic (for example only for management). In that case give it the
	 * option to filter the packets from which it can decode source port
	 * information.
	 */
	//测试环境中netdev_uses_dsa()返回false
	if (unlikely(netdev_uses_dsa(dev)) && dsa_can_decode(skb, dev))
		return htons(ETH_P_XDSA);

	//正常情况下此处返回，比如IP协议，返回ETH_P_IP（0x0800），ARP返回ETH_P_ARP（0x0806）
	if (likely(eth_proto_is_802_3(eth->h_proto)))
		return eth->h_proto;

	/*
	 *      This is a magic hack to spot IPX packets. Older Novell breaks
	 *      the protocol design and runs IPX over 802.3 without an 802.2 LLC
	 *      layer. We look for FFFF which isn't a used 802.2 SSAP/DSAP. This
	 *      won't work for fault tolerant netware but does for the rest.
	 */
	sap = skb_header_pointer(skb, 0, sizeof(*sap), &_service_access_point);
	if (sap && *sap == 0xFFFF)
		return htons(ETH_P_802_3);

	/*
	 *      Real 802.2 LLC
	 */
	return htons(ETH_P_802_2);
}
EXPORT_SYMBOL(eth_type_trans);

//include/linux/etherdevice.h:206
/**
 * eth_proto_is_802_3 - Determine if a given Ethertype/length is a protocol
 * @proto: Ethertype/length value to be tested
 *
 * Check that the value from the Ethertype/length field is a valid Ethertype.
 *
 * Return true if the valid is an 802.3 supported Ethertype.
 */
static inline bool eth_proto_is_802_3(__be16 proto)
{
	/* cast both to u16 and compare since LSB can be ignored */
	return (__force u16)proto >= (__force u16)htons(ETH_P_802_3_MIN);
}

static inline void skb_reset_mac_header(struct sk_buff *skb)
{
	skb->mac_header = skb->data - skb->head;
}

#endif

#if 1 //网络设备层次流量控制pfifo

//缺省的流量控制算法：FIFO_FAST类型出口排队规则
/*
 * 这个队列的特点就是先进先出（FIFO），没有任何数据包被特殊对待
 * 这个队列有3个所谓的“频道”。FIFO规则应用于每一个频道。
 * 并且：如果在频道0有数据包等待发送，频道1的包就不会被处理，频道1和频道2之间的关系也是如此。
 * 内核遵照数据包的TOS标记，把带有“最小延时”标记的包放进0频道。
*/
const struct Qdisc_ops *default_qdisc_ops = &pfifo_fast_ops;
EXPORT_SYMBOL(default_qdisc_ops);

//net/sched/sch_generic.c:786
struct Qdisc_ops pfifo_fast_ops = 
{
	.id		=	"pfifo_fast",
	.priv_size	=	sizeof(struct pfifo_fast_priv),
	.enqueue	=	pfifo_fast_enqueue,
	.dequeue	=	pfifo_fast_dequeue,
	.peek		=	pfifo_fast_peek,

	//dev_open()中若使用pfifo_fast_ops规则，则会调用该回调
	.init		=	pfifo_fast_init,
	
	.destroy	=	pfifo_fast_destroy,
	.reset		=	pfifo_fast_reset,
	.dump		=	pfifo_fast_dump,
	.change_tx_queue_len =  pfifo_fast_change_tx_queue_len,
	.owner		=	THIS_MODULE,
	.static_flags	=	TCQ_F_NOLOCK | TCQ_F_CPUSTATS,
};
EXPORT_SYMBOL(pfifo_fast_ops);

/* 3-band FIFO queue: old style, but should be a bit faster than
   generic prio+fifo combination.
 */

#define PFIFO_FAST_BANDS 3

//net/sched/sch_generic.c:611
/*
 * Private data for a pfifo_fast scheduler containing:
 *	- rings for priority bands
 */
struct pfifo_fast_priv 
{
	struct skb_array q[PFIFO_FAST_BANDS];
};

//include/net/sch_generic.h:369
struct qdisc_skb_cb 
{
	struct 
	{
		unsigned int		pkt_len;
		u16					slave_dev_queue_mapping;
		u16					tc_classid;
	};
	
#define QDISC_CB_PRIV_LEN 20
	unsigned char			data[QDISC_CB_PRIV_LEN];
};

//net/sched/sch_generic.c:1054
static void attach_default_qdiscs(struct net_device *dev)
{
	struct netdev_queue *txq;
	struct Qdisc *qdisc;

	txq = netdev_get_tx_queue(dev, 0);

	if (!netif_is_multiqueue(dev) || dev->priv_flags & IFF_NO_QUEUE)
	{//pcnet32进入此分支

		//调用attach_one_default_qdisc()
		netdev_for_each_tx_queue(dev, attach_one_default_qdisc, NULL);
		
		dev->qdisc = txq->qdisc_sleeping;
		
		qdisc_refcount_inc(dev->qdisc);
	} 
	else 
	{
		qdisc = qdisc_create_dflt(txq, &mq_qdisc_ops, TC_H_ROOT, NULL);
		if (qdisc) {
			dev->qdisc = qdisc;
			qdisc->ops->attach(qdisc);
		}
	}

	if (dev->qdisc != &noop_qdisc)
		qdisc_hash_add(dev->qdisc, false);
}

//net/sched/sch_api.c:275
void qdisc_hash_add(struct Qdisc *q, bool invisible)
{
	if ((q->parent != TC_H_ROOT) && !(q->flags & TCQ_F_INGRESS)) 
	{
		ASSERT_RTNL();
		hash_add_rcu(qdisc_dev(q)->qdisc_hash, &q->hash, q->handle);
		if (invisible)
			q->flags |= TCQ_F_INVISIBLE;
	}
}
EXPORT_SYMBOL(qdisc_hash_add);

//include/net/sch_generic.h:117
static inline void qdisc_refcount_inc(struct Qdisc *qdisc)
{
	if (qdisc->flags & TCQ_F_BUILTIN)
		return;
	
	refcount_inc(&qdisc->refcnt);
}

//net/sched/sch_generic.c:1032
static void attach_one_default_qdisc(struct net_device *dev,
				     struct netdev_queue *dev_queue,
				     void *_unused)
{
	struct Qdisc *qdisc;
	const struct Qdisc_ops *ops = default_qdisc_ops;

	//对于pcnet32，以下语句不会执行
	if (dev->priv_flags & IFF_NO_QUEUE)
		ops = &noqueue_qdisc_ops;
	else if(dev->type == ARPHRD_CAN)
		ops = &pfifo_fast_ops;

	qdisc = qdisc_create_dflt(dev_queue, ops, TC_H_ROOT, NULL);	
	if (!qdisc) 
	{
		netdev_info(dev, "activation failed\n");
		return;
	}
	
	if (!netif_is_multiqueue(dev))
		qdisc->flags |= TCQ_F_ONETXQUEUE | TCQ_F_NOPARENT;
	
	dev_queue->qdisc_sleeping = qdisc;
}

//net/sched/sch_generic.c:880
struct Qdisc *qdisc_create_dflt(struct netdev_queue *dev_queue,
				const struct Qdisc_ops *ops,
				unsigned int parentid,
				struct netlink_ext_ack *extack)
{
	struct Qdisc *sch;

	if (!try_module_get(ops->owner)) 
	{
		NL_SET_ERR_MSG(extack, "Failed to increase module reference counter");
		return NULL;
	}

	sch = qdisc_alloc(dev_queue, ops, extack);
	if (IS_ERR(sch)) {
		module_put(ops->owner);
		return NULL;
	}
	
	sch->parent = parentid;

	//pcnet32测试，调用pfifo_fast_init()
	if (!ops->init || ops->init(sch, NULL, extack) == 0)
		return sch;

	qdisc_put(sch);
	return NULL;
}
EXPORT_SYMBOL(qdisc_create_dflt);

//net/sched/sch_generic.c:724
static int pfifo_fast_init(struct Qdisc *qdisc, struct nlattr *opt,
			   struct netlink_ext_ack *extack)
{
	//一般该值是1000
	unsigned int qlen = qdisc_dev(qdisc)->tx_queue_len;
	
	struct pfifo_fast_priv *priv = qdisc_priv(qdisc);
	int prio;

	/* guard against zero length rings */
	if (!qlen)
		return -EINVAL;

	for (prio = 0; prio < PFIFO_FAST_BANDS; prio++) 
	{
		struct skb_array *q = band2list(priv, prio);
		int err;

		//为skb_array.queue分配空间，该字段指向元素类型是void*的数组，元素个数1000
		err = skb_array_init(q, qlen, GFP_KERNEL);
		if (err)
			return -ENOMEM;
	}

	/* Can by-pass the queue discipline */
	qdisc->flags |= TCQ_F_CAN_BYPASS;
	return 0;
}

//net/sched/sch_generic.c:611
static inline struct skb_array *band2list(struct pfifo_fast_priv *priv, int band)
{
	return &priv->q[band];
}

//include/net/pkt_sched.h:546
static inline struct net_device *qdisc_dev(const struct Qdisc *qdisc)
{
	return qdisc->dev_queue->dev;
}

//include/net/pkt_sched.h:25
static inline void *qdisc_priv(struct Qdisc *q)
{
	return (char *) q + QDISC_ALIGN(sizeof(struct Qdisc));
}

//net/sched/sch_generic.c:802
struct Qdisc *qdisc_alloc(struct netdev_queue *dev_queue,
			  const struct Qdisc_ops *ops,
			  struct netlink_ext_ack *extack)
{
	void *p;
	struct Qdisc *sch;
	unsigned int size = QDISC_ALIGN(sizeof(*sch)) + ops->priv_size;
	int err = -ENOBUFS;
	struct net_device *dev;

	if (!dev_queue) 
	{
		NL_SET_ERR_MSG(extack, "No device queue given");
		err = -EINVAL;
		goto errout;
	}

	dev = dev_queue->dev;

	//新分配的Qdisc结构，要与netdev_queue在同一个NUMA结点
	p = kzalloc_node(size, GFP_KERNEL, netdev_queue_numa_node_read(dev_queue));

	if (!p)
		goto errout;
	
	sch = (struct Qdisc *) QDISC_ALIGN((unsigned long) p);
	/* if we got non aligned memory, ask more and do alignment ourself */
	if (sch != p) {
		kfree(p);
		p = kzalloc_node(size + QDISC_ALIGNTO - 1, GFP_KERNEL,
				 netdev_queue_numa_node_read(dev_queue));
		if (!p)
			goto errout;
		sch = (struct Qdisc *) QDISC_ALIGN((unsigned long) p);
		sch->padded = (char *) sch - (char *) p;
	}
	
	__skb_queue_head_init(&sch->gso_skb);
	__skb_queue_head_init(&sch->skb_bad_txq);
	
	qdisc_skb_head_init(&sch->q);
	spin_lock_init(&sch->q.lock);

	if (ops->static_flags & TCQ_F_CPUSTATS) 
	{//使用pfifo_fast_ops规则进入此
	
		sch->cpu_bstats = netdev_alloc_pcpu_stats(struct gnet_stats_basic_cpu);
		if (!sch->cpu_bstats)
			goto errout1;

		sch->cpu_qstats = alloc_percpu(struct gnet_stats_queue);
		if (!sch->cpu_qstats) {
			free_percpu(sch->cpu_bstats);
			goto errout1;
		}
	}

	spin_lock_init(&sch->busylock);
	/* seqlock has the same scope of busylock, for NOLOCK qdisc */
	spin_lock_init(&sch->seqlock);

	//sch->running.sequence = 0;
	seqcount_init(&sch->running);
	
	sch->ops = ops;
	sch->flags = ops->static_flags;
	sch->enqueue = ops->enqueue;
	sch->dequeue = ops->dequeue;
	sch->dev_queue = dev_queue;
	sch->empty = true;
	
	dev_hold(dev);
	
	refcount_set(&sch->refcnt, 1);

	if (sch != &noop_qdisc) 
	{
		lockdep_set_class(&sch->busylock, &dev->qdisc_tx_busylock_key);
		lockdep_set_class(&sch->seqlock, &dev->qdisc_tx_busylock_key);
		lockdep_set_class(&sch->running, &dev->qdisc_running_key);
	}

	return sch;
errout1:
	kfree(p);
errout:
	return ERR_PTR(err);
}

//include/net/sch_generic.h:955
static inline void qdisc_skb_head_init(struct qdisc_skb_head *qh)
{
	qh->head = NULL;
	qh->tail = NULL;
	qh->qlen = 0;
}

//include/linux/netdevice.h:3535
/**
 *	netif_is_multiqueue - test if device has multiple transmit queues
 *	@dev: network device
 *
 * Check if device has multiple transmit queues
 */
static inline bool netif_is_multiqueue(const struct net_device *dev)
{
	return dev->num_tx_queues > 1;
}

#endif

#if 1 //dev_queue_xmit()、net_tx_action()

//net/core/dev.c:3823
int dev_queue_xmit(struct sk_buff *skb)
{
	return __dev_queue_xmit(skb, NULL);
}
EXPORT_SYMBOL(dev_queue_xmit);

//net/core/dev.c:3717
/**
 *	__dev_queue_xmit - transmit a buffer
 *	@skb: buffer to transmit
 *	@sb_dev: suboordinate device used for L2 forwarding offload
 *
 *	Queue a buffer for transmission to a network device. The caller must
 *	have set the device and priority and built the buffer before calling
 *	this function. The function can be called from an interrupt.
 *
 *	A negative errno code is returned on a failure. A success does not
 *	guarantee the frame will be transmitted as it may be dropped due
 *	to congestion or traffic shaping.
 *
 * -----------------------------------------------------------------------------------
 *      I notice this method can also return errors from the queue disciplines,
 *      including NET_XMIT_DROP, which is a positive value.  So, errors can also
 *      be positive.
 *
 *      Regardless of the return value, the skb is consumed, so it is currently
 *      difficult to retry a send to this method.  (You can bump the ref count
 *      before sending to hold a reference for retry if you are careful.)
 *
 *      When calling this method, interrupts MUST be enabled.  This is because
 *      the BH enable code must have IRQs enabled so that it will not deadlock.
 *          --BLG
 */
//失败时返回负数，但是非负数并不意味着帧成功发送（比如返回NET_XMIT_DROP），因为可能被出口拥塞或流量控制机制给丢弃
//可以在中断上下文调用此函数
static int __dev_queue_xmit(struct sk_buff *skb, struct net_device *sb_dev)
{
	struct net_device *dev = skb->dev;
	struct netdev_queue *txq;
	struct Qdisc *q;
	int rc = -ENOMEM;
	bool again = false;

	skb_reset_mac_header(skb);

	if (unlikely(skb_shinfo(skb)->tx_flags & SKBTX_SCHED_TSTAMP))
		__skb_tstamp_tx(skb, NULL, skb->sk, SCM_TSTAMP_SCHED);

	/* Disable soft irqs for various locks below. Also
	 * stops preemption for RCU.
	 */
	rcu_read_lock_bh();

	//默认情况下，该函数无实际效果。skb->dev->priomap为空
	skb_update_prio(skb);

	//根据分段数量重新计算应发报文大小，以设置skb.(struct qdisc_skb_cb *)cb->pkt_len，即
	//原传递的一个完整skb所示的报文大小，再加上（分段数量-1）*（MAC头部大小 + 网络层头部大小 + 传输层头部（TCP或UDP）大小）
	qdisc_pkt_len_init(skb);
	
#ifdef CONFIG_NET_CLS_ACT
	skb->tc_at_ingress = 0;
#ifdef CONFIG_NET_EGRESS
	if (static_branch_unlikely(&egress_needed_key)) 
	{
		//由于net_device结构的miniq_egress一般为NULL，该函数直接返回skb，无实际效果
		skb = sch_handle_egress(skb, &rc, dev);
		if (!skb)
			goto out;
	}
#endif
#endif

	//net_device结构的priv_flags，一般都设置了IFF_XMIT_DST_RELEASE
	//即表示可以释放skb->dst
	if (dev->priv_flags & IFF_XMIT_DST_RELEASE)
		skb_dst_drop(skb);
	else
		skb_dst_force(skb);

	//通常net_device结构_tx只包含一个队列，因此txq=dev._tx[0]
	txq = netdev_core_pick_tx(dev, skb, sb_dev);

	q = rcu_dereference_bh(txq->qdisc);

	trace_net_dev_queue(skb);

	//默认情况下，该回调函数字段被设置成了pfifo_fast_enqueue	
	if (q->enqueue) 
	{
		rc = __dev_xmit_skb(skb, q, dev, txq);
		goto out;
	}

	/* The device has no queue. Common case for software devices:
	 * loopback, all the sorts of tunnels...

	 * Really, it is unlikely that netif_tx_lock protection is necessary
	 * here.  (f.e. loopback and IP tunnels are clean ignoring statistics
	 * counters.)
	 * However, it is possible, that they rely on protection
	 * made by us here.

	 * Check this and shot the lock. It is not prone from deadlocks.
	 *Either shot noqueue qdisc, it is even simpler 8)
	 */
	if (dev->flags & IFF_UP) {
		int cpu = smp_processor_id(); /* ok because BHs are off */

		if (txq->xmit_lock_owner != cpu) {
			if (dev_xmit_recursion())
				goto recursion_alert;

			skb = validate_xmit_skb(skb, dev, &again);
			if (!skb)
				goto out;

			HARD_TX_LOCK(dev, txq, cpu);

			if (!netif_xmit_stopped(txq)) {
				dev_xmit_recursion_inc();
				skb = dev_hard_start_xmit(skb, dev, txq, &rc);
				dev_xmit_recursion_dec();
				if (dev_xmit_complete(rc)) {
					HARD_TX_UNLOCK(dev, txq);
					goto out;
				}
			}
			HARD_TX_UNLOCK(dev, txq);
			net_crit_ratelimited("Virtual device %s asks to queue packet!\n",
					     dev->name);
		} else {
			/* Recursion is detected! It is possible,
			 * unfortunately
			 */
recursion_alert:
			net_crit_ratelimited("Dead loop on virtual device %s, fix it urgently!\n",
					     dev->name);
		}
	}

	rc = -ENETDOWN;
	rcu_read_unlock_bh();

	atomic_long_inc(&dev->tx_dropped);
	kfree_skb_list(skb);
	return rc;
out:
	rcu_read_unlock_bh();
	return rc;
}

//net/core/dev.c:3377
static inline int __dev_xmit_skb(struct sk_buff *skb, struct Qdisc *q,
				 struct net_device *dev,
				 struct netdev_queue *txq)
{
	spinlock_t *root_lock = qdisc_lock(q);	
	struct sk_buff *to_free = NULL;
	bool contended;
	int rc;

	qdisc_calculate_pkt_len(skb, q);

	//pfifo中设置了TCQ_F_NOLOCK标志，进入if子句
	if (q->flags & TCQ_F_NOLOCK) 
	{
		//pfifo中设置了TCQ_F_CAN_BYPASS标志、q->empty=true（即判断队列是否正在发送）、qdisc_run_begin返回true
		if ((q->flags & TCQ_F_CAN_BYPASS) && q->empty && qdisc_run_begin(q)) 
		{
			//pfifo中q->state的该(__QDISC_STATE_DEACTIVATED位为0
			if (unlikely(test_bit(__QDISC_STATE_DEACTIVATED,&q->state))) 
			{
				__qdisc_drop(skb, &to_free);
				rc = NET_XMIT_DROP;
				goto end_run;
			}
			
			qdisc_bstats_cpu_update(q, skb);

			rc = NET_XMIT_SUCCESS;
			
			if (sch_direct_xmit(skb, q, dev, txq, NULL, true))
				//这里返回true，说明帧已经交给了驱动程序
				//通常情况下就不会有skb放入net_device._tx[0].qdisc.gso_skb链表中
				//此时__qdisc_run的调用无实际意义
				__qdisc_run(q);
end_run:
			qdisc_run_end(q);
		} 
		else 
		{
			//此时发送队列中还有报文需要发送，因此先调用enqueue排队
			//实际上这里主要是指发生了拥塞
			//对于pfifo，实际调用pfifo_fast_enqueue
			//根据待发送的skb的priority字段，选择一个发送频道，即skb_arry，然后将skb，放入该skb_array环形缓冲区中
			rc = q->enqueue(skb, q, &to_free) & NET_XMIT_MASK;
			qdisc_run(q);
		}

		if (unlikely(to_free))
			kfree_skb_list(to_free);
		
		return rc;
	}

	/*
	 * Heuristic to force contended enqueues to serialize on a
	 * separate lock before trying to get qdisc main lock.
	 * This permits qdisc->running owner to get the lock more
	 * often and dequeue packets faster.
	 */
	contended = qdisc_is_running(q);
	if (unlikely(contended))
		spin_lock(&q->busylock);

	spin_lock(root_lock);
	if (unlikely(test_bit(__QDISC_STATE_DEACTIVATED, &q->state))) {
		__qdisc_drop(skb, &to_free);
		rc = NET_XMIT_DROP;
	} else if ((q->flags & TCQ_F_CAN_BYPASS) && !qdisc_qlen(q) &&
		   qdisc_run_begin(q)) {
		/*
		 * This is a work-conserving queue; there are no old skbs
		 * waiting to be sent out; and the qdisc is not running -
		 * xmit the skb directly.
		 */

		qdisc_bstats_update(q, skb);

		if (sch_direct_xmit(skb, q, dev, txq, root_lock, true)) {
			if (unlikely(contended)) {
				spin_unlock(&q->busylock);
				contended = false;
			}
			__qdisc_run(q);
		}

		qdisc_run_end(q);
		rc = NET_XMIT_SUCCESS;
	} else {
		rc = q->enqueue(skb, q, &to_free) & NET_XMIT_MASK;
		if (qdisc_run_begin(q)) {
			if (unlikely(contended)) {
				spin_unlock(&q->busylock);
				contended = false;
			}
			__qdisc_run(q);
			qdisc_run_end(q);
		}
	}
	spin_unlock(root_lock);
	if (unlikely(to_free))
		kfree_skb_list(to_free);
	if (unlikely(contended))
		spin_unlock(&q->busylock);
	return rc;
};

//include/net/pkt_sched.h:118
//若当前Qdisc没有正在发送帧，则
//从net_device._tx[0].qdisc.gso_skb链表中，或对于pfifo而言从其发送频道环形缓冲中，取出一个skb发送
static inline void qdisc_run(struct Qdisc *q)
{
	if (qdisc_run_begin(q)) 
	{
		/* NOLOCK qdisc must check 'state' under the qdisc seqlock
		 * to avoid racing with dev_qdisc_reset()
		 */
		if (!(q->flags & TCQ_F_NOLOCK) || likely(!test_bit(__QDISC_STATE_DEACTIVATED, &q->state)))
			__qdisc_run(q);
					
		qdisc_run_end(q);
	}
}

//net/sched/sch_generic.c:597
static const u8 prio2band[TC_PRIO_MAX + 1] = 
{
	1, 2, 2, 2, 1, 2, 0, 0 , 1, 1, 1, 1, 1, 1, 1, 1
};

#define TC_PRIO_MAX 15

//net/sched/sch_generic.c:621
//根据待发送的skb的priority字段，选择一个发送频道，即skb_arry，然后将skb，放入该skb_array环形缓冲区中
static int pfifo_fast_enqueue(struct sk_buff *skb, struct Qdisc *qdisc,
			      struct sk_buff **to_free)
{
	//根据skb优先级选择pfifo私有数据中的频道，即某个skb_array
	int band = prio2band[skb->priority & TC_PRIO_MAX];
	
	struct pfifo_fast_priv *priv = qdisc_priv(qdisc);
	
	struct skb_array *q = band2list(priv, band);
	
	unsigned int pkt_len = qdisc_pkt_len(skb);
	int err;

	//skb_array本质上是环形缓冲区
	//该函数将待发送的skb，放入上述环形缓冲区中
	err = skb_array_produce(q, skb);
	if (unlikely(err)) 
	{
		if (qdisc_is_percpu_stats(qdisc))
			return qdisc_drop_cpu(skb, qdisc, to_free);
		else
			return qdisc_drop(skb, qdisc, to_free);
	}

	qdisc_update_stats_at_enqueue(qdisc, pkt_len);
	return NET_XMIT_SUCCESS;
};

//include/net/sch_generic.h:1106
static inline void qdisc_update_stats_at_enqueue(struct Qdisc *sch,
						 unsigned int pkt_len)
{
	if (qdisc_is_percpu_stats(sch)) 
	{
		qdisc_qstats_cpu_qlen_inc(sch);
		this_cpu_add(sch->cpu_qstats->backlog, pkt_len);
	} 
	else 
	{
		sch->qstats.backlog += pkt_len;
		sch->q.qlen++;
	}
}

//include/net/sch_generic.h:173
static inline void qdisc_run_end(struct Qdisc *qdisc)
{
	write_seqcount_end(&qdisc->running);
	
	if (qdisc->flags & TCQ_F_NOLOCK)
		spin_unlock(&qdisc->seqlock);
}

//net/core/dev.c:3888
//一次能发送的最大帧数目
int dev_tx_weight = 64; // __read_mostly 

//net/sched/sch_generic.c:379
//调用dev_queue_xmit()发送帧给驱动程序，成功返回后也可能调用该函数
//调用dev_queue_xmit()发送帧时，如果当前Qdisc结构empty字段为假，即出现拥塞，也可能调用该函数
//软中断net_tx_actioin()中也可能调用该函数
void __qdisc_run(struct Qdisc *q)
{
	int quota = dev_tx_weight;
	int packets;

	while (qdisc_restart(q, &packets)) 	
	{
		/*
		 * Ordered by possible occurrence: Postpone processing if
		 * 1. we've exceeded packet quota
		 * 2. another process needs the CPU;
		 */
		quota -= packets;
		if (quota <= 0 || need_resched()) 
		{
			__netif_schedule(q);
			break;
		}
	}
}

//net/sched/sch_generic.c:357
/*
 * NOTE: Called under qdisc_lock(q) with locally disabled BH.
 *
 * running seqcount guarantees only one CPU can process
 * this qdisc at a time. qdisc_lock(q) serializes queue accesses for
 * this queue.
 *
 *  netif_tx_lock serializes accesses to device driver.
 *
 *  qdisc_lock(q) and netif_tx_lock are mutually exclusive,
 *  if one is grabbed, another must be free.
 *
 * Note, that this procedure can be called by a watchdog timer
 *
 * Returns to the caller:
 *				0  - queue is empty or throttled.
 *				>0 - queue is not empty.
 *
 */
//返回true说明发送完成，false说明重新进入队列，packet=1
static inline bool qdisc_restart(struct Qdisc *q, int *packets)
{
	spinlock_t *root_lock = NULL;
	struct netdev_queue *txq;
	struct net_device *dev;
	struct sk_buff *skb;
	bool validate;

	/* Dequeue packet */
	skb = dequeue_skb(q, &validate, packets);
	if (unlikely(!skb))
		return false;

	if (!(q->flags & TCQ_F_NOLOCK))
		root_lock = qdisc_lock(q);

	dev = qdisc_dev(q);
	txq = skb_get_tx_queue(dev, skb);

	return sch_direct_xmit(skb, q, dev, txq, root_lock, validate);	
}

//include/linux/netdevice.h:2119
static inline struct netdev_queue *skb_get_tx_queue(const struct net_device *dev,
						    const struct sk_buff *skb)
{
	return netdev_get_tx_queue(dev, skb_get_queue_mapping(skb));
}

//include/linux/skbuff.h:4271
static inline u16 skb_get_queue_mapping(const struct sk_buff *skb)
{
	return skb->queue_mapping;
}

//net/sched/sch_generic.c:202
/* Note that dequeue_skb can possibly return a SKB list (via skb->next).
 * A requeued skb (via q->gso_skb) can also be a SKB list.
 */
//从net_device._tx[0].qdisc.gso_skb链表中，或对于pfifo而言从其发送频道环形缓冲中，取出一个skb发送。
//只能取一个，优先从gso_skb链表中取。即packets保存1
//大多情况下，从gso_skb链表中取skb，validate将保存false，否则保存true。
static struct sk_buff *dequeue_skb(struct Qdisc *q, bool *validate, int *packets)
{
	const struct netdev_queue *txq = q->dev_queue;
	struct sk_buff *skb = NULL;

	*packets = 1;
	
	if (unlikely(!skb_queue_empty(&q->gso_skb))) 
	{
		spinlock_t *lock = NULL;

		if (q->flags & TCQ_F_NOLOCK) 
		{
			lock = qdisc_lock(q);
			spin_lock(lock);
		}

		skb = skb_peek(&q->gso_skb);

		/* skb may be null if another cpu pulls gso_skb off in between
		 * empty check and lock.
		 */
		if (!skb) 
		{
			if (lock)
				spin_unlock(lock);
			
			goto validate;
		}

		/* skb in gso_skb were already validated */
		*validate = false;
		
		if (xfrm_offload(skb))
			*validate = true;
		
		/* check the reason of requeuing without tx lock first */
		txq = skb_get_tx_queue(txq->dev, skb);
		
		if (!netif_xmit_frozen_or_stopped(txq)) 
		{
			skb = __skb_dequeue(&q->gso_skb);
			
			if (qdisc_is_percpu_stats(q)) 
			{
				qdisc_qstats_cpu_backlog_dec(q, skb);
				qdisc_qstats_cpu_qlen_dec(q);
			} 
			else 
			{
				qdisc_qstats_backlog_dec(q, skb);
				q->q.qlen--;
			}
		} 
		else 
		{
			skb = NULL;
		}
		
		if (lock)
			spin_unlock(lock);
		goto trace;
	}
	
validate:
	*validate = true;

	//对于pfifo第一个条件为真
	if ((q->flags & TCQ_F_ONETXQUEUE) && netif_xmit_frozen_or_stopped(txq))
		return skb;

	skb = qdisc_dequeue_skb_bad_txq(q);
	if (unlikely(skb)) 
	{
		if (skb == SKB_XOFF_MAGIC)
			return NULL;
		goto bulk;
	}

	//对于pfifo设置为pfifo_fast_dequeue，返回pfifo中优先级最高频道中的skb
	skb = q->dequeue(q);
	if (skb) 
	{
bulk:
		if (qdisc_may_bulk(q))
			try_bulk_dequeue_skb(q, skb, txq, packets);		
		else
			try_bulk_dequeue_skb_slow(q, skb, packets);
	}
trace:

	trace_qdisc_dequeue(q, txq, *packets, skb);
	return skb;
}

//net/sched/sch_generic.c:152
static void try_bulk_dequeue_skb(struct Qdisc *q,
				 struct sk_buff *skb,
				 const struct netdev_queue *txq,
				 int *packets)
{
	int bytelimit = qdisc_avail_bulklimit(txq) - skb->len;

	while (bytelimit > 0) {
		struct sk_buff *nskb = q->dequeue(q);

		if (!nskb)
			break;

		bytelimit -= nskb->len; /* covers GSO len */
		skb->next = nskb;
		skb = nskb;
		(*packets)++; /* GSO counts as one pkt */
	}
	skb_mark_not_on_list(skb);
};

//include/net/sch_generic.h:185
//默认情况下返回0
static inline int qdisc_avail_bulklimit(const struct netdev_queue *txq)
{
	/* Non-BQL migrated drivers will return 0, too. */
	return dql_avail(&txq->dql);
}

//include/linux/dynamic_queue_limits.h:90
/* Returns how many objects can be queued, < 0 indicates over limit. */
static inline int dql_avail(const struct dql *dql)
{
	return READ_ONCE(dql->adj_limit) - READ_ONCE(dql->num_queued);
}

//include/net/sch_generic.h:180
//对pfifo返回true
static inline bool qdisc_may_bulk(const struct Qdisc *qdisc)
{
	return qdisc->flags & TCQ_F_ONETXQUEUE;
}

//net/sched/sch_generic.c:643
//返回pfifo中优先级最高频道中的skb
static struct sk_buff *pfifo_fast_dequeue(struct Qdisc *qdisc)
{
	struct pfifo_fast_priv *priv = qdisc_priv(qdisc);
	struct sk_buff *skb = NULL;
	int band;

	//只会获取优先级最高的skb_array中的skb
	for (band = 0; band < PFIFO_FAST_BANDS && !skb; band++)
	{
		struct skb_array *q = band2list(priv, band);

		if (__skb_array_empty(q))
			continue;

		skb = __skb_array_consume(q);
	}

	if (likely(skb)) 
	{
		qdisc_update_stats_at_dequeue(qdisc, skb);
	} 
	else 
	{
		qdisc->empty = true;
	}

	return skb;
}

//include/net/sch_generic.h:1092
static inline void qdisc_update_stats_at_dequeue(struct Qdisc *sch,
						 struct sk_buff *skb)
{
	if (qdisc_is_percpu_stats(sch)) 
	{
		qdisc_qstats_cpu_backlog_dec(sch, skb);
		qdisc_bstats_cpu_update(sch, skb);
		qdisc_qstats_cpu_qlen_dec(sch);
	} 
	else 
	{
		qdisc_qstats_backlog_dec(sch, skb);
		qdisc_bstats_update(sch, skb);
		sch->q.qlen--;
	}
}

//include/net/sch_generic.h:880
static inline void qdisc_qstats_cpu_qlen_dec(struct Qdisc *sch)
{
	this_cpu_dec(sch->cpu_qstats->qlen);
}

//include/net/sch_generic.h:857
static inline void qdisc_qstats_cpu_backlog_dec(struct Qdisc *sch,
						const struct sk_buff *skb)
{
	this_cpu_sub(sch->cpu_qstats->backlog, qdisc_pkt_len(skb));
}

//net/sched/sch_generic.c:86
static inline struct sk_buff *qdisc_dequeue_skb_bad_txq(struct Qdisc *q)
{
	struct sk_buff *skb = skb_peek(&q->skb_bad_txq);

	if (unlikely(skb))
		skb = __skb_dequeue_bad_txq(q);

	return skb;
}

//net/sched/sch_generic.c:285
/*
 * Transmit possibly several skbs, and handle the return status as
 * required. Owning running seqcount bit guarantees that
 * only one CPU can execute this function.
 *
 * Returns to the caller:
 *				false  - hardware queue frozen backoff
 *				true   - feel free to send more pkts
 */
//返回true说明发送完成，false说明重新进入队列
bool sch_direct_xmit(struct sk_buff *skb, struct Qdisc *q,
		     struct net_device *dev, struct netdev_queue *txq,
		     spinlock_t *root_lock, bool validate)
{
	int ret = NETDEV_TX_BUSY;
	bool again = false;

	/* And release qdisc */
	if (root_lock)
		spin_unlock(root_lock);

	/* Note that we validate skb (GSO, checksum, ...) outside of locks */
	//检测各种feature，如是否支持GSO等
	//若硬件不支持分段，则内核在这里会执行软件分段
	if (validate)
		skb = validate_xmit_skb_list(skb, dev, &again);

#ifdef CONFIG_XFRM_OFFLOAD
	if (unlikely(again)) {
		if (root_lock)
			spin_lock(root_lock);

		dev_requeue_skb(skb, q);
		return false;
	}
#endif

	if (likely(skb)) 
	{
		HARD_TX_LOCK(dev, txq, smp_processor_id());

		//正常情况会进入if子句
		if (!netif_xmit_frozen_or_stopped(txq))
			skb = dev_hard_start_xmit(skb, dev, txq, &ret);

		HARD_TX_UNLOCK(dev, txq);
	} 
	else 
	{
		if (root_lock)
			spin_lock(root_lock);
		return true;
	}

	if (root_lock)
		spin_lock(root_lock);

	if (!dev_xmit_complete(ret)) 
	{
		/* Driver returned NETDEV_TX_BUSY - requeue skb */
		if (unlikely(ret != NETDEV_TX_BUSY))
			net_warn_ratelimited("BUG %s code %d qlen %d\n", dev->name, ret, q->q.qlen);

		dev_requeue_skb(skb, q);

		return false;
	}

	return true;
};

//net/sched/sch_generic.c:120
//通常，skb链表代表了之前没有发送成功（常常是由于驱动发送队列满）的若干帧
//将这些skb逐一放入net_device._tx[0].qdisc.gso_skb链表中，并更新net_device._tx[0].qdisc.cpu_qstats相关统计数据
//将net_device._tx[0].qdisc，放入当前cpu的softnet_data.output_queue链表中
//触发软中断NET_TX_SOFTIRQ，若不处于中断或软中断上下文，则启动ksoftirqd线程
static inline void dev_requeue_skb(struct sk_buff *skb, struct Qdisc *q)
{
	spinlock_t *lock = NULL;

	//进入if子句
	if (q->flags & TCQ_F_NOLOCK) 
	{
		lock = qdisc_lock(q);
		spin_lock(lock);
	}

	while (skb) 
	{
		struct sk_buff *next = skb->next;

		__skb_queue_tail(&q->gso_skb, skb);

		/* it's still part of the queue */
		if (qdisc_is_percpu_stats(q)) 		
		{
			qdisc_qstats_cpu_requeues_inc(q);
			qdisc_qstats_cpu_backlog_inc(q, skb);
			qdisc_qstats_cpu_qlen_inc(q);
		} 
		else 
		{
			q->qstats.requeues++;
			qdisc_qstats_backlog_inc(q, skb);
			q->q.qlen++;
		}

		skb = next;
	}
	
	if (lock)
		spin_unlock(lock);
	
	//通常是将net_device._tx[0].qdisc，放入当前cpu的softnet_data.output_queue链表中
	//触发软中断NET_TX_SOFTIRQ，若不处于中断或软中断上下文，则启动ksoftirqd线程
	__netif_schedule(q);
}

//include/net/sch_generic.h:875
static inline void qdisc_qstats_cpu_qlen_inc(struct Qdisc *sch)
{
	this_cpu_inc(sch->cpu_qstats->qlen);
}

//include/net/sch_generic.h:863
static inline void qdisc_qstats_backlog_inc(struct Qdisc *sch,
					    const struct sk_buff *skb)
{
	sch->qstats.backlog += qdisc_pkt_len(skb);
}

//include/net/sch_generic.h:869
static inline void qdisc_qstats_cpu_backlog_inc(struct Qdisc *sch,
						const struct sk_buff *skb)
{
	this_cpu_add(sch->cpu_qstats->backlog, qdisc_pkt_len(skb));
}

//include/net/sch_generic.h:885
static inline void qdisc_qstats_cpu_requeues_inc(struct Qdisc *sch)
{
	this_cpu_inc(sch->cpu_qstats->requeues);
}

//include/net/sch_generic.h:144
static inline bool qdisc_is_percpu_stats(const struct Qdisc *q)
{
	//pfifo默认情况下设置了该标志
	return q->flags & TCQ_F_CPUSTATS;
}

//net/core/dev.c:3205
//若first对应的skb链表（单纯的skb链表并无sk_buff_head结构）都发送完毕，则返回NULL，ret=NETDEV_TX_OK
//若first对应的skb链表没有全发送完，则返回链表中第一个未发送的skb以及以其为首的子链表，ret=NETDEV_TX_BUSY
struct sk_buff *dev_hard_start_xmit(struct sk_buff *first, struct net_device *dev,
				    struct netdev_queue *txq, int *ret)
{
	struct sk_buff *skb = first;
	int rc = NETDEV_TX_OK;

	while (skb) 
	{
		struct sk_buff *next = skb->next;

		skb_mark_not_on_list(skb);
		
		rc = xmit_one(skb, dev, txq, next != NULL);
		
		if (unlikely(!dev_xmit_complete(rc))) 
		{
			skb->next = next;
			goto out;
		}

		skb = next;
		if (netif_tx_queue_stopped(txq) && skb) 
		{
			rc = NETDEV_TX_BUSY;
			break;
		}
	}

out:
	*ret = rc;
	return skb;
};

//include/linux/netdevice.h:118
/*
 * Current order: NETDEV_TX_MASK > NET_XMIT_MASK >= 0 is significant;
 * hard_start_xmit() return < NET_XMIT_MASK means skb was consumed.
 */
static inline bool dev_xmit_complete(int rc)
{
	/*
	 * Positive cases with an skb consumed by a driver:
	 * - successful transmission (rc == NETDEV_TX_OK)
	 * - error while transmitting (rc < 0)
	 * - error while queueing to a different device (rc & NET_XMIT_MASK)
	 */
	if (likely(rc < NET_XMIT_MASK))
		return true;

	return false;
}

//net/core/dev.c:3188
static int xmit_one(struct sk_buff *skb, struct net_device *dev,
		    struct netdev_queue *txq, bool more)
{
	unsigned int len;
	int rc;

	//检测是否有截获数据包的回调函数注册
	//注意，发送帧的截获，只有ptype_all或net_device结构的ptype_all
	if (dev_nit_active(dev))
		//分别遍历ptype_all和net_device结构ptype_all链表，调用截获帧的回调函数
		dev_queue_xmit_nit(skb, dev);

	len = skb->len;
	
	trace_net_dev_start_xmit(skb, dev);
	
	rc = netdev_start_xmit(skb, dev, txq, more);
	
	trace_net_dev_xmit(skb, rc, dev, len);

	return rc;
};

//include/linux/netdevice.h:4421
static inline netdev_tx_t netdev_start_xmit(struct sk_buff *skb, struct net_device *dev,
					    struct netdev_queue *txq, bool more)
{
	const struct net_device_ops *ops = dev->netdev_ops;
	netdev_tx_t rc;

	rc = __netdev_start_xmit(ops, skb, dev, more);

	if (rc == NETDEV_TX_OK)
		txq_trans_update(txq);

	return rc;
};

//include/linux/netdevice.h:3938
static inline void txq_trans_update(struct netdev_queue *txq)
{
	if (txq->xmit_lock_owner != -1)
		txq->trans_start = jiffies;
}

//include/linux/netdevice.h:4408
static inline netdev_tx_t __netdev_start_xmit(const struct net_device_ops *ops,
					      struct sk_buff *skb, struct net_device *dev,
					      bool more)
{
	__this_cpu_write(softnet_data.xmit.more, more);
	return ops->ndo_start_xmit(skb, dev);
};

//include/linux/netdevice.h:3129
/**
 *	netif_stop_queue - stop transmitted packets
 *	@dev: network device
 *
 *	Stop upper layers calling the device hard_start_xmit routine.
 *	Used for flow control when transmit resources are unavailable.
 */
static inline void netif_stop_queue(struct net_device *dev)
{
	netif_tx_stop_queue(netdev_get_tx_queue(dev, 0));
} 

//include/linux/netdevice.h:3117
static __always_inline void netif_tx_stop_queue(struct netdev_queue *dev_queue)
{
	set_bit(__QUEUE_STATE_DRV_XOFF, &dev_queue->state);
}

//net/core/dev.c:1938
/*
 *	Support routine. Sends outgoing frames to any network
 *	taps currently in use.
 */
//分别遍历ptype_all和net_device结构ptype_all链表，调用截获帧的回调函数
//注意传递给回调函数的skb结构，是调用skb_clone()而来的
void dev_queue_xmit_nit(struct sk_buff *skb, struct net_device *dev)
{
	struct packet_type *ptype;
	struct sk_buff *skb2 = NULL;
	struct packet_type *pt_prev = NULL;
	struct list_head *ptype_list = &ptype_all;

	rcu_read_lock();
again:
	list_for_each_entry_rcu(ptype, ptype_list, list) 
	{
		if (ptype->ignore_outgoing)
			continue;

		/* Never send packets back to the socket
		 * they originated from - MvS (miquels@drinkel.ow.org)
		 */
		if (skb_loop_sk(ptype, skb))
			continue;

		if (pt_prev) 
		{
			//将原来的skb clone后并设置新skb头部结构，传递给packet_type结构的func回调函数
			deliver_skb(skb2, pt_prev, skb->dev);
			pt_prev = ptype;
			continue;
		}

		/* need to clone skb, done only once */
		skb2 = skb_clone(skb, GFP_ATOMIC);
		if (!skb2)
			goto out_unlock;

		net_timestamp_set(skb2);

		/* skb->nh should be correctly
		 * set by sender, so that the second statement is
		 * just protection against buggy protocols.
		 */
		skb_reset_mac_header(skb2);

		//重新调整clone得到的skb的布局字段
		if (skb_network_header(skb2) < skb2->data ||
		    skb_network_header(skb2) > skb_tail_pointer(skb2)) 
		{
			net_crit_ratelimited("protocol %04x is buggy, dev %s\n",
					     ntohs(skb2->protocol),
					     dev->name);
			skb_reset_network_header(skb2);
		}

		skb2->transport_header = skb2->network_header;
		skb2->pkt_type = PACKET_OUTGOING;
		pt_prev = ptype;
	}

	if (ptype_list == &ptype_all) {
		ptype_list = &dev->ptype_all;
		goto again;
	}
out_unlock:
	if (pt_prev) {
		if (!skb_orphan_frags_rx(skb2, GFP_ATOMIC))
			pt_prev->func(skb2, skb->dev, pt_prev, skb->dev);
		else
			kfree_skb(skb2);
	}
	rcu_read_unlock();
}
EXPORT_SYMBOL_GPL(dev_queue_xmit_nit);

//include/linux/skbuff.h:2473
static inline unsigned char *skb_network_header(const struct sk_buff *skb)
{
	return skb->head + skb->network_header;
}

//net/core/dev.c:1810
static inline void net_timestamp_set(struct sk_buff *skb)
{
	skb->tstamp = 0;
	if (static_branch_unlikely(&netstamp_needed_key))
		__net_timestamp(skb);
}

//net/core/dev.c:1909
static inline bool skb_loop_sk(struct packet_type *ptype, struct sk_buff *skb)
{
	if (!ptype->af_packet_priv || !skb->sk)
		return false;

	if (ptype->id_match)
		return ptype->id_match(ptype, skb->sk);
	else if ((struct sock *)ptype->af_packet_priv == skb->sk)
		return true;

	return false;
}

//net/core/dev.c:1927
/**
 * dev_nit_active - return true if any network interface taps are in use
 *
 * @dev: network device to check for the presence of taps
 */
//检测是否有截获数据包的回调函数注册
//注意，发送帧的截获，只有ptype_all或net_device结构的ptype_all
bool dev_nit_active(struct net_device *dev)
{
	return !list_empty(&ptype_all) || !list_empty(&dev->ptype_all);
}
EXPORT_SYMBOL_GPL(dev_nit_active);

//include/linux/netdevice.h:3158
static inline bool netif_xmit_frozen_or_stopped(const struct netdev_queue *dev_queue)
{
	return dev_queue->state & QUEUE_STATE_ANY_XOFF_OR_FROZEN;
}

//include/linux/netdevice.h:4010
#define HARD_TX_LOCK(dev, txq, cpu) {			\
	if ((dev->features & NETIF_F_LLTX) == 0) {	\
		__netif_tx_lock(txq, cpu);		\
	} else {					\
		__netif_tx_acquire(txq);		\
	}						\
}

//include/linux/netdevice.h:3901
static inline bool __netif_tx_acquire(struct netdev_queue *txq)
{
	__acquire(&txq->_xmit_lock);
	return true;
}

//net/core/dev.c:3308
struct sk_buff *validate_xmit_skb_list(struct sk_buff *skb, struct net_device *dev, bool *again)
{
	struct sk_buff *next, *head = NULL, *tail;

	for (; skb != NULL; skb = next)
	{
		next = skb->next;
		
		skb_mark_not_on_list(skb);

		/* in case skb wont be segmented, point to itself */
		skb->prev = skb;

		skb = validate_xmit_skb(skb, dev, again);
	
		if (!skb)
			continue;

		if (!head)
			head = skb;
		else
			tail->next = skb;
		/* If skb was segmented, skb->prev points to
		 * the last segment. If not, it still contains skb.
		 */
		tail = skb->prev;
	}
	return head;
}
EXPORT_SYMBOL_GPL(validate_xmit_skb_list);

//net/core/dev.c:3253
static struct sk_buff *validate_xmit_skb(struct sk_buff *skb, struct net_device *dev, bool *again)
{
	netdev_features_t features;

	//获取NIC所能支持的、内核开启了的各种feature
	features = netif_skb_features(skb);

	skb = validate_xmit_vlan(skb, features);
	if (unlikely(!skb))
		goto out_null;

	skb = sk_validate_xmit_skb(skb, dev);
	if (unlikely(!skb))
		goto out_null;

	if (netif_needs_gso(skb, features)) 
	{
		struct sk_buff *segs;

		//软件进行分段，segs保存软件分段后得到的skb链表
		segs = skb_gso_segment(skb, features);

		if (IS_ERR(segs)) 
		{
			goto out_kfree_skb;
		} 
		else if (segs) 
		{
			consume_skb(skb);//释放skb
			skb = segs;
		}
	} 
	else 
	{
		if (skb_needs_linearize(skb, features) &&  __skb_linearize(skb))
			goto out_kfree_skb;

		/* If packet is not checksummed and device does not
		 * support checksumming for this protocol, complete
		 * checksumming here.
		 */
		if (skb->ip_summed == CHECKSUM_PARTIAL) 
		{
			if (skb->encapsulation)
				skb_set_inner_transport_header(skb,
							       skb_checksum_start_offset(skb));
			else
				skb_set_transport_header(skb,
							 skb_checksum_start_offset(skb));
			if (skb_csum_hwoffload_help(skb, features))
				goto out_kfree_skb;
		}
	}

	skb = validate_xmit_xfrm(skb, features, again);

	return skb;

out_kfree_skb:
	kfree_skb(skb);
out_null:
	atomic_long_inc(&dev->tx_dropped);
	return NULL;
}

//include/linux/netdevice.h:4531
static inline bool netif_needs_gso(struct sk_buff *skb,
				   netdev_features_t features)
{
	return skb_is_gso(skb) && (!skb_gso_ok(skb, features) ||
		unlikely((skb->ip_summed != CHECKSUM_PARTIAL) &&
			 (skb->ip_summed != CHECKSUM_UNNECESSARY)));
}

static inline bool skb_gso_ok(struct sk_buff *skb, netdev_features_t features)
{
	return net_gso_ok(features, skb_shinfo(skb)->gso_type) &&
	       (!skb_has_frag_list(skb) || (features & NETIF_F_FRAGLIST));
}

static inline bool net_gso_ok(netdev_features_t features, int gso_type)
{
	netdev_features_t feature = (netdev_features_t)gso_type << NETIF_F_GSO_SHIFT;

	/* check flags correspondence */
	BUILD_BUG_ON(SKB_GSO_TCPV4   != (NETIF_F_TSO >> NETIF_F_GSO_SHIFT));
	BUILD_BUG_ON(SKB_GSO_DODGY   != (NETIF_F_GSO_ROBUST >> NETIF_F_GSO_SHIFT));
	BUILD_BUG_ON(SKB_GSO_TCP_ECN != (NETIF_F_TSO_ECN >> NETIF_F_GSO_SHIFT));
	BUILD_BUG_ON(SKB_GSO_TCP_FIXEDID != (NETIF_F_TSO_MANGLEID >> NETIF_F_GSO_SHIFT));
	BUILD_BUG_ON(SKB_GSO_TCPV6   != (NETIF_F_TSO6 >> NETIF_F_GSO_SHIFT));
	BUILD_BUG_ON(SKB_GSO_FCOE    != (NETIF_F_FSO >> NETIF_F_GSO_SHIFT));
	BUILD_BUG_ON(SKB_GSO_GRE     != (NETIF_F_GSO_GRE >> NETIF_F_GSO_SHIFT));
	BUILD_BUG_ON(SKB_GSO_GRE_CSUM != (NETIF_F_GSO_GRE_CSUM >> NETIF_F_GSO_SHIFT));
	BUILD_BUG_ON(SKB_GSO_IPXIP4  != (NETIF_F_GSO_IPXIP4 >> NETIF_F_GSO_SHIFT));
	BUILD_BUG_ON(SKB_GSO_IPXIP6  != (NETIF_F_GSO_IPXIP6 >> NETIF_F_GSO_SHIFT));
	BUILD_BUG_ON(SKB_GSO_UDP_TUNNEL != (NETIF_F_GSO_UDP_TUNNEL >> NETIF_F_GSO_SHIFT));
	BUILD_BUG_ON(SKB_GSO_UDP_TUNNEL_CSUM != (NETIF_F_GSO_UDP_TUNNEL_CSUM >> NETIF_F_GSO_SHIFT));
	BUILD_BUG_ON(SKB_GSO_PARTIAL != (NETIF_F_GSO_PARTIAL >> NETIF_F_GSO_SHIFT));
	BUILD_BUG_ON(SKB_GSO_TUNNEL_REMCSUM != (NETIF_F_GSO_TUNNEL_REMCSUM >> NETIF_F_GSO_SHIFT));
	BUILD_BUG_ON(SKB_GSO_SCTP    != (NETIF_F_GSO_SCTP >> NETIF_F_GSO_SHIFT));
	BUILD_BUG_ON(SKB_GSO_ESP != (NETIF_F_GSO_ESP >> NETIF_F_GSO_SHIFT));
	BUILD_BUG_ON(SKB_GSO_UDP != (NETIF_F_GSO_UDP >> NETIF_F_GSO_SHIFT));
	BUILD_BUG_ON(SKB_GSO_UDP_L4 != (NETIF_F_GSO_UDP_L4 >> NETIF_F_GSO_SHIFT));

	return (features & feature) == feature;
}

//include/net/sock.h:2503
/* Checks if this SKB belongs to an HW offloaded socket
 * and whether any SW fallbacks are required based on dev.
 * Check decrypted mark in case skb_orphan() cleared socket.
 */
static inline struct sk_buff *sk_validate_xmit_skb(struct sk_buff *skb,
						   struct net_device *dev)
{
#ifdef CONFIG_SOCK_VALIDATE_XMIT
	struct sock *sk = skb->sk;

	if (sk && sk_fullsock(sk) && sk->sk_validate_xmit_skb) {
		skb = sk->sk_validate_xmit_skb(sk, dev, skb);
#ifdef CONFIG_TLS_DEVICE
	} else if (unlikely(skb->decrypted)) {
		pr_warn_ratelimited("unencrypted skb with no associated socket - dropping\n");
		kfree_skb(skb);
		skb = NULL;
#endif
	}
#endif

	return skb;
}

//net/core/dev.c:3157
netdev_features_t netif_skb_features(struct sk_buff *skb)
{
	struct net_device *dev = skb->dev;

	//通常此时为NETIF_F_GRO
	netdev_features_t features = dev->features;

	if (skb_is_gso(skb))
		features = gso_features_check(skb, dev, features);

、	/* If encapsulation offload request, verify we are testing
	 * hardware encapsulation features instead of standard
	 * features for the netdev
	 */
	if (skb->encapsulation)
		features &= dev->hw_enc_features;

	if (skb_vlan_tagged(skb))
		features = netdev_intersect_features(features,
						     dev->vlan_features |
						     NETIF_F_HW_VLAN_CTAG_TX |
						     NETIF_F_HW_VLAN_STAG_TX);

	if (dev->netdev_ops->ndo_features_check)
		features &= dev->netdev_ops->ndo_features_check(skb, dev,
								features);
	else
		features &= dflt_features_check(skb, dev, features);

	return harmonize_features(skb, features);
}
EXPORT_SYMBOL(netif_skb_features);

//net/core/dev.c:3154
static netdev_features_t gso_features_check(const struct sk_buff *skb,
					    struct net_device *dev,
					    netdev_features_t features)
{
	u16 gso_segs = skb_shinfo(skb)->gso_segs;

	//判断分段个数是否大于65535
	//若是则将GSO相关的若干标志关闭
	if (gso_segs > dev->gso_max_segs)
		return features & ~NETIF_F_GSO_MASK;

	/* Support for GSO partial features requires software
	 * intervention before we can actually process the packets
	 * so we need to strip support for any partial features now
	 * and we can pull them back in after we have partially
	 * segmented the frame.
	 */
	if (!(skb_shinfo(skb)->gso_type & SKB_GSO_PARTIAL))
		features &= ~dev->gso_partial_features;

	/* Make sure to clear the IPv4 ID mangling feature if the
	 * IPv4 header has the potential to be fragmented.
	 */
	if (skb_shinfo(skb)->gso_type & SKB_GSO_TCPV4) 
	{
		struct iphdr *iph = skb->encapsulation ?
				    inner_ip_hdr(skb) : ip_hdr(skb);

		if (!(iph->frag_off & htons(IP_DF)))
			features &= ~NETIF_F_TSO_MANGLEID;
	}

	return features;
}


//include/linux/skbuff.h:1476
static inline void skb_mark_not_on_list(struct sk_buff *skb)
{
	skb->next = NULL;
}

//include/net/sch_generic.h:839
//设置qdisc结构cpu_bstats->bstats.bytes = 要发送的帧长度（如果使用了GSO，则考虑了所有分段）
//设置qdisc结构cpu_bstats->bstats.packets = 即要发送的帧的个数。如果使用了GSO，则等于skb_shinfo(skb)->gso_segs；否则，等于1
static inline void qdisc_bstats_cpu_update(struct Qdisc *sch, const struct sk_buff *skb)
{
	bstats_cpu_update(this_cpu_ptr(sch->cpu_bstats), skb);
}

//include/net/sch_generic.h:831
static inline void bstats_cpu_update(struct gnet_stats_basic_cpu *bstats,
				     const struct sk_buff *skb)
{
	u64_stats_update_begin(&bstats->syncp);
	
	bstats_update(&bstats->bstats, skb);
	
	u64_stats_update_end(&bstats->syncp);
}

//include/net/sch_generic.h:815
static inline void bstats_update(struct gnet_stats_basic_packed *bstats, const struct sk_buff *skb)
{
	_bstats_update(bstats,
		       qdisc_pkt_len(skb),
		       skb_is_gso(skb) ? skb_shinfo(skb)->gso_segs : 1);
}

//include/linux/u64_stats_sync.h:79
static inline void u64_stats_update_begin(struct u64_stats_sync *syncp)
{
#if BITS_PER_LONG==32 && defined(CONFIG_SMP)
	write_seqcount_begin(&syncp->seq);
#endif
}

//include/linux/u64_stats_sync.h:86
static inline void u64_stats_update_end(struct u64_stats_sync *syncp)
{
#if BITS_PER_LONG==32 && defined(CONFIG_SMP)
	write_seqcount_end(&syncp->seq);
#endif
}

//include/net/sch_generic.h:808
static inline void _bstats_update(struct gnet_stats_basic_packed *bstats,
				  __u64 bytes, __u32 packets)
{
	bstats->bytes += bytes;
	bstats->packets += packets;
}

//include/linux/skbuff.h:4384
static inline bool skb_is_gso(const struct sk_buff *skb)
{
	return skb_shinfo(skb)->gso_size;
}

//include/net/sch_generic.h:773
//返回要发送的帧长度，如果使用了GSO，则考虑了所有的分段
static inline unsigned int qdisc_pkt_len(const struct sk_buff *skb)
{
	return qdisc_skb_cb(skb)->pkt_len;
}

static inline bool qdisc_run_begin(struct Qdisc *qdisc)
{
	//设置了该标志
	if (qdisc->flags & TCQ_F_NOLOCK) 
	{
		if (!spin_trylock(&qdisc->seqlock))
			return false;
		
		qdisc->empty = false;
	} 
	else if (qdisc_is_running(qdisc)) 
	{
		return false;
	}
	
	/* Variant of write_seqcount_begin() telling lockdep a trylock
	 * was attempted.
	 */
	raw_write_seqcount_begin(&qdisc->running);

	//未定义CONFIG_LOCKDEP，为空
	seqcount_acquire(&qdisc->running.dep_map, 0, 1, _RET_IP_);

	return true;
}

//include/linux/seqlock.h:226
static inline void raw_write_seqcount_begin(seqcount_t *s)
{
	s->sequence++;
	smp_wmb();
}

//include/net/sch_generic.h:790
static inline void qdisc_calculate_pkt_len(struct sk_buff *skb,
					   const struct Qdisc *sch)
{
	//pfifo规则中，stab字段为NULL
	struct qdisc_size_table *stab = rcu_dereference_bh(sch->stab);

	if (stab)
		__qdisc_calculate_pkt_len(skb, stab);
}

//include/net/sch_generic.h:489
static inline spinlock_t *qdisc_lock(struct Qdisc *qdisc)
{
	return &qdisc->q.lock;
}

//net/core/dev.c:3663
struct netdev_queue *netdev_core_pick_tx(struct net_device *dev,
					 struct sk_buff *skb,
					 struct net_device *sb_dev)
{
	int queue_index = 0;

#ifdef CONFIG_XPS
	u32 sender_cpu = skb->sender_cpu - 1;

	if (sender_cpu >= (u32)NR_CPUS)
		skb->sender_cpu = raw_smp_processor_id() + 1;
#endif

	//一般，net_device结构的real_num_tx_queues=1
	//暂时不考虑多队列
	if (dev->real_num_tx_queues != 1) 
	{
		const struct net_device_ops *ops = dev->netdev_ops;

		if (ops->ndo_select_queue)
			queue_index = ops->ndo_select_queue(dev, skb, sb_dev);
		else
			queue_index = netdev_pick_tx(dev, skb, sb_dev);

		queue_index = netdev_cap_txqueue(dev, queue_index);
	}

	skb_set_queue_mapping(skb, queue_index);

	return netdev_get_tx_queue(dev, queue_index);
}

//include/linux/skbuff.h:4266
static inline void skb_set_queue_mapping(struct sk_buff *skb, u16 queue_mapping)
{
	skb->queue_mapping = queue_mapping;
}

//include/net/dst.h:268
/**
 * skb_dst_drop - drops skb dst
 * @skb: buffer
 *
 * Drops dst reference count if a reference was taken.
 */
static inline void skb_dst_drop(struct sk_buff *skb)
{
	if (skb->_skb_refdst) {
		refdst_drop(skb->_skb_refdst);
		skb->_skb_refdst = 0UL;
	}
}

//net/core/dev.c:3336
//根据分段数量重新计算应发报文大小，即
//原传递的一个完整skb所示的报文大小，再加上（分段数量-1）*（MAC头部大小 + 网络层头部大小 + 传输层头部（TCP或UDP）大小）
static void qdisc_pkt_len_init(struct sk_buff *skb)
{
	const struct skb_shared_info *shinfo = skb_shinfo(skb);

	qdisc_skb_cb(skb)->pkt_len = skb->len;

	/* To get more precise estimation of bytes sent on wire,
	 * we add to pkt_len the headers size of all segments
	 */
	 
	if (shinfo->gso_size && skb_transport_header_was_set(skb)) 
	{
		unsigned int hdr_len;
		u16 gso_segs = shinfo->gso_segs;
		
		//MAC头部大小 + 网络层头部大小
		hdr_len = skb_transport_header(skb) - skb_mac_header(skb);

		/* + transport layer */
		if (likely(shinfo->gso_type & (SKB_GSO_TCPV4 | SKB_GSO_TCPV6))) 
		{
			const struct tcphdr *th;
			struct tcphdr _tcphdr;

			//返回传输层头部地址，头部可能copy到_tcphdr中，可能没有拷贝
			th = skb_header_pointer(skb, skb_transport_offset(skb), sizeof(_tcphdr), &_tcphdr);
			
			if (likely(th))
				//再加上TCP头部
				hdr_len += __tcp_hdrlen(th);
		} 
		else 
		{
			struct udphdr _udphdr;

			if (skb_header_pointer(skb, skb_transport_offset(skb), sizeof(_udphdr), &_udphdr))		
				hdr_len += sizeof(struct udphdr);
		}

		//此时，hdr_len = MAC头部大小 + 网络层头部大小 + 传输层头部（TCP或UDP）

		//若gso_type设置了SKB_GSO_DODGY，即表示skb来源于不可信之源，重新计算分段数量
		if (shinfo->gso_type & SKB_GSO_DODGY)
			gso_segs = DIV_ROUND_UP(skb->len - hdr_len, shinfo->gso_size);

		//根据分段数量重新计算应发报文大小，即
		//原传递的一个完整skb所示的报文大小，再加上（分段数量-1）*（MAC头部大小 + 网络层头部大小 + 传输层头部（TCP或UDP））
		qdisc_skb_cb(skb)->pkt_len += (gso_segs - 1) * hdr_len;
	}
}

//include/linux/skbuff.h:3573
//返回传输层头部地址，头部可能copy到buffer中，可能没有拷贝
static inline void * __must_check
skb_header_pointer(const struct sk_buff *skb, int offset, int len, void *buffer)
{
	return __skb_header_pointer(skb, offset, len, skb->data, skb_headlen(skb), buffer);
}

//include/linux/skbuff.h:3559
static inline void * __must_check
__skb_header_pointer(const struct sk_buff *skb, int offset,
		     int len, void *data, int hlen, void *buffer)
{
	if (hlen - offset >= len)
		return data + offset;

	if (!skb ||
	    skb_copy_bits(skb, offset, buffer, len) < 0)
		return NULL;

	return buffer;
}

//include/linux/skbuff.h:2557
//获取传输层头部相对于skb->data字段的偏移量
static inline int skb_transport_offset(const struct sk_buff *skb)
{
	return skb_transport_header(skb) - skb->data;
}

//include/linux/skbuff.h:2489
//获取MAC头部的地址
static inline unsigned char *skb_mac_header(const struct sk_buff *skb)
{
	return skb->head + skb->mac_header;
}

//include/linux/skbuff.h:2456
//获取传输层头部的地址
static inline unsigned char *skb_transport_header(const struct sk_buff *skb)
{
	return skb->head + skb->transport_header;
}

//include/net/sch_generic.h:484
static inline struct qdisc_skb_cb *qdisc_skb_cb(const struct sk_buff *skb)
{
	return (struct qdisc_skb_cb *)skb->cb;
}

//net/core/dev.c:3469
static void skb_update_prio(struct sk_buff *skb)
{
	const struct netprio_map *map;
	const struct sock *sk;
	unsigned int prioidx;

	if (skb->priority)
		return;
	
	map = rcu_dereference_bh(skb->dev->priomap);
	if (!map)
		return;
	
	sk = skb_to_full_sk(skb);
	if (!sk)
		return;

	prioidx = sock_cgroup_prioidx(&sk->sk_cgrp_data);

	if (prioidx < map->priomap_len)
		skb->priority = map->priomap[prioidx];
}

//include/linux/netdevice.h:3148
/**
 *	netif_queue_stopped - test if transmit queue is flowblocked
 *	@dev: network device
 *
 *	Test if transmit queue on device is currently unable to send.
 */;
static inline bool netif_queue_stopped(const struct net_device *dev)
{
		return netif_tx_queue_stopped(netdev_get_tx_queue(dev, 0));
}

//include/linux/netdevice.h:3137
static inline bool netif_tx_queue_stopped(const struct netdev_queue *dev_queue)
{
	return test_bit(__QUEUE_STATE_DRV_XOFF, &dev_queue->state);
}

//include/linux/netdevice.h:3102
/**
 *	netif_wake_queue - restart transmit
 *	@dev: network device
 *
 *	Allow upper layers to call the device hard_start_xmit routine.
 *	Used for flow control when transmit resources are available.
 */
static inline void netif_wake_queue(struct net_device *dev)
{
	netif_tx_wake_queue(netdev_get_tx_queue(dev, 0));
}

//net/core/dev.c:2702
void netif_tx_wake_queue(struct netdev_queue *dev_queue)
{
	if (test_and_clear_bit(__QUEUE_STATE_DRV_XOFF, &dev_queue->state)) 
	{
		struct Qdisc *q;

		rcu_read_lock();
		q = rcu_dereference(dev_queue->qdisc);
		__netif_schedule(q);
		rcu_read_unlock();
	}
}
EXPORT_SYMBOL(netif_tx_wake_queue);

//net/core/dev.c:2674
//通常是将net_device._tx[0].qdisc，放入当前cpu的softnet_data.output_queue链表中
//触发软中断NET_TX_SOFTIRQ，若不处于中断或软中断上下文，则启动ksoftirqd线程
void __netif_schedule(struct Qdisc *q)
{
	if (!test_and_set_bit(__QDISC_STATE_SCHED, &q->state))
		__netif_reschedule(q);
}
EXPORT_SYMBOL(__netif_schedule);

//net/core/dev.c:2660
static void __netif_reschedule(struct Qdisc *q)
{
	struct softnet_data *sd;
	unsigned long flags;

	local_irq_save(flags);
	
	sd = this_cpu_ptr(&softnet_data);
	
	q->next_sched = NULL;
	
	*sd->output_queue_tailp = q;
	
	sd->output_queue_tailp = &q->next_sched;
	
	raise_softirq_irqoff(NET_TX_SOFTIRQ);
	
	local_irq_restore(flags);
}

//kernel/softirq.c:423
/*
 * This function must run with irqs disabled!
 */
inline void raise_softirq_irqoff(unsigned int nr)
{
	__raise_softirq_irqoff(nr);

	/*
	 * If we're in an interrupt or softirq, we're done
	 * (this also catches softirq-disabled code). We will
	 * actually run the softirq once we return from
	 * the irq or softirq.
	 *
	 * Otherwise we wake up ksoftirqd to make sure we
	 * schedule the softirq soon.
	 */
	if (!in_interrupt())
		wakeup_softirqd();
}

//net/core/dev.c:4495
static __latent_entropy void net_tx_action(struct softirq_action *h)
{
	struct softnet_data *sd = this_cpu_ptr(&softnet_data);

	if (sd->completion_queue) 
	{
		struct sk_buff *clist;

		local_irq_disable();
		clist = sd->completion_queue;
		sd->completion_queue = NULL;
		local_irq_enable();

		while (clist) 
		{
			struct sk_buff *skb = clist;

			clist = clist->next;

			WARN_ON(refcount_read(&skb->users));
			
			if (likely(get_kfree_skb_cb(skb)->reason == SKB_REASON_CONSUMED))
				trace_consume_skb(skb);
			else
				trace_kfree_skb(skb, net_tx_action);

			if (skb->fclone != SKB_FCLONE_UNAVAILABLE)
				__kfree_skb(skb);
			else
				__kfree_skb_defer(skb);
		}

		__kfree_skb_flush();
	}

	if (sd->output_queue) 
	{
		struct Qdisc *head;

		local_irq_disable();
		head = sd->output_queue;
		sd->output_queue = NULL;
		sd->output_queue_tailp = &sd->output_queue;
		local_irq_enable();

		while (head) 
		{
			struct Qdisc *q = head;
			spinlock_t *root_lock = NULL;

			head = head->next_sched;

			if (!(q->flags & TCQ_F_NOLOCK)) 
			{
				root_lock = qdisc_lock(q);
				spin_lock(root_lock);
			}
			
			/* We need to make sure head->next_sched is read
			 * before clearing __QDISC_STATE_SCHED
			 */
			smp_mb__before_atomic();
			
			clear_bit(__QDISC_STATE_SCHED, &q->state);
			
			qdisc_run(q);
			
			if (root_lock)
				spin_unlock(root_lock);
		}
	}

	xfrm_dev_backlog(sd);
}

#endif

#if 1 //超时处理dev_watchdog和pcnet32_tx_timeout回调

//net/sched/sch_generic.c:418
//在register_netdev()中设置了定时器net_device.watchdog_timer的回调函数为dev_watchdog
//在dev_open()中设置了该定时器的超时值net_device.watchdog_timeo，pcnet32中设为5秒
//
static void dev_watchdog(struct timer_list *t)
{
	struct net_device *dev = from_timer(dev, t, watchdog_timer);

	netif_tx_lock(dev);

	//默认设置pfifo_fast，会进入if子句
	if (!qdisc_tx_is_noop(dev)) 
	{
		if (netif_device_present(dev) && netif_running(dev) && netif_carrier_ok(dev)) 
		{
			int some_queue_timedout = 0;
			unsigned int i;
			unsigned long trans_start;

			for (i = 0; i < dev->num_tx_queues; i++) 
			{
				struct netdev_queue *txq;

				txq = netdev_get_tx_queue(dev, i);

				//获取最近一次该队列发送帧的时间
				trans_start = txq->trans_start;

				//若网络设备已经停止，且自最近一次发送帧以来已经超过了设定的超时值net_device.watchdog_timeo
				//则会调用回调函数net_device.netdev_ops->ndo_tx_timeout
				if (netif_xmit_stopped(txq) &&
				    time_after(jiffies, (trans_start + dev->watchdog_timeo))) 
				{
					some_queue_timedout = 1;
					txq->trans_timeout++;
					break;
				}
			}

			if (some_queue_timedout) 
			{
				trace_net_dev_xmit_timeout(dev, i);
				WARN_ONCE(1, KERN_INFO "NETDEV WATCHDOG: %s (%s): transmit queue %u timed out\n",
				       dev->name, netdev_drivername(dev), i);

				//比如pcnet32中调用pcnet32_tx_timeout
				dev->netdev_ops->ndo_tx_timeout(dev);
			}
			if (!mod_timer(&dev->watchdog_timer,
				       round_jiffies(jiffies +
						     dev->watchdog_timeo)))
				dev_hold(dev);
		}
	}
	netif_tx_unlock(dev);

	dev_put(dev);
}

//include/linux/netdevice.h:3153
static inline bool netif_xmit_stopped(const struct netdev_queue *dev_queue)
{
	return dev_queue->state & QUEUE_STATE_ANY_XOFF;
}

//include/net/sch_generic.h:761
static inline bool qdisc_tx_is_noop(const struct net_device *dev)
{
	unsigned int i;

	for (i = 0; i < dev->num_tx_queues; i++) 
	{
		struct netdev_queue *txq = netdev_get_tx_queue(dev, i);
		
		if (rcu_access_pointer(txq->qdisc) != &noop_qdisc)
			return false;
	}
	
	return true;
}

//include/linux/netdevice.h:3959
/**
 *	netif_tx_lock - grab network device transmit lock
 *	@dev: network device
 *
 * Get network device transmit lock
 */
static inline void netif_tx_lock(struct net_device *dev)
{
	unsigned int i;
	int cpu;

	spin_lock(&dev->tx_global_lock);
	
	cpu = smp_processor_id();
	
	for (i = 0; i < dev->num_tx_queues; i++) 
	{
		struct netdev_queue *txq = netdev_get_tx_queue(dev, i);

		/* We are the only thread of execution doing a
		 * freeze, but we have to grab the _xmit_lock in
		 * order to synchronize with threads which are in
		 * the ->hard_start_xmit() handler and already
		 * checked the frozen bit.
		 */
		__netif_tx_lock(txq, cpu);
		
		set_bit(__QUEUE_STATE_FROZEN, &txq->state);

		__netif_tx_unlock(txq);
	}
}

//include/linux/netdevice.h:3895
static inline void __netif_tx_lock(struct netdev_queue *txq, int cpu)
{
	spin_lock(&txq->_xmit_lock);
	txq->xmit_lock_owner = cpu;
}

//include/linux/netdevice.h:3926
static inline void __netif_tx_unlock(struct netdev_queue *txq)
{
	txq->xmit_lock_owner = -1;
	spin_unlock(&txq->_xmit_lock);
}

//include/linux/netdevice.h:3875
#define netif_msg_tx_err(p)	((p)->msg_enable & NETIF_MSG_TX_ERR)

#endif