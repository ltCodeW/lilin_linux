#if 1 //initcall启动顺序定义

//include/asm-generic/vmlinux.lds.h：806
//定义了各个初始化段的顺序，初始化函数的调用即按照此顺序，先调用early，然后是0、0s、1、1s等
#define INIT_CALLS                          \
        __initcall_start = .;               \
        KEEP(*(.initcallearly.init))        \

		//例如：
		//__initcall0_start = .
		//KEEP(*(.initcall0.init))
		//KEEP(*(.initcall0s.init))
        INIT_CALLS_LEVEL(0)                 \
        
        INIT_CALLS_LEVEL(1)                 \
        INIT_CALLS_LEVEL(2)                 \
        INIT_CALLS_LEVEL(3)                 \
        INIT_CALLS_LEVEL(4)                 \
        INIT_CALLS_LEVEL(5)                 \
        INIT_CALLS_LEVEL(rootfs)            \
        INIT_CALLS_LEVEL(6)                 \
        INIT_CALLS_LEVEL(7)                 \
        __initcall_end = .;

//include/asm-generic/vmlinux.lds.h：801
#define INIT_CALLS_LEVEL(level)                     		\
				__initcall##level##_start = .;				\
				KEEP(*(.initcall##level##.init))			\
				KEEP(*(.initcall##level##s.init))			\

//include/asm-generic/vmlinux.lds.h：986
#define INIT_DATA_SECTION(initsetup_align)              \
    .init.data : AT(ADDR(.init.data) - LOAD_OFFSET) {       \
        INIT_DATA                       \
        INIT_SETUP(initsetup_align)             \
        INIT_CALLS                      \
        CON_INITCALL                        \
        INIT_RAM_FS                     \
    }

//arch/x86/kernel/vmlinux.lds.S：248
INIT_DATA_SECTION(16)
/*
即形成；
* SECTIONS
* {
*  . = START;
*  __init_begin = .;
*  HEAD_TEXT_SECTION
*  INIT_TEXT_SECTION(PAGE_SIZE)
*  INIT_DATA_SECTION(...)
*  PERCPU_SECTION(CACHELINE_SIZE)
*  __init_end = .;
* ..........................
*/

//include/linux/init.h：216
/*
 * A "pure" initcall has no dependencies on anything else, and purely
 * initializes variables that couldn't be statically initialized.
 *
 * This only exists for built-in code, not for modules.
 * Keep main.c:initcall_level_names[] in sync.
 */
/*
对于pure_initcall(net_ns_init);展开：
static void * __section(.discard.addressable) __used __addressable_net_ns_init44 = (void *)&net_ns_init; 
asm(".section   \".initcall0.init\", \"a\"  \n" 
    "__initcall_net_ns_init0:\n" 
    ".long net_ns_init - . \n" 
    ".previous\n");;

过去的定义：
static initcall_t __initcall_net_ns_init0 __used __attribute__((__section__(".initcall0.init"))) = net_ns_init;
*/
#define early_initcall(fn)			__define_initcall(fn, early)
#define pure_initcall(fn)			__define_initcall(fn, 0)
#define core_initcall(fn)			__define_initcall(fn, 1)
#define core_initcall_sync(fn)		__define_initcall(fn, 1s)
#define postcore_initcall(fn)		__define_initcall(fn, 2)
#define postcore_initcall_sync(fn)	__define_initcall(fn, 2s)
#define arch_initcall(fn)			__define_initcall(fn, 3)
#define arch_initcall_sync(fn)		__define_initcall(fn, 3s)
#define subsys_initcall(fn)			__define_initcall(fn, 4)
#define subsys_initcall_sync(fn)	__define_initcall(fn, 4s)
#define fs_initcall(fn)				__define_initcall(fn, 5)
#define fs_initcall_sync(fn)		__define_initcall(fn, 5s)
#define rootfs_initcall(fn)			__define_initcall(fn, rootfs)
#define device_initcall(fn)			__define_initcall(fn, 6)
#define device_initcall_sync(fn)	__define_initcall(fn, 6s)
#define late_initcall(fn)			__define_initcall(fn, 7)
#define late_initcall_sync(fn)		__define_initcall(fn, 7s)

//include/linux/init.h：234
#define __initcall(fn) device_initcall(fn)

//include/linux/module.h：85
//对于不是动态加载驱动程序
#define module_init(x)	__initcall(x);

//include/linux/init.h：200
#define __define_initcall(fn, id) ___define_initcall(fn, id, .initcall##id)

//include/linux/init.h：188
#define ___define_initcall(fn, id, __sec)			\
	__ADDRESSABLE(fn)								\
	asm(".section	\"" #__sec ".init\", \"a\"	\n"	\
	"__initcall_" #fn #id ":			\n"			\
	    ".long	" #fn " - .			\n"				\
	    ".previous					\n");

//include/linux/compiler.h：300
/*
 * Force the compiler to emit 'sym' as a symbol, so that we can reference
 * it from inline assembler. Necessary in case 'sym' could be inlined
 * otherwise, or eliminated entirely due to lack of references that are
 * visible to the compiler.
 */
#define __ADDRESSABLE(sym) \
			static void * __section(.discard.addressable) __used \
				__PASTE(__addressable_##sym, __LINE__) = (void *)&sym;

//include/linux/compiler_types.h：53
#define ___PASTE(a,b) a##b
#define __PASTE(a,b) ___PASTE(a,b)

#endif

#if 1 //启动顺序4。net_dev_init()

//net/core/dev.c：10243
subsys_initcall(net_dev_init);

//net/core/dev.c：10166
static int __init net_dev_init(void)
{
	int i, rc = -ENOMEM;

	BUG_ON(!dev_boot_phase);

	if (dev_proc_init())
		goto out;

	if (netdev_kobject_init())
		goto out;

	INIT_LIST_HEAD(&ptype_all);
	
	for (i = 0; i < PTYPE_HASH_SIZE; i++)
		INIT_LIST_HEAD(&ptype_base[i]);

	INIT_LIST_HEAD(&offload_base);

	//导致netdev_init被调用
	if (register_pernet_subsys(&netdev_net_ops))
		goto out;

	/*
	 *	Initialise the packet receive queues.
	 */

	for_each_possible_cpu(i) 
	{
		struct work_struct *flush = per_cpu_ptr(&flush_works, i);
		struct softnet_data *sd = &per_cpu(softnet_data, i);

		//flush_works->data = WORK_STRUCT_NO_POOL
		//初始化flush_works->entry链表
		//flush_works->func = flush_backlog
		INIT_WORK(flush, flush_backlog);

		skb_queue_head_init(&sd->input_pkt_queue);
		skb_queue_head_init(&sd->process_queue);
#ifdef CONFIG_XFRM_OFFLOAD
		skb_queue_head_init(&sd->xfrm_backlog);
#endif
		INIT_LIST_HEAD(&sd->poll_list);
		sd->output_queue_tailp = &sd->output_queue;
#ifdef CONFIG_RPS
		sd->csd.func = rps_trigger_softirq;
		sd->csd.info = sd;
		sd->cpu = i;
#endif

		init_gro_hash(&sd->backlog);

		sd->backlog.poll = process_backlog;
		sd->backlog.weight = weight_p;
	}

	//标识完成初始化
	dev_boot_phase = 0;

	/* The loopback device is special if any other network devices
	 * is present in a network namespace the loopback device must
	 * be present. Since we now dynamically allocate and free the
	 * loopback device ensure this invariant is maintained by
	 * keeping the loopback device as the first device on the
	 * list of network devices.  Ensuring the loopback devices
	 * is the first device that appears and the last network device
	 * that disappears.
	 */
	//导致loopback_net_init被调用
	//创建了回环设备lo的net_device结构，并与init_net关联
	if (register_pernet_device(&loopback_net_ops))
		goto out;

	if (register_pernet_device(&default_device_ops))
		goto out;

	//注册了两个软中断服务函数，分别是数据包发送和数据包接收服务函数
	open_softirq(NET_TX_SOFTIRQ, net_tx_action);
	open_softirq(NET_RX_SOFTIRQ, net_rx_action);

	//Setup hotplug state callbacks without calling the callbacks
	//CPU热插拔事件通知链上，注册teardown对应的回调函数dev_cpu_dead
	rc = cpuhp_setup_state_nocalls(CPUHP_NET_DEV_DEAD, "net/dev:dead", NULL, dev_cpu_dead);
	WARN_ON(rc < 0);
	rc = 0;
out:
	return rc;
}

//kernel/softirq.c:455
void open_softirq(int nr, void (*action)(struct softirq_action *))
{
	softirq_vec[nr].action = action;
}

//net/core/dev.c：1539
//用以判断net_dev_init()是否已经执行过，为0表示执行过
static int dev_boot_phase = 1;

//net/core/dev.c：6213
static void init_gro_hash(struct napi_struct *napi)
{
	int i;

	for (i = 0; i < GRO_HASH_BUCKETS; i++) 
	{
		INIT_LIST_HEAD(&napi->gro_hash[i].list);
		napi->gro_hash[i].count = 0;
	}
	napi->gro_bitmask = 0;
}

//net/core/net-sysfs.c：1778
int __init netdev_kobject_init(void)
{
	kobj_ns_type_register(&net_ns_type_operations);
	return class_register(&net_class);
}

//net/core/net-procfs.c：361
int __init dev_proc_init(void)
{
	//导致调用dev_proc_net_init()
	//其中创建:
	// /proc/net/dev：按照设备统计，如：ens33、lo
	// /proc/net/ptype：按照包类型统计（ptype为packet type），如：ip_rcv、arp_rcv、ipv6_rcv
	// /proc/net/softnet_stat：分cpu统计，一行一个cpu统计信息
	int ret = register_pernet_subsys(&dev_proc_ops);
	if (!ret)
		return register_pernet_subsys(&dev_mc_net_ops);
	
	return ret;
}

static struct pernet_operations __net_initdata dev_proc_ops = 
{
	.init = dev_proc_net_init,
	.exit = dev_proc_net_exit,
};

//net/core/net-procfs.c：275
static int __net_init dev_proc_net_init(struct net *net)
{
	int rc = -ENOMEM;

	if (!proc_create_net("dev", 0444, net->proc_net, &dev_seq_ops,
			sizeof(struct seq_net_private)))
		goto out;
	if (!proc_create_seq("softnet_stat", 0444, net->proc_net,
			 &softnet_seq_ops))
		goto out_dev;
	if (!proc_create_net("ptype", 0444, net->proc_net, &ptype_seq_ops,
			sizeof(struct seq_net_private)))
		goto out_softnet;

	if (wext_proc_init(net))
		goto out_ptype;
	
	rc = 0;
out:
	return rc;
out_ptype:
	remove_proc_entry("ptype", net->proc_net);
out_softnet:
	remove_proc_entry("softnet_stat", net->proc_net);
out_dev:
	remove_proc_entry("dev", net->proc_net);
	goto out;
}

//net/core/dev.c：10048
static struct pernet_operations __net_initdata netdev_net_ops = 
{
	.init = netdev_init,
	.exit = netdev_exit,
};

//net/core/dev.c：9933
/* Initialize per network namespace state */
static int __net_init netdev_init(struct net *net)
{
	BUILD_BUG_ON(GRO_HASH_BUCKETS > 8 * FIELD_SIZEOF(struct napi_struct, gro_bitmask));

	if (net != &init_net)
		INIT_LIST_HEAD(&net->dev_base_head);

	net->dev_name_head = netdev_create_hash();
	if (net->dev_name_head == NULL)
		goto err_name;

	net->dev_index_head = netdev_create_hash();
	if (net->dev_index_head == NULL)
		goto err_idx;

	return 0;

err_idx:
	kfree(net->dev_name_head);
err_name:
	return -ENOMEM;
}

//net/core/dev.c：9919
static struct hlist_head * __net_init netdev_create_hash(void)
{
	int i;
	struct hlist_head *hash;

	hash = kmalloc_array(NETDEV_HASHENTRIES, sizeof(*hash), GFP_KERNEL);
	if (hash != NULL)
		for (i = 0; i < NETDEV_HASHENTRIES; i++)
			INIT_HLIST_HEAD(&hash[i]);

	return hash;
}

//include/net/net_namespace.h：51
#define NETDEV_HASHBITS    8
#define NETDEV_HASHENTRIES (1 << NETDEV_HASHBITS)

//net/core/net_namespace.c：1302
/**
 *      register_pernet_device - register a network namespace device
 *	@ops:  pernet operations structure for the subsystem
 *
 *	Register a device which has init and exit functions
 *	that are called when network namespaces are created and
 *	destroyed respectively.
 *
 *	When registered all network namespace init functions are
 *	called for every existing network namespace.  Allowing kernel
 *	modules to have a race free view of the set of network namespaces.
 *
 *	When a new network namespace is created all of the init
 *	methods are called in the order in which they were registered.
 *
 *	When a network namespace is destroyed all of the exit methods
 *	are called in the reverse of the order with which they were
 *	registered.
 */
int register_pernet_device(struct pernet_operations *ops)
{
	int error;
	down_write(&pernet_ops_rwsem);
	
	error = register_pernet_operations(&pernet_list, ops);
	if (!error && (first_device == &pernet_list))
		first_device = &ops->list;
	up_write(&pernet_ops_rwsem);
	return error;
}
EXPORT_SYMBOL_GPL(register_pernet_device);

//net/core/dev.c：10150
static struct pernet_operations __net_initdata default_device_ops = 
{
	.exit = default_device_exit,
	.exit_batch = default_device_exit_batch,
};

//drivers/net/loopback.c：231
struct pernet_operations __net_initdata loopback_net_ops =
{
	.init = loopback_net_init,
};

//drivers/net/loopback.c：203
/* Setup and register the loopback device. */
static __net_init int loopback_net_init(struct net *net)
{
	struct net_device *dev;
	int err;

	err = -ENOMEM;
	dev = alloc_netdev(0, "lo", NET_NAME_UNKNOWN, loopback_setup);
	if (!dev)
		goto out;

	dev_net_set(dev, net);
	err = register_netdev(dev);
	if (err)
		goto out_free_netdev;

	BUG_ON(dev->ifindex != LOOPBACK_IFINDEX);
	net->loopback_dev = dev;
	return 0;

out_free_netdev:
	free_netdev(dev);
out:
	if (net_eq(net, &init_net))
		panic("loopback: Failed to register netdevice: %d\n", err);
	return err;
}

#endif
