#if 1 //网络名字空间net结构、init_net结构

//include/net/net_namespace.h：54
struct net 
{
	/* First cache line can be often dirtied.
	 * Do not place here read-mostly fields.
	 */
	refcount_t		passive;	/* To decide when the network
						 * namespace should be freed.
						 */
	refcount_t		count;		/* To decided when the network
						 *  namespace should be shut down.
						 */
	spinlock_t		rules_mod_lock;		//保护net.rules_ops链表

	unsigned int		dev_unreg_count;	//当调用unregister_netdev()时该计数器加1，退出该函数时减1
											//记录正在被unresgister的网络设备个数

	unsigned int		dev_base_seq;	/* protected by rtnl_mutex */
	
	int					ifindex;		//跟踪当前net结构中已被占用的最大的interface index
										//网络设备的index，由内核软件维护的而已
										//每当有新的网络设备注册时（调用register_netdev)，该字段都会被更新

	spinlock_t		nsid_lock;
	atomic_t		fnhe_genid;

	struct list_head	list;		/* list of network namespaces */
	struct list_head	exit_list;	/* To linked to call pernet exit
						 * methods on dead net (
						 * pernet_ops_rwsem read locked),
						 * or to unregister pernet ops
						 * (pernet_ops_rwsem write locked).
						 */
	struct llist_node	cleanup_list;	/* namespaces on death row */

#ifdef CONFIG_KEYS
	struct key_tag		*key_domain;	/* Key domain of operation tag */
#endif
	struct user_namespace   *user_ns;	/* Owning user namespace */
	struct ucounts		*ucounts;
	struct idr		netns_ids;

	struct ns_common	ns;

	struct list_head 	dev_base_head;		//属于该net结构的网络设备构成的链表
											//该链表的结点，即net_device结构的dev_list字段
											//register_netdev()中会有节点加入上述链表
											
	struct proc_dir_entry 	*proc_net;
	struct proc_dir_entry 	*proc_net_stat;

#ifdef CONFIG_SYSCTL
	struct ctl_table_set	sysctls;
#endif

	struct sock 		*rtnl;			/* rtnetlink socket */
	struct sock		*genl_sock;

	struct uevent_sock	*uevent_sock;		/* uevent socket */

	struct hlist_head 	*dev_name_head;		//以网络设备名称为主键的哈希表，比如eht0。
											//key实际上是hash_32(full_name_hash(网络设备名称))
											//哈希冲突链表的节点，即net_device结构的name_hlist字段
											//register_netdev()中会有节点加入上述哈希表
	
	struct hlist_head	*dev_index_head;	//以网络设备index为主键的哈希表
											//key实际上是net_device结构的ifindex字段取低8位
											//哈希冲突链表的节点，即net_device结构的index_hlist字段
											//register_netdev()中会有节点加入上述哈希表
	
	/* Note that @hash_mix can be read millions times per second,
	 * it is critical that it is on a read_mostly cache line.
	 */
	//保存调用get_random_bytes得到的随机数
	//用于计算inet_addr_lst哈希表的哈希值
	u32			hash_mix;

	struct net_device       *loopback_dev;          /* The loopback */

	/* core fib_rules */
	struct list_head	rules_ops;

	struct netns_core	core;

	//SNMP中的MIB信息库
	struct netns_mib	mib;
	
	struct netns_packet	packet;
	struct netns_unix	unx;
	struct netns_nexthop	nexthop;
	struct netns_ipv4	ipv4;
#if IS_ENABLED(CONFIG_IPV6)
	struct netns_ipv6	ipv6;
#endif
#if IS_ENABLED(CONFIG_IEEE802154_6LOWPAN)
	struct netns_ieee802154_lowpan	ieee802154_lowpan;
#endif
#if defined(CONFIG_IP_SCTP) || defined(CONFIG_IP_SCTP_MODULE)
	struct netns_sctp	sctp;
#endif
#if defined(CONFIG_IP_DCCP) || defined(CONFIG_IP_DCCP_MODULE)
	struct netns_dccp	dccp;
#endif
#ifdef CONFIG_NETFILTER
	struct netns_nf		nf;
	struct netns_xt		xt;
#if defined(CONFIG_NF_CONNTRACK) || defined(CONFIG_NF_CONNTRACK_MODULE)
	struct netns_ct		ct;
#endif
#if defined(CONFIG_NF_TABLES) || defined(CONFIG_NF_TABLES_MODULE)
	struct netns_nftables	nft;
#endif
#if IS_ENABLED(CONFIG_NF_DEFRAG_IPV6)
	struct netns_nf_frag	nf_frag;
	struct ctl_table_header *nf_frag_frags_hdr;
#endif
	struct sock		*nfnl;
	struct sock		*nfnl_stash;
#if IS_ENABLED(CONFIG_NETFILTER_NETLINK_ACCT)
	struct list_head        nfnl_acct_list;
#endif
#if IS_ENABLED(CONFIG_NF_CT_NETLINK_TIMEOUT)
	struct list_head	nfct_timeout_list;
#endif
#endif
#ifdef CONFIG_WEXT_CORE
	struct sk_buff_head	wext_nlevents;
#endif
	struct net_generic __rcu	*gen;

	struct bpf_prog __rcu	*flow_dissector_prog;

	/* Note : following structs are cache line aligned */
#ifdef CONFIG_XFRM
	struct netns_xfrm	xfrm;
#endif
#if IS_ENABLED(CONFIG_IP_VS)
	struct netns_ipvs	*ipvs;
#endif
#if IS_ENABLED(CONFIG_MPLS)
	struct netns_mpls	mpls;
#endif
#if IS_ENABLED(CONFIG_CAN)
	struct netns_can	can;
#endif
#ifdef CONFIG_XDP_SOCKETS
	struct netns_xdp	xdp;
#endif
#if IS_ENABLED(CONFIG_CRYPTO_USER)
	struct sock		*crypto_nlsk;
#endif
	struct sock		*diag_nlsk;
} __randomize_layout;

//include/net/netns/ipv4.h：43
struct netns_ipv4
{
#ifdef CONFIG_SYSCTL
	struct ctl_table_header	*forw_hdr;
	struct ctl_table_header	*frags_hdr;
	struct ctl_table_header	*ipv4_hdr;
	struct ctl_table_header *route_hdr;
	struct ctl_table_header *xfrm4_hdr;
#endif
	struct ipv4_devconf	*devconf_all;
	struct ipv4_devconf	*devconf_dflt;
	struct ip_ra_chain __rcu *ra_chain;
	struct mutex		ra_mutex;
#ifdef CONFIG_IP_MULTIPLE_TABLES
	struct fib_rules_ops	*rules_ops;
	bool			fib_has_custom_rules;
	unsigned int		fib_rules_require_fldissect;

	//主路由表
	struct fib_table __rcu	*fib_main;

	//默认路由表
	struct fib_table __rcu	*fib_default;
#endif
	bool			fib_has_custom_local_routes;
#ifdef CONFIG_IP_ROUTE_CLASSID
	int			fib_num_tclassid_users;
#endif
	struct hlist_head	*fib_table_hash;
	bool			fib_offload_disabled;
	struct sock		*fibnl;

	struct sock  * __percpu	*icmp_sk;
	struct sock		*mc_autojoin_sk;

	struct inet_peer_base	*peers;
	struct sock  * __percpu	*tcp_sk;

	//其rhashtable字段，存储了等待组合分配的数据包队列
	struct fqdir		*fqdir;
	
#ifdef CONFIG_NETFILTER
	struct xt_table		*iptable_filter;
	struct xt_table		*iptable_mangle;
	struct xt_table		*iptable_raw;
	struct xt_table		*arptable_filter;
#ifdef CONFIG_SECURITY
	struct xt_table		*iptable_security;
#endif
	struct xt_table		*nat_table;
#endif

	int sysctl_icmp_echo_ignore_all;
	int sysctl_icmp_echo_ignore_broadcasts;
	int sysctl_icmp_ignore_bogus_error_responses;
	int sysctl_icmp_ratelimit;
	int sysctl_icmp_ratemask;
	int sysctl_icmp_errors_use_inbound_ifaddr;

	struct local_ports ip_local_ports;

	int sysctl_tcp_ecn;
	int sysctl_tcp_ecn_fallback;

	int sysctl_ip_default_ttl;
	int sysctl_ip_no_pmtu_disc;
	int sysctl_ip_fwd_use_pmtu;
	int sysctl_ip_fwd_update_priority;
	int sysctl_ip_nonlocal_bind;
	/* Shall we try to damage output packets if routing dev changes? */
	int sysctl_ip_dynaddr;
	int sysctl_ip_early_demux;
#ifdef CONFIG_NET_L3_MASTER_DEV
	int sysctl_raw_l3mdev_accept;
#endif
	int sysctl_tcp_early_demux;
	int sysctl_udp_early_demux;

	int sysctl_fwmark_reflect;
	int sysctl_tcp_fwmark_accept;
#ifdef CONFIG_NET_L3_MASTER_DEV
	int sysctl_tcp_l3mdev_accept;
#endif
	int sysctl_tcp_mtu_probing;
	int sysctl_tcp_mtu_probe_floor;
	int sysctl_tcp_base_mss;
	int sysctl_tcp_min_snd_mss;
	int sysctl_tcp_probe_threshold;
	u32 sysctl_tcp_probe_interval;

	int sysctl_tcp_keepalive_time;
	int sysctl_tcp_keepalive_probes;
	int sysctl_tcp_keepalive_intvl;

	int sysctl_tcp_syn_retries;
	int sysctl_tcp_synack_retries;
	int sysctl_tcp_syncookies;
	int sysctl_tcp_reordering;
	int sysctl_tcp_retries1;
	int sysctl_tcp_retries2;
	int sysctl_tcp_orphan_retries;
	int sysctl_tcp_fin_timeout;
	unsigned int sysctl_tcp_notsent_lowat;
	int sysctl_tcp_tw_reuse;
	int sysctl_tcp_sack;
	int sysctl_tcp_window_scaling;
	int sysctl_tcp_timestamps;
	int sysctl_tcp_early_retrans;
	int sysctl_tcp_recovery;
	int sysctl_tcp_thin_linear_timeouts;
	int sysctl_tcp_slow_start_after_idle;
	int sysctl_tcp_retrans_collapse;
	int sysctl_tcp_stdurg;
	int sysctl_tcp_rfc1337;
	int sysctl_tcp_abort_on_overflow;
	int sysctl_tcp_fack;
	int sysctl_tcp_max_reordering;
	int sysctl_tcp_dsack;
	int sysctl_tcp_app_win;
	int sysctl_tcp_adv_win_scale;
	int sysctl_tcp_frto;
	int sysctl_tcp_nometrics_save;
	int sysctl_tcp_moderate_rcvbuf;
	int sysctl_tcp_tso_win_divisor;
	int sysctl_tcp_workaround_signed_windows;
	int sysctl_tcp_limit_output_bytes;
	int sysctl_tcp_challenge_ack_limit;
	int sysctl_tcp_min_tso_segs;
	int sysctl_tcp_min_rtt_wlen;
	int sysctl_tcp_autocorking;
	int sysctl_tcp_invalid_ratelimit;
	int sysctl_tcp_pacing_ss_ratio;
	int sysctl_tcp_pacing_ca_ratio;
	int sysctl_tcp_wmem[3];
	int sysctl_tcp_rmem[3];
	int sysctl_tcp_comp_sack_nr;
	unsigned long sysctl_tcp_comp_sack_delay_ns;
	struct inet_timewait_death_row tcp_death_row;
	int sysctl_max_syn_backlog;
	int sysctl_tcp_fastopen;
	const struct tcp_congestion_ops __rcu  *tcp_congestion_control;
	struct tcp_fastopen_context __rcu *tcp_fastopen_ctx;
	spinlock_t tcp_fastopen_ctx_lock;
	unsigned int sysctl_tcp_fastopen_blackhole_timeout;
	atomic_t tfo_active_disable_times;
	unsigned long tfo_active_disable_stamp;

	int sysctl_udp_wmem_min;
	int sysctl_udp_rmem_min;

#ifdef CONFIG_NET_L3_MASTER_DEV
	int sysctl_udp_l3mdev_accept;
#endif

	int sysctl_igmp_max_memberships;
	int sysctl_igmp_max_msf;
	int sysctl_igmp_llm_reports;
	int sysctl_igmp_qrv;

	struct ping_group_range ping_group_range;

	atomic_t dev_addr_genid;

#ifdef CONFIG_SYSCTL
	unsigned long *sysctl_local_reserved_ports;
	int sysctl_ip_prot_sock;
#endif

#ifdef CONFIG_IP_MROUTE
#ifndef CONFIG_IP_MROUTE_MULTIPLE_TABLES
	struct mr_table		*mrt;
#else
	struct list_head	mr_tables;
	struct fib_rules_ops	*mr_rules_ops;
#endif
#endif
#ifdef CONFIG_IP_ROUTE_MULTIPATH
	int sysctl_fib_multipath_use_neigh;
	int sysctl_fib_multipath_hash_policy;
#endif

	struct fib_notifier_ops	*notifier_ops;
	unsigned int	fib_seq;	/* protected by rtnl_mutex */

	struct fib_notifier_ops	*ipmr_notifier_ops;
	unsigned int	ipmr_seq;	/* protected by rtnl_mutex */

	atomic_t	rt_genid;
	siphash_key_t	ip_id_key;
};

//include/net/netns/core.h：8
struct netns_core 
{
	/* core sysctls */
	struct ctl_table_header	*sysctl_hdr;

	int	sysctl_somaxconn;

	//统计当前网络命名空间中包含的套接字数量
	int __percpu *sock_inuse;
	
	struct prot_inuse __percpu *prot_inuse;
};

//net/core/net_namespace.c：46
struct net init_net = 
{
	.count		= REFCOUNT_INIT(1),
	.dev_base_head	= LIST_HEAD_INIT(init_net.dev_base_head),
	.key_domain	= &init_net_key_domain,

	//net_ns_init()、setup_net()初始化结果
	.gen = net_alloc_generic();		//分配了net_generic结构
	.count = 1;
	.passive = 1;
	.hash_mix = ;					//保存调用get_random_bytes得到的随机数
									//用于计算inet_addr_lst哈希表的哈希值
	.dev_base_seq = 1;				//在register_netdev()中加1
	.user_ns = &init_user_ns;
	.netns_ids = ;					//调用idr_init()初始化，主要字段初始化为0
	.nsid_lock = ;					//初始化自旋锁
	.ipv4.ra_mutex = ;				//初始化互斥量
	.list = ;						//被组织进了链表net_namespace_list
	.ns.ops = &netns_operations;
	.ns.stashed = 0;
	.ns.inum = ;					//函数proc_alloc_inum返回一个inode号

	//net_inuse_init()初始化的结果
	.core.prot_inuse = ;			//分配了per cpu空间，类型是struct prot_inuse
	.core.sock_inuse = ;			//分配了per cpu空间，类型是int

	//net_dev_init()->netdev_init()初始化结果
	.dev_name_head = ;				//初始化哈希表，以设备名称为主键，组织各种网络设备，包括ens33、lo
	.dev_index_head = ;				//初始化哈希表，以设备index为主键，组织各种网络设备，包括ens33、lo

	//net_dev_init()->loopback_net_init()
	.loopback_dev = ;				//设置了loopback的net_device结构

	//fib_notifier_init()
	.gen->ptr[fib_notifier_net_id] = ;	//专门构建了链表头，该链表元素实际就是struct fib_notifier_ops

	//fib_rules_init()
	.rules_ops =;					//初始化链表头
	.rules_mod_lock =;				//初始化自旋锁
	
	//inet_init()->ip_static_sysctl_init()
	.sysctls = ;					//register_net_sysctl(&init_net, "net/ipv4/route"（PATH）, ipv4_route_table);
	//inet_init()->inet_init_net()
	.ipv4.ip_local_ports.lock = ;	//初始化
	.ipv4.ip_local_ports.range[0] =  32768;
	.ipv4.ip_local_ports.range[1] =  60999;
	.ipv4.ping_group_range.lock = ;	//初始化
	.ipv4.ping_group_range.range[0] = make_kgid(&init_user_ns, 1);
	.ipv4.ping_group_range.range[1] = make_kgid(&init_user_ns, 0);
	//sysctl
	.ipv4.sysctl_ip_default_ttl = IPDEFTTL;	//64
	.ipv4.sysctl_ip_fwd_update_priority = 1;
	.ipv4.sysctl_ip_dynaddr = 0;
	.ipv4.sysctl_ip_early_demux = 1;
	.ipv4.sysctl_udp_early_demux = 1;
	.ipv4.sysctl_tcp_early_demux = 1;
	.ipv4.sysctl_ip_prot_sock = PROT_SOCK;
	//IGMP
	.ipv4.sysctl_igmp_max_memberships = 20;
	.ipv4.sysctl_igmp_max_msf = 10;
	.ipv4.sysctl_igmp_llm_reports = 1;
	.ipv4.sysctl_igmp_qrv = 2;

	//inet_init()->ip_init()->ip_rt_init()->devinet_init()->...->devinet_init_net()
	//对ipv4.forw_hdr、ipv4.devconf_all、ipv4.devconf_dflt进行了设置

	//inet_init()->ip_init()->ip_rt_init()->ip_fib_init()->...->fib_net_init()
	.ipv4.fib_num_tclassid_users = 0;
	.ipv4.fib_seq = 0;
	
	//将fib4_notifier_ops_template的副本，加入到init_net.gen->ptr[fib_notifier_net_id]->fib_notifier_ops链表
	//.gen->ptr[fib_notifier_net_id]的实际类型是fib_notifier_net *，该字段实际指向了一个链表，元素类型为fib_notifier_ops
	
	.ipv4.notifier_ops = ;	//等于上述fib4_notifier_ops_template的副本

	.ipv4.fib_table_hash = ;//为该哈希表分配空间
							//空间大小，即256个槽。=sizeof(struct hlist_head) * FIB_TABLE_HASHSZ; //256
							//每个元素类型是fib_table结构
							//对table id进行hash，比如RT_TABLE_MAIN
							//初始化的地方：
							//inet_init()->ip_init()->ip_rt_init()->ip_fib_init()->register_netdevice_notifier(&fib_netdev_notifier)->两次调用fib_netdev_event，第二次以事件NETDEV_UP调用->fib_add_ifaddr()->fib_magic()->fib_new_table()中有hlist_add_head_rcu(&tb->tb_hlist, &net->ipv4.fib_table_hash[h]); 即添加路由表
							
	//将fib4_rules_ops_template的副本ops，加入到init_net.rules_ops链表中
	//该链表元素的类型是struct fib_rules_ops
	//ops->rules_list，被初始化
	//ops->fro_net = &init_net;
	//建立三个路由规则（本地路由规则、主路由规则、默认路由规则），并加入到ops->rules_list链表
	.ipv4.rules_ops = ops;
	.ipv4.fib_has_custom_rules = false;		//即没有定制的路由规则
	.ipv4.fib_rules_require_fldissect = 0;

	//指向用于netlink的sock结构
	.ipv4.fibnl = ;

	//tcp_congestion_default()，启动顺序7
	ipv4.tcp_congestion_control = &cubictcp;		//拥塞控制算法cubic结构
	ipv4.tcp_congestion_control.flags = TCP_CONG_NON_RESTRICTED;

	//在register_netdev()中加1
	.dev_base_seq = 2;		
};
EXPORT_SYMBOL(init_net);

//net/core/net_namespace.c：35
//所有net结构被组织进了链表net_namespace_list
LIST_HEAD(net_namespace_list);
EXPORT_SYMBOL_GPL(net_namespace_list);

//net/core/fib_notifier.c：11
//初始化函数fib_notifier_init被调用时，调用ida_alloc_min，获取未使用ID，存入其中
static unsigned int fib_notifier_net_id;

//每个进程的current->nsproxy->net_ns实际指向了init_net
//证明：(实际编程获取current->nsproxy->net_ns，和init_net地址，相等)
//kernel/nsproxy.c：29
struct nsproxy init_nsproxy = //namespace的代理类
{
	.count					= ATOMIC_INIT(1),
	.uts_ns					= &init_uts_ns,
	.ipc_ns					= &init_ipc_ns,
	.mnt_ns					= NULL,
	.pid_ns_for_children	= &init_pid_ns,
	.net_ns					= &init_net,
	.cgroup_ns				= &init_cgroup_ns,
};

//init/init_task.c：56
struct task_struct init_task = 
{
	//...................
	.nsproxy	= &init_nsproxy,
	//...................
};
EXPORT_SYMBOL(init_task);

#endif

#if 1 //sk_buff_head结构和sk_buff结构

//include/linux/skbuff.h：289
struct sk_buff_head 
{
	/* These two members must be first. */
	struct sk_buff	*next;		//以下两个字段，与sk_buff构成双向循环链表
	struct sk_buff	*prev;

	__u32			qlen;		//链表中sk_buff的个数
	spinlock_t		lock;
};

//include/linux/skbuff.h：685
//socket buffer，存放接收、发送的数据包的结构
/*
 *当网络设备驱动程序接收到帧，构建或获取到skb时，设置的字段包括：
 *		布局等参见sk_buff结构图
 *		.len = 帧长度 - MAC头长度
 *		.data_len = 0
 *
 *		.dev = 接收到帧的net_device结构
 *		.pkt_type = ;	根据接收到的帧的目的MAC地址、net_device结构的dev_addr字段和broadcast字段
 *						确定帧类型：PACKET_BROADCAST、PACKET_MULTICAST、PACKET_OTHERHOST、PACKET_HOST
 *		.protocol = 比如等于ETH_P_IP
 *		.tstamp = 接收到帧的时间
 *		.mac_len = MAC头部长度，即14
 *		.skb_iif = net_device结构的interface index，即ifindex
 *		.tc_redirected = 0;
 *
 *当ip_rcv()接收到数据包后
 *		如果传输媒介在数据包末尾额外添加了一些数据，会剔除这些数据，重新计算skb->len、skb->tail，以反映实际数据包的情况
 *		.transport_header = 传输层头部
 *		((struct inet_skb_parm*)((skb)->cb))结构清0
 *		((struct inet_skb_parm*)((skb)->cb))->iif = .skb_iif	net_device结构的interface index，即ifindex
 *		((struct inet_skb_parm*)((skb)->cb))->opt.optlen = 设置IP选项长度
 *						根据IP选项，设置上述opt的其他字段
 *
 *当ip_local_deliver()处理数据包时
 *		.len = 帧长度 - MAC头长度 - 网络层头部长度
 *		.data += 网络层头部长度，即指向了传输层头部
 */
 
/* 
 *调用dev_queue_xmit()发送帧时
 *		.mac_header = 设置MAC头部位置
 *
 *		//考虑GSO后，设置要发送的帧的总长度
 *		.(struct qdisc_skb_cb *)cb->pkt_len = .len +（分段数量-1）*（MAC头部大小 + 网络层头部大小 + 传输层头部（TCP或UDP）大小）
 *
 *		.tc_at_ingress = 0;
 *		.sender_cpu = ; 		若未设置该字段，则将其设置为raw_smp_processor_id() + 1，即当前CPU编号+1
 *		.queue_mapping = 0;		表明选择了net_device结构的_tx[0]，即该字段时_tx数组的下标
 */
struct sk_buff 
{
	union 
	{
		struct 
		{
			/* These two members must be first. */
			struct sk_buff			*next;				//Next buffer in list
			struct sk_buff			*prev;				//Previous buffer in list

			union 
			{
				struct net_device	*dev;				//数据包接收、发送的设备
				/* Some protocols might use this space to store information,
				 * while device pointer would be NULL.
				 * UDP receive path is one user.
				 */
				unsigned long		dev_scratch;
			};
		};
		struct rb_node				rbnode; 			//RB tree node, alternative to next/prev for netem/tcp
		struct list_head			list;				//指回sk_buff_head结构？？？存疑
	};

	union 
	{
		struct sock					*sk;				//当前sk_buff所属的sock结构
		int							ip_defrag_offset;
	};

	union 
	{
		ktime_t						tstamp;				//数据包达到sk_buff结构的时间（包括接收、发送）
														//NIC驱动程序接收帧时，会设置此字段
														
		u64							skb_mstamp_ns; /* earliest departure time */
	};
	
	/*
	 * This is the control buffer. It is free to use for every
	 * layer. Please put your private variables there. If you
	 * want to keep them across layers you have to do a skb_clone()
	 * first. This is owned by whoever has the skb queued ATM.
	 */
	//用于存储每层的私有数据，比如TCP在其中存放tcp_skb_cb结构
	//网络层中，又存放的是qdisc_skb_cb结构
	//网络层中，接收到数据包后，存放的类型是struct inet_skb_parm
	//当驱动程序释放已经发送的帧时，该字段的类型可能是struct dev_kfree_skb_cb *
	char							cb[48];// __aligned(8);	

	union 
	{
		struct 
		{
			//skb中缓存的路由表项
			//destination entry (with norefcount bit)
			//将最低位清0后，该字段类型就是struct dst_entry *
			unsigned long			_skb_refdst;		
			
			void					(*destructor)(struct sk_buff *skb); //当当前sk_buff结构被删除时调用该函数
																		//常被设为sock_wfree或sock_rfree
		};
		struct list_head			tcp_tsorted_anchor;	//list structure for TCP (tp->tsorted_sent_queue)
	};


	unsigned long		 			_nfct;				//Associated connection, if any (with nfctinfo bits)
														//该字段最低3位清0后，其类型即struct nf_conntrack *

	unsigned int					len,				//Length of actual data
														//len跟踪[data, tail)的长度
														//存疑：页面内碎片中数据的数据、frag_list中的数据是否应会计算在内？感觉是skb_copy貌似如此
														//当前网络层次实际数据的大小，包括当前层次的头部和负载
														//随着数据包在各个网络分层中移动，该字段值会发生变化
	
									data_len;			//同len字段类似，只是不计算数据包头部
	
	__u16							mac_len,			//MAC报头的大小
									hdr_len;			//writable header length of cloned skb

	/* Following fields are _not_ copied in __copy_skb_header()
	 * Note that queue_mapping is here mostly to fill a hole.
	 */
	//该字段保存net_device结构的_tx数组下标，即说明skb使用哪个发送队列
	__u16							queue_mapping;		//Queue mapping for multiqueue devices

/* if you move cloned around you also must adapt those constants */
#ifdef __BIG_ENDIAN_BITFIELD
#define CLONED_MASK	(1 << 7)
#else
#define CLONED_MASK	1
#endif
#define CLONED_OFFSET()		offsetof(struct sk_buff, __cloned_offset)

	__u8							__cloned_offset[0];
	__u8							cloned:1,			//Head may be cloned (check refcnt to be sure)
														//为1时表示当前结构被克隆了
														//调用了skb_clone()后，被克隆的、克隆得到的，其skb.clone都等于1
														
									nohdr:1,			//Payload reference only, must not modify header
									fclone:2,			//skbuff clone status
									peeked:1,			//this packet has been seen already, so stats have been done for it, don't do them again
									
									head_frag:1,		//若sk_buff对应的缓冲区（即head字段指向）是从页面碎片中分配而来的，该位设为1
									
									pfmemalloc:1;		//skbuff was allocated from PFMEMALLOC reserves
														//若缓冲区是正常分配（使用了__GFP_NOMEMALLOC | __GFP_NOWARN），则pfmemalloc=false，即未使用紧急内存
														//若正常分配不成功，则不使用上述标志再分配一次，此时pfmemalloc=true，即使用了紧急内存

	__u8							active_extensions;	//active extensions (skb_ext_id types)

	/* fields enclosed in headers_start/headers_end are copied
	 * using a single memcpy() in __copy_skb_header()
	 */
	/* private: */
	__u32							headers_start[0];
	/* public: */

/* if you move pkt_type around you also must adapt those constants */
#ifdef __BIG_ENDIAN_BITFIELD
#define PKT_TYPE_MAX	(7 << 5)
#else
#define PKT_TYPE_MAX	7
#endif
#define PKT_TYPE_OFFSET()	offsetof(struct sk_buff, __pkt_type_offset)

	__u8							__pkt_type_offset[0];
	__u8							pkt_type:3;			//Packet class
														//对于接收来说，网卡驱动程序在接收到帧后，会调用eth_type_trans()设置包类型
														//根据L2的目的地址进行类型划分，比如
														//PACKET_HOST表示发送到本机、PACKET_BROADCAST表示广播、PACKET_MULTICAST、PACKET_OTHERHOST
	
	__u8							ignore_df:1;		//allow local fragmentation
	__u8							nf_trace:1;			//netfilter packet trace flag


	//ip_summed记录L4校验和状态，取值：	
	#define CHECKSUM_NONE			0		//接收报文时，网络设备没有进行校验和，csum字段中不保存校验和
											//发送报文时，表示协议栈已经处理了校验和，设备不需要做任何事情
	#define CHECKSUM_UNNECESSARY	1		//接收报文时，网路设备已经验证了L4报头以及伪报头的校验和，软件无需再做任何工作，csum字段中不保存校验和
											//该值常由网络设备驱动程序，根据网卡返回的状态设置
											//该宏只针对TCP、UDP、GRE、SCTP、FCoE
	#define CHECKSUM_COMPLETE		2		//对于接收报文时，网络设备提供了整个包的校验和，并填入csum字段
	#define CHECKSUM_PARTIAL		3		//对于发送报文时：
											//		该标志说明采用网卡硬件计算UDP数据包的校验和
											//		之所以称为partial，是因为网卡硬件计算的校验和不包括IP伪头部的数据，即不包括IP头部中的源地址、目的地址，长度和协议号字段
											//		需要内核程序首先计算出IP伪头部的校验和，放置在UDP头部的校验和字段中
	__u8							ip_summed:2;		//Driver fed us an IP checksum
	
	__u8							ooo_okay:1;			//allow the mapping of a socket to a queue to be changed

	__u8							l4_hash:1;			//indicate hash is a canonical 4-tuple hash over transport ports.
	__u8							sw_hash:1;			//indicates hash was computed in software stack
	__u8							wifi_acked_valid:1;	//wifi_acked was set
	__u8							wifi_acked:1;		//whether frame was acked on wifi or not
	__u8							no_fcs:1;			//Request NIC to treat last 4 bytes as Ethernet FCS
	/* Indicates the inner headers are valid in the skbuff. */
	__u8							encapsulation:1;
	__u8							encap_hdr_csum:1;
	__u8							csum_valid:1;

#ifdef __BIG_ENDIAN_BITFIELD
#define PKT_VLAN_PRESENT_BIT	7
#else
#define PKT_VLAN_PRESENT_BIT	0
#endif
#define PKT_VLAN_PRESENT_OFFSET()	offsetof(struct sk_buff, __pkt_vlan_present_offset)
	__u8							__pkt_vlan_present_offset[0];
	__u8							vlan_present:1;
	__u8							csum_complete_sw:1;

/*
 *   skb->csum_level indicates the number of consecutive checksums found in
 *   the packet minus one that have been verified as CHECKSUM_UNNECESSARY.
 *   For instance if a device receives an IPv6->UDP->GRE->IPv4->TCP packet
 *   and a device is able to verify the checksums for UDP (possibly zero),
 *   GRE (checksum flag is set), and TCP-- skb->csum_level would be set to
 *   two. If the device were only able to verify the UDP checksum and not
 *   GRE, either because it doesn't support GRE checksum of because GRE
 *   checksum is bad, skb->csum_level would be set to zero (TCP checksum is
 *   not considered in this case).
 */
	__u8							csum_level:2;
	__u8							csum_not_inet:1;		//use CRC32c to resolve CHECKSUM_PARTIAL
	__u8							dst_pending_confirm:1;	//need to confirm neighbour
	__u8							ndisc_nodetype:2;		//router type (from link layer)

	__u8							ipvs_property:1;		//skbuff is owned by ipvs
	__u8							inner_protocol_type:1;
	__u8							remcsum_offload:1;

	__u8							offload_fwd_mark:1;		//Packet was L2-forwarded in hardware
	__u8							offload_l3_fwd_mark:1;	//Packet was L3-forwarded in hardware

	__u8							tc_skip_classify:1;		//do not classify packet. set by IFB device
	__u8							tc_at_ingress:1;		//used within tc_classify to distinguish in/egress
	__u8							tc_redirected:1;		//packet was redirected by a tc action
	__u8							tc_from_ingress:1;		//if tc_redirected, tc_at_ingress at time of redirect


	__u8							decrypted:1;			//Decrypted SKB


	__u16							tc_index;			/* traffic control index */

	union 
	{
		//当接收到数据包时，该字段可能包含L4校验和
		//当发送数据包时，该字段是指针，硬件将其计算出来的校验和放入该地址
		__wsum						csum;				//Checksum (must include start/offset pair)
		struct 
		{
			__u16					csum_start;			//Offset from skb->head where checksumming should start
			__u16					csum_offset;		// Offset from csum_start where checksum should be stored
		};
	};
	__u32							priority;			//Packet queueing priority
														//该字段表示正在被传输或转发的封包QoS等级
														
	int								skb_iif;			//输入设备的索引号，ifindex of device we arrived on
														//net_device结构的interface index，即ifindex
														
	__u32							hash;				//the packet hash
	__be16							vlan_proto;			//vlan encapsulation protocol
	__u16							vlan_tci;			//vlan tag control information

	union 
	{
		unsigned int				napi_id;			//id of the NAPI struct this skb came from
		unsigned int				sender_cpu;
	};

	__u32							secmark;			//security marking

	union 
	{
		__u32						mark;				//Generic packet mark
		__u32						reserved_tailroom;
	};

	union 
	{
		__be16						inner_protocol;		//Protocol (encapsulation)
		__u8						inner_ipproto;
	};

	__u16							inner_transport_header;	//Inner transport layer header (encapsulation)
	__u16							inner_network_header;	//Network layer header (encapsulation)
	__u16							inner_mac_header;	//Link layer header (encapsulation)

	__be16							protocol;			//该字段表示站在L2层的设备驱动程序的角度，下一个较高层次的协议
														//NIC驱动程序接收到帧后，会设置该字段，即MAC层承载何种类型的包
														//比如ETH_P_ARP（0x0806）、ETH_P_IP（0x0800）
	
	__u16							transport_header;	//指向数据包中传输层头部（偏移量）
														//初始化时设为0xffff
	
	__u16							network_header;		//指向数据包中网络层头部（偏移量）
														//如IPv4头部起始
	
	__u16							mac_header;			//指向数据包中链路层头部（偏移量，相对于head）
														//初始化时设为0xffff

	/* private: */
	__u32							headers_end[0];
	/* public: */

	/* These elements must be at the end, see alloc_skb() for details.  */
	typedef unsigned int sk_buff_data_t;

	//可以在head、data之间（称为头空间）为当前层次的以下层次，留出空间，放置头部结构
	//可以在tail、end之间（称为尾空间）留出空隙，以填入新数据
	sk_buff_data_t					tail;				//指向协议数据区域的结束地址（即某种协议的结尾）（相对于data的偏移量），比如处理TCP包时，指向TCP包结束处
														//初始化时，tail=0，因为是相对于head的偏移量
														
	sk_buff_data_t					end;				//指向缓冲区的结束地址（相对于head的偏移量）
														//初始化时，end=用户可用缓冲区大小
	
	unsigned char					*head,				//初始化时，指向缓冲区的开始地址
	
									*data;				//指向协议数据区域的开始地址（即某种协议的开头），比如处理IP包时，指向IP头开始处
														//初始化时，指向缓冲区的开始地址

	unsigned int					truesize;			//缓冲区的总大小，包括sk_buff结构本身
														//当len字段增加时，该字段也会随之更新
														//当len字段减少时，该字段是否也要减少？
														//初始化时，该字段等于
														//		用户可用的缓冲大小（即分配的总大小 - cacheline对齐(skb_shared_info结构的大小))
														// 		+ cacheline对齐(sk_buff结构)		//即使分配的是fast clone结构，也计算的是sk_buff结构大小
														// 		+ cacheline对齐(skb_shared_info结构)
	
	refcount_t						users;				//User count - see {datagram,tcp}.c
														//创建时设为1

	/* only useable after checking ->active_extensions != 0 */
	struct skb_ext					*extensions;		//allocated extensions, valid if active_extensions is nonzero
};

//include/net/ip.h:43
struct inet_skb_parm 
{
	int					iif;
	struct ip_options	opt;		/* Compiled IP options		*/
	u16					flags;

#define IPSKB_FORWARDED		BIT(0)
#define IPSKB_XFRM_TUNNEL_SIZE	BIT(1)
#define IPSKB_XFRM_TRANSFORMED	BIT(2)
#define IPSKB_FRAG_COMPLETE	BIT(3)
#define IPSKB_REROUTED		BIT(4)
#define IPSKB_DOREDIRECT	BIT(5)
#define IPSKB_FRAG_PMTU		BIT(6)
#define IPSKB_L3SLAVE		BIT(7)

	u16					frag_max_size;
};

//include/linux/skbuff.h：510
/* This data is invariant across clones and lives at
 * the end of the header data, ie. at skb->end.
 */
struct skb_shared_info 
{
	__u8			__unused;
	__u8			meta_len;
	__u8			nr_frags;			//frags数组元素数目
	
	__u8			tx_flags;			//发送标志。如SKBTX_SCHED_TSTAMP
	
	unsigned short	gso_size;			//分段大小。不包含传输层头部，只包含其负载
	
	/* Warning: this field is not always filled in (UFO)! */
	unsigned short	gso_segs;			//分段的个数
	
	struct sk_buff	*frag_list;			//指向一个skb链表，比如IP分片时（接收时），每个分片占据一个skb
	
	struct skb_shared_hwtstamps hwtstamps;
	
	unsigned int	gso_type;			//例如SKB_GSO_TCPV4、SKB_GSO_TCPV6、SKB_GSO_UDP
	
	u32				tskey;

	/*
	 * Warning : all fields before dataref are cleared in __alloc_skb()
	 */
	atomic_t		dataref;	//初始化时被设置为1
								//当当前skb对应的缓冲区被clone后，该字段会加1

	/* Intermediate layers must ensure that destructor_arg
	 * remains valid until skb destructor */
	void *			destructor_arg;			//应该是struct ubuf_info *类型

	/* must be last field, see pskb_expand_head() */
	//当sk_buff对应的缓冲区（该缓冲区称为线性缓冲区）不够用时，就使用该字段
	//该字段类似于iovec数组，每个元素都是一个页内缓冲区（称之为fragment缓冲，非线性缓冲等）
	//只有网络设备DMA操作支持Scatter/Gather（SG，分散/聚集）时，才能使用frags数组保存网络数据
	skb_frag_t		frags[MAX_SKB_FRAGS];	
};

//include/linux/skbuff.h：319
typedef struct bio_vec skb_frag_t;

//include/linux/bvec.h：18
//页内缓冲区（类型类似于iovec）管理
struct bio_vec 
{
	struct page		*bv_page;	//缓冲区所在的页面
	unsigned int	bv_len;		//缓冲区长度
	unsigned int	bv_offset;	//缓冲区起始地址在页内的偏移量
};


//include/linux/skbuff.h：1060
/* Layout of fast clones : [skb1][skb2][fclone_ref] */
struct sk_buff_fclones 
{
	struct sk_buff	skb1;		//原始的skb

	struct sk_buff	skb2;		//skb_clone后，复制得到的sk_buff位于此

	refcount_t	fclone_ref;		//初始化时，由于skb1创建了其对应的缓冲，该字段设为1
								//调用skb_clone()，执行fast clone后，该字段设为2，表示有两个skb使用了缓冲区
};

//net/core/skbuff.c：81
//用于分配struct sk_buff
struct kmem_cache *skbuff_head_cache;// __ro_after_init;

//用于分配struct sk_buff_fclones，即用于fast clone
static struct kmem_cache *skbuff_fclone_cache;// __ro_after_init;


static struct kmem_cache *skbuff_ext_cache;// __ro_after_init;

#endif

#if 1 //sk_buff的管理函数

#if 1 //alloc_skb()和__alloc_skb()：分配sk_buff结构、缓冲区，并初始化

//include/linux/skbuff.h：1046
/**
 * alloc_skb - allocate a network buffer
 * @size: 要分配的缓冲区的大小，size to allocate
 * @priority: allocation mask
 *
 * This function is a convenient wrapper around __alloc_skb().
 */
static inline struct sk_buff *alloc_skb(unsigned int size, gfp_t priority)
{
	return __alloc_skb(size, priority, 0, NUMA_NO_NODE);
}

//net/core/skbuff.c：181
/**
 *	__alloc_skb	-	allocate a network buffer
 *	@size: 要分配的缓冲区的大小，size to allocate
 *	@gfp_mask: allocation mask
 *		|= GFP_ATOMIC，在中断、软中断、spinlock等不可睡眠的上下文，应使用此标志
 *					   注意不能使用GFP_KERNEL，能引发直接的内存reclaim，从而引起睡眠
 *					   该标志允许从紧急内存空间分配，但只能最多到最低水位下的某个限制处
 *
 *	@flags: 
 *      = SKB_ALLOC_FCLONE, fast clone。allocate from fclone cache instead of head cache and allocate a cloned (child) skb.
 *		= SKB_ALLOC_RX, gfp_mask中将设置__GFP_MEMALLOC位。 will be used for allocations in case the data is required for writeback
 *						即在内存分配时忽略最低水位限制，可从紧急内存分配空间
 *						接收数据包分配sk_buff时，应该使用此
 *						
 *	@node: numa node to allocate memory on
 *
 *	Allocate a new &sk_buff. The returned buffer has no headroom and a
 *	tail room of at least size bytes. The object has a reference count
 *	of one. The return is the buffer. On a failure the return is %NULL.
 *
 *	Buffers may only be allocated from interrupts using a @gfp_mask of
 *	%GFP_ATOMIC.
 */
struct sk_buff *__alloc_skb(unsigned int size, gfp_t gfp_mask, int flags, int node)
{
	struct kmem_cache *cache;
	struct skb_shared_info *shinfo;
	struct sk_buff *skb;
	u8 *data;
	bool pfmemalloc;

	cache = (flags & SKB_ALLOC_FCLONE) ? skbuff_fclone_cache : skbuff_head_cache;

	if (sk_memalloc_socks() && (flags & SKB_ALLOC_RX))
		gfp_mask |= __GFP_MEMALLOC;

	/* Get the HEAD, head就是sk_buff结构，即分配sk_buff结构 */
	//若设置了SKB_ALLOC_FCLONE，则分配sk_buff_fclones结构
	skb = kmem_cache_alloc_node(cache, gfp_mask & ~__GFP_DMA, node);
	if (!skb)
		goto out;
	
	prefetchw(skb);

	/* We do our best to align skb_shared_info on a separate cache
	 * line. It usually works because kmalloc(X > SMP_CACHE_BYTES) gives
	 * aligned memory blocks, unless SLUB/SLAB debug is enabled.
	 * Both skb->head and skb_shared_info are cache line aligned.
	 */
	//按cacheline对齐调整大小
	size = SKB_DATA_ALIGN(size);

	//本函数分配的结构包含两个部分，一是用户所需的缓冲区，二是skb_shared_info结构
	//两部分结构都是cacheline对齐
	size += SKB_DATA_ALIGN(sizeof(struct skb_shared_info));

	//分配用户所需缓冲区和skb_shared_info结构所需空间
	//若是正常分配（使用了__GFP_NOMEMALLOC | __GFP_NOWARN），则pfmemalloc=false，即未使用紧急内存
	//若正常分配不成功，则不使用上述标志再分配一次，此时pfmemalloc=true，即使用了紧急内存
	data = kmalloc_reserve(size, gfp_mask, node, &pfmemalloc);
	if (!data)
		goto nodata;
	
	/* kmalloc(size) might give us more room than requested.
	 * Put skb_shared_info exactly at the end of allocated zone,
	 * to allow max possible filling before reallocation.
	 */
	//ksize()返回对象，即data的实际分配大小，而非申请的大小。通常kmalloc会多分配空间，如红区等
	//此时size等于，实际分配给data的大小，减去cacheline对齐(skb_shared_info结构的大小)
	//即，size = 用户可用的缓冲区大小
	//即，在data区域尾部部署skb_shared_info结构（该结构cacheline对齐）
	size = SKB_WITH_OVERHEAD(ksize(data));

	//即预取了skb_shared_info结构部分所占空间
	prefetchw(data + size);

	/*
	 * Only clear those fields we need to clear, not those that we will
	 * actually initialise below. Hence, don't put any more fields after
	 * the tail pointer in struct sk_buff!
	 */
	memset(skb, 0, offsetof(struct sk_buff, tail));

	/* Account for allocated memory : skb + skb->head */
	
	//用户可用的缓冲大小（即分配的总大小 - cacheline对齐(skb_shared_info结构的大小))
	// + cacheline对齐(sk_buff结构)
	// + cacheline对齐(skb_shared_info结构)
	skb->truesize = SKB_TRUESIZE(size);
	
	skb->pfmemalloc = pfmemalloc;

	refcount_set(&skb->users, 1);
	
	skb->head = data;
	skb->data = data;
	skb_reset_tail_pointer(skb);
	
	skb->end = skb->tail + size;
	
	skb->mac_header = (typeof(skb->mac_header))~0U;
	skb->transport_header = (typeof(skb->transport_header))~0U;

	/* make sure we initialize shinfo sequentially */
	shinfo = skb_shinfo(skb);
	
	memset(shinfo, 0, offsetof(struct skb_shared_info, dataref));
	
	atomic_set(&shinfo->dataref, 1);

	if (flags & SKB_ALLOC_FCLONE) 
	{
		struct sk_buff_fclones *fclones;

		fclones = container_of(skb, struct sk_buff_fclones, skb1);

		skb->fclone = SKB_FCLONE_ORIG;
		refcount_set(&fclones->fclone_ref, 1);

		fclones->skb2.fclone = SKB_FCLONE_CLONE;
	}
out:
	return skb;
nodata:
	kmem_cache_free(cache, skb);
	skb = NULL;
	goto out;
}
EXPORT_SYMBOL(__alloc_skb);

//include/linux/skbuff.h：2403
#define skb_shinfo(SKB)	((struct skb_shared_info *)(skb_end_pointer(SKB)))

//include/linux/skbuff.h：1381
static inline unsigned char *skb_end_pointer(const struct sk_buff *skb)
{
	return skb->head + skb->end;
}


//include/linux/skbuff.h：2154
static inline void skb_reset_tail_pointer(struct sk_buff *skb)
{
	skb->tail = skb->data - skb->head;
}

//include/linux/skbuff.h：237
/* return minimum truesize of one skb containing X bytes of data */
#define SKB_TRUESIZE(X) ((X) +						\
			 SKB_DATA_ALIGN(sizeof(struct sk_buff)) +	\
			 SKB_DATA_ALIGN(sizeof(struct skb_shared_info)))


//net/core/skbuff.c：128
/*
 * kmalloc_reserve is a wrapper around kmalloc_node_track_caller that tells
 * the caller if emergency pfmemalloc reserves are being used. If it is and
 * the socket is later found to be SOCK_MEMALLOC then PFMEMALLOC reserves
 * may be used. Otherwise, the packet data may be discarded until enough
 * memory is free
 */
#define kmalloc_reserve(size, gfp, node, pfmemalloc) \
	 __kmalloc_reserve(size, gfp, node, _RET_IP_, pfmemalloc)
static void *__kmalloc_reserve(size_t size, gfp_t flags, int node,
			       unsigned long ip, bool *pfmemalloc)
{
	void *obj;
	bool ret_pfmemalloc = false;

	/*
	 * Try a regular allocation, when that fails and we're not entitled
	 * to the reserves, fail.
	 */
	obj = kmalloc_node_track_caller(size,
					flags | __GFP_NOMEMALLOC | __GFP_NOWARN,
					node);
	if (obj || !(gfp_pfmemalloc_allowed(flags)))
		goto out;

	/* Try again but now we are using pfmemalloc reserves */
	ret_pfmemalloc = true;
	obj = kmalloc_node_track_caller(size, flags, node);

out:
	if (pfmemalloc)
		*pfmemalloc = ret_pfmemalloc;

	return obj;
}

//include/linux/skbuff.h：228
//cacheline对齐
#define SKB_DATA_ALIGN(X)	ALIGN(X, SMP_CACHE_BYTES)

//include/linux/skbuff.h：229
#define SKB_WITH_OVERHEAD(X) ((X) - SKB_DATA_ALIGN(sizeof(struct skb_shared_info)))

//include/net/sock.h：843
DECLARE_STATIC_KEY_FALSE(memalloc_socks_key);
static inline int sk_memalloc_socks(void)
{
	//类似于unlikely
	return static_branch_unlikely(&memalloc_socks_key);
}

#endif

#if 1 //dev_alloc_skb()和netdev_alloc_skb()和__netdev_alloc_skb()：在中断上下文中（驱动接收到数据时）分配sk_buff结构、缓冲区并初始化

//include/linux/skbuff.h：2790
static inline struct sk_buff *dev_alloc_skb(unsigned int length)
{
	return netdev_alloc_skb(NULL, length);
}

//include/linux/skbuff.h：2776
/**
 *	netdev_alloc_skb - allocate an skbuff for rx on a specific device
 *	@dev: network device to receive on
 *	@length: length to allocate
 *
 *	Allocate a new &sk_buff and assign it a usage count of one. The
 *	buffer has unspecified headroom built in. Users should allocate
 *	the headroom they think they need without accounting for the
 *	built in space. The built in space is used for optimisations.
 *
 *	%NULL is returned if there is no free memory. Although this function
 *	allocates memory it can be called from an interrupt.
 */
static inline struct sk_buff *netdev_alloc_skb(struct net_device *dev, unsigned int length)
{
	return __netdev_alloc_skb(dev, length, GFP_ATOMIC);
}

//net/core/skbuff.c：424
/**
 *	__netdev_alloc_skb - allocate an skbuff for rx on a specific device
 *	@dev: network device to receive on
 *	@len: length to allocate
 *	@gfp_mask: get_free_pages mask, passed to alloc_skb
 *
 *	Allocate a new &sk_buff and assign it a usage count of one. The
 *	buffer has NET_SKB_PAD headroom built in. Users should allocate
 *	the headroom they think they need without accounting for the
 *	built in space. The built in space is used for optimisations.
 *
 *	%NULL is returned if there is no free memory.
 */
struct sk_buff *__netdev_alloc_skb(struct net_device *dev, unsigned int len, gfp_t gfp_mask)
{
	struct page_frag_cache *nc;
	struct sk_buff *skb;
	bool pfmemalloc;
	void *data;

	//在sk_buff指向的用户可用缓冲中，预留64字节的头部空间，以备各个层次增加头部结构
	//说明该函数不一定是在接收数据包时调用？
	len += NET_SKB_PAD;

	//如果len + cacheline对齐(struct skb_shared_info) > 页面大小，直接进入if子句
	//如果从DMA分配，也进入if子句
	if ((len > SKB_WITH_OVERHEAD(PAGE_SIZE)) || (gfp_mask & (__GFP_DIRECT_RECLAIM | GFP_DMA))) 
	{
		skb = __alloc_skb(len, gfp_mask, SKB_ALLOC_RX, NUMA_NO_NODE);
		if (!skb)
			goto skb_fail;

		goto skb_success;
	}

	//用户申请的缓冲较小时：
	//len = 64 + 用户申请的空间大小 + cacheline对齐(struct skb_shared_info)
	//len = cacheline对齐(len)
	//注意，是从页面碎片中分配空间

	len += SKB_DATA_ALIGN(sizeof(struct skb_shared_info));
	len = SKB_DATA_ALIGN(len);

	if (sk_memalloc_socks())
		gfp_mask |= __GFP_MEMALLOC;

	//in_irq() - We're in (hard) IRQ context
	//根据是否处于中断上下文，从不同的cache，分配sk_buff对应的缓冲区
	//注意，是从页面碎片中分配
	if (in_irq() || irqs_disabled()) 
	{
		nc = this_cpu_ptr(&netdev_alloc_cache);
		data = page_frag_alloc(nc, len, gfp_mask);
		pfmemalloc = nc->pfmemalloc;
	} 
	else 
	{
		local_bh_disable();
		nc = this_cpu_ptr(&napi_alloc_cache.page);
		data = page_frag_alloc(nc, len, gfp_mask);
		pfmemalloc = nc->pfmemalloc;
		local_bh_enable();
	}

	if (unlikely(!data))
		return NULL;

	skb = __build_skb(data, len);
	if (unlikely(!skb)) 
	{
		skb_free_frag(data);
		return NULL;
	}

	/* use OR instead of assignment to avoid clearing of bits in mask */
	if (pfmemalloc)
		skb->pfmemalloc = 1;
	
	skb->head_frag = 1;

skb_success:
	skb_reserve(skb, NET_SKB_PAD);
	skb->dev = dev;

skb_fail:
	return skb;
}
EXPORT_SYMBOL(__netdev_alloc_skb);

//net/core/skbuff.c：306
/**
 * __build_skb - build a network buffer
 * @data: data buffer provided by caller
 * @frag_size: size of data, or 0 if head was kmalloced
 *
 * Allocate a new &sk_buff. Caller provides space holding head and
 * skb_shared_info. @data must have been allocated by kmalloc() only if
 * @frag_size is 0, otherwise data should come from the page allocator
 *  or vmalloc()
 * The return is the new skb buffer.
 * On a failure the return is %NULL, and @data is not freed.
 * Notes :
 *  Before IO, driver allocates only data buffer where NIC put incoming frame
 *  Driver should add room at head (NET_SKB_PAD) and
 *  MUST add room at tail (SKB_DATA_ALIGN(skb_shared_info))
 *  After IO, driver calls build_skb(), to allocate sk_buff and populate it
 *  before giving packet to stack.
 *  RX rings only contains data buffers, not full skbs.
 */
struct sk_buff *__build_skb(void *data, unsigned int frag_size)
{
	struct sk_buff *skb;

	skb = kmem_cache_alloc(skbuff_head_cache, GFP_ATOMIC);
	if (unlikely(!skb))
		return NULL;

	memset(skb, 0, offsetof(struct sk_buff, tail));

	return __build_skb_around(skb, data, frag_size);
}

//net/core/skbuff.c：261
/* Caller must provide SKB that is memset cleared */
static struct sk_buff *__build_skb_around(struct sk_buff *skb,
					  void *data, unsigned int frag_size)
{
	struct skb_shared_info *shinfo;
	unsigned int size = frag_size ? : ksize(data);

	size -= SKB_DATA_ALIGN(sizeof(struct skb_shared_info));

	/* Assumes caller memset cleared SKB */
	skb->truesize = SKB_TRUESIZE(size);
	refcount_set(&skb->users, 1);
	skb->head = data;
	skb->data = data;
	skb_reset_tail_pointer(skb);
	skb->end = skb->tail + size;
	skb->mac_header = (typeof(skb->mac_header))~0U;
	skb->transport_header = (typeof(skb->transport_header))~0U;

	/* make sure we initialize shinfo sequentially */
	shinfo = skb_shinfo(skb);
	memset(shinfo, 0, offsetof(struct skb_shared_info, dataref));
	atomic_set(&shinfo->dataref, 1);

	return skb;
}

#endif

#if 1 //kfree_skb()：释放sk_buff结构

/**
 *	kfree_skb - free an sk_buff
 *	@skb: buffer to free
 *
 *	Drop a reference to the buffer and free it if the usage count has
 *	hit zero.
 */
void kfree_skb(struct sk_buff *skb)
{
	if (!skb_unref(skb))
		return;

	trace_kfree_skb(skb, __builtin_return_address(0));
	__kfree_skb(skb);
}
EXPORT_SYMBOL(kfree_skb);

#endif

#if 1 //dev_kfree_skb_any()

//include/linux/netdevice.h:3611
//若调用者是在硬件中断上下文，或硬件中断关闭的情况下，调用该函数释放skb
//		就会将skb放入softnet_data.completion_queue链表首部
//		产生软中断NET_TX_SOFTIRQ
//		在net_tx_action软中断处理例程中，遍历softnet_data.completion_queue链表，真正释放skb
//若调用者不是在硬件中断上下文，或硬件中断关闭的情况下，调用该函数释放skb
//		则直接调用dev_kfree_skb()释放skb
//
//通常驱动程序发送完帧后，是在其poll回调（net_rx_action软中断处理调用）中释放已发送的skb
//此时不属于硬件中断中，硬件中断应该也是打开的
//因此一般来说会直接调用dev_kfree_skb()释放skb
static inline void dev_kfree_skb_any(struct sk_buff *skb)
{
	__dev_kfree_skb_any(skb, SKB_REASON_DROPPED);
}

//net/core/dev.c:2737
void __dev_kfree_skb_any(struct sk_buff *skb, enum skb_free_reason reason)
{
	//在硬中断处理例程中，或硬件中断已经关闭，会进入if子句
	if (in_irq() || irqs_disabled())
		__dev_kfree_skb_irq(skb, reason);
	else
		dev_kfree_skb(skb);
}
EXPORT_SYMBOL(__dev_kfree_skb_any);

//net/core/dev.c:2715
void __dev_kfree_skb_irq(struct sk_buff *skb, enum skb_free_reason reason)
{
	unsigned long flags;

	if (unlikely(!skb))
		return;

	if (likely(refcount_read(&skb->users) == 1)) 
	{
		smp_rmb();
		refcount_set(&skb->users, 0);
	} 
	else if (likely(!refcount_dec_and_test(&skb->users))) 
	{
		return;
	}
	
	get_kfree_skb_cb(skb)->reason = reason;
	
	local_irq_save(flags);
	
	skb->next = __this_cpu_read(softnet_data.completion_queue);
	
	__this_cpu_write(softnet_data.completion_queue, skb);
	
	raise_softirq_irqoff(NET_TX_SOFTIRQ);
	
	local_irq_restore(flags);
}
EXPORT_SYMBOL(__dev_kfree_skb_irq);

//net/core/dev.c:2685
static struct dev_kfree_skb_cb *get_kfree_skb_cb(const struct sk_buff *skb)
{
	return (struct dev_kfree_skb_cb *)(skb->cb);
}


//include/linux/skbuff.h:1143
#define dev_kfree_skb(a)	consume_skb(a)

/**
 *	consume_skb - free an skbuff
 *	@skb: buffer to free
 *
 *	Drop a ref to the buffer and free it if the usage count has hit zero
 *	Functions identically to kfree_skb, but kfree_skb assumes that the frame
 *	is being dropped after a failure and notes that
 */
//skb->users--，即减少引用计数，如果引用计数变为0，即释放该skb
void consume_skb(struct sk_buff *skb)
{
	//如果引用计数可以变为0，即可释放该skb，返回true
	if (!skb_unref(skb))
		return;

	trace_consume_skb(skb);
	__kfree_skb(skb);
}
EXPORT_SYMBOL(consume_skb);

//include/linux/skbuff.h:1006
/**
 * skb_unref - decrement the skb's reference count
 * @skb: buffer
 *
 * Returns true if we can free the skb.
 */
//如果引用计数可以变为0，即可释放该skb，返回true
static inline bool skb_unref(struct sk_buff *skb)
{
	if (unlikely(!skb))
		return false;
	if (likely(refcount_read(&skb->users) == 1))
		smp_rmb();
	else if (likely(!refcount_dec_and_test(&skb->users)))
		return false;

	return true;
}

//net/core/skbuff.c:677
/**
 *	__kfree_skb - private function
 *	@skb: buffer
 *
 *	Free an sk_buff. Release anything attached to the buffer.
 *	Clean the state. This is an internal helper function. Users should
 *	always call kfree_skb
 */
void __kfree_skb(struct sk_buff *skb)
{
	skb_release_all(skb);
	kfree_skbmem(skb);
}
EXPORT_SYMBOL(__kfree_skb);

#endif

#if 1 //skb_reserve()、skb_put()、skb_push()、skb_pull()

//include/linux/skbuff.h：2336
/**
 *	skb_reserve - adjust headroom
 *	@skb: buffer to alter
 *	@len: bytes to move
 *
 *	Increase the headroom of an empty &sk_buff by reducing the tail
 *	room. This is only allowed for an empty buffer.
 */
 //除了为了下层预留添加头部的空间外，还可以用于帮助对齐
 //比如驱动程序常常调用：skb_reserve(skb, 2)
 //mac头14字节，加上2 = 16，即IP头变成16字节对齐
static inline void skb_reserve(struct sk_buff *skb, int len)
{
	skb->data += len;
	skb->tail += len;
}

//net/core/skbuff.c：1859
/**
 *	skb_put - add data to a buffer
 *	@skb: buffer to use
 *	@len: amount of data to add
 *
 *	This function extends the used data area of the buffer. If this would
 *	exceed the total buffer size the kernel will panic. A pointer to the
 *	first byte of the extra data is returned.
 */
//在[skb->data, skb->head+skb->tail)结尾增加len字节空间，并返回老的tail的位置，即新增空间的起始地址
void *skb_put(struct sk_buff *skb, unsigned int len)
{
	void *tmp = skb_tail_pointer(skb);
	
	SKB_LINEAR_ASSERT(skb);
	
	skb->tail += len;
	skb->len  += len;
	
	if (unlikely(skb->tail > skb->end))
		skb_over_panic(skb, len, __builtin_return_address(0));
	
	return tmp;
}
EXPORT_SYMBOL(skb_put);

//include/linux/skbuff.h：2149
//返回tail指向的地址
static inline unsigned char *skb_tail_pointer(const struct sk_buff *skb)
{
	return skb->head + skb->tail;
}

//net/core/skbuff.c：1880
/**
 *	skb_push - add data to the start of a buffer
 *	@skb: buffer to use
 *	@len: amount of data to add
 *
 *	This function extends the used data area of the buffer at the buffer
 *	start. If this would exceed the total buffer headroom the kernel will
 *	panic. A pointer to the first byte of the extra data is returned.
 */
//在[skb->data, skb->head+skb->tail)开头增加len字节空间，并返回新的skb->data的位置，即新增空间的起始地址
void *skb_push(struct sk_buff *skb, unsigned int len)
{
	skb->data -= len;
	skb->len  += len;
	
	if (unlikely(skb->data < skb->head))
		skb_under_panic(skb, len, __builtin_return_address(0));
	
	return skb->data;
}
EXPORT_SYMBOL(skb_push);

//net/core/skbuff.c：1900
/**
 *	skb_pull - remove data from the start of a buffer
 *	@skb: buffer to use
 *	@len: amount of data to remove
 *
 *	This function removes data from the start of a buffer, returning
 *	the memory to the headroom. A pointer to the next data in the buffer
 *	is returned. Once the data has been pulled future pushes will overwrite
 *	the old data.
 */
//在[skb->data, skb->head+skb->tail)开头去掉len字节空间，并返回新的skb->data的位置
void *skb_pull(struct sk_buff *skb, unsigned int len)
{
	return skb_pull_inline(skb, len);
}
EXPORT_SYMBOL(skb_pull);

//include/linux/skbuff.h：2259
static inline void *skb_pull_inline(struct sk_buff *skb, unsigned int len)
{
	return unlikely(len > skb->len) ? NULL : __skb_pull(skb, len);
}

//include/linux/skbuff.h：2252
static inline void *__skb_pull(struct sk_buff *skb, unsigned int len)
{
	skb->len -= len;
	BUG_ON(skb->len < skb->data_len);
	return skb->data += len;
}

#endif

#if 1 //skb_clone()

//net/core/skbuff.c：1430
/**
 *	skb_clone	-	duplicate an sk_buff
 *	@skb: buffer to clone
 *	@gfp_mask: allocation priority
 *
 *	Duplicate an &sk_buff. The new one is not owned by a socket. Both
 *	copies share the same packet data but not structure. The new
 *	buffer has a reference count of 1. If the allocation fails the
 *	function returns %NULL otherwise the new buffer is returned.
 *
 *	If this function is called from an interrupt gfp_mask() must be
 *	%GFP_ATOMIC.
 */
struct sk_buff *skb_clone(struct sk_buff *skb, gfp_t gfp_mask)
{
	struct sk_buff_fclones *fclones = container_of(skb, struct sk_buff_fclones, skb1);
	struct sk_buff *n;

	//若skb_shinfo(skb)->tx_flags设置了SKBTX_DEV_ZEROCOPY位，则会复制skb_shared_info结构中的碎片缓存到新分配的若干页面	
	//说明：
	//skb_shared_info结构中网络数据存储在若干个页面内碎片缓存中，即skb_shinfo(skb)->frags数组中
	//该函数分配若干页面（不一定是连续页面），从页面碎片缓存，将网络数据复制到上述若干页面中
	//然后使用新分配的页面信息，设置skb_shinfo(skb)->frags数组，并释放老的页面碎片缓存
	if (skb_orphan_frags(skb, gfp_mask))
		return NULL;

	if (skb->fclone == SKB_FCLONE_ORIG && refcount_read(&fclones->fclone_ref) == 1) 
	{
		n = &fclones->skb2;
		refcount_set(&fclones->fclone_ref, 2);
	} 
	else 
	{
		if (skb_pfmemalloc(skb))
			gfp_mask |= __GFP_MEMALLOC;

		n = kmem_cache_alloc(skbuff_head_cache, gfp_mask);
		if (!n)
			return NULL;

		n->fclone = SKB_FCLONE_UNAVAILABLE;
	}

	return __skb_clone(n, skb);
}
EXPORT_SYMBOL(skb_clone);

//net/core/skbuff.c：981
/*
 * You should not add any new code to this function.  Add it to
 * __copy_skb_header above instead.
 */
static struct sk_buff *__skb_clone(struct sk_buff *n, struct sk_buff *skb)
{
#define C(x) n->x = skb->x

	n->next = n->prev = NULL;
	n->sk = NULL;
	__copy_skb_header(n, skb);
	C(len);
	C(data_len);
	C(mac_len);
	n->hdr_len = skb->nohdr ? skb_headroom(skb) : skb->hdr_len;
	n->cloned = 1;
	n->nohdr = 0;
	n->peeked = 0;
	C(pfmemalloc);
	n->destructor = NULL;
	C(tail);
	C(end);
	C(head);
	C(head_frag);
	C(data);
	C(truesize);
	refcount_set(&n->users, 1);

	atomic_inc(&(skb_shinfo(skb)->dataref));
	skb->cloned = 1;

	return n;
#undef C
}

//include/linux/skbuff.h：2297
/**
 *	skb_headroom - bytes at buffer head
 *	@skb: buffer to check
 *
 *	Return the number of bytes of free space at the head of an &sk_buff.
 */
static inline unsigned int skb_headroom(const struct sk_buff *skb)
{
	return skb->data - skb->head;
}

//net/core/skbuff.c：929
static void __copy_skb_header(struct sk_buff *new, const struct sk_buff *old)
{
	new->tstamp		= old->tstamp;
	
	/* We do not copy old->sk */
	new->dev		= old->dev;

	memcpy(new->cb, old->cb, sizeof(old->cb));
	
	skb_dst_copy(new, old);

	__skb_ext_copy(new, old);
	
	__nf_copy(new, old, false);

	/* Note : this field could be in headers_start/headers_end section
	 * It is not yet because we do not want to have a 16 bit hole
	 */
	new->queue_mapping = old->queue_mapping;

	memcpy(&new->headers_start, &old->headers_start,
	       offsetof(struct sk_buff, headers_end) -
	       offsetof(struct sk_buff, headers_start));
}

//include/linux/skbuff.h：4209
/* Note: This doesn't put any conntrack info in dst. */
static inline void __nf_copy(struct sk_buff *dst, const struct sk_buff *src, bool copy)
{
	dst->_nfct = src->_nfct;
	nf_conntrack_get(skb_nfct(src));

	if (copy)
		dst->nf_trace = src->nf_trace;
}

//include/linux/netfilter/nf_conntrack_common.h：36
static inline void nf_conntrack_get(struct nf_conntrack *nfct)
{
	if (nfct)
		atomic_inc(&nfct->use);
}

//include/linux/skbuff.h：4053
static inline struct nf_conntrack *skb_nfct(const struct sk_buff *skb)
{
	return (void *)(skb->_nfct & NFCT_PTRMASK);
}

//include/linux/skbuff.h：4119
static inline void __skb_ext_copy(struct sk_buff *dst, const struct sk_buff *src)
{
	dst->active_extensions = src->active_extensions;

	if (src->active_extensions) 
	{
		struct skb_ext *ext = src->extensions;

		refcount_inc(&ext->refcnt);
		dst->extensions = ext;
	}
}

//include/net/dst.h：283
static inline void skb_dst_copy(struct sk_buff *nskb, const struct sk_buff *oskb)
{
	__skb_dst_copy(nskb, oskb->_skb_refdst);
}

//include/net/dst.h：276
static inline void __skb_dst_copy(struct sk_buff *nskb, unsigned long refdst)
{
	nskb->_skb_refdst = refdst;
	
	if (!(nskb->_skb_refdst & SKB_DST_NOREF))
		dst_clone(skb_dst(nskb));
}

//include/net/dst.h：245
static inline struct dst_entry *dst_clone(struct dst_entry *dst)
{
	if (dst)
		dst_hold(dst);
	
	return dst;
}

//include/net/dst.h：221
static inline void dst_hold(struct dst_entry *dst)
{
	/*
	 * If your kernel compilation stops here, please check
	 * the placement of __refcnt in struct dst_entry
	 */
	BUILD_BUG_ON(offsetof(struct dst_entry, __refcnt) & 63);

	//increment unless the number is zero
	WARN_ON(atomic_inc_not_zero(&dst->__refcnt) == 0);
}

//include/linux/skbuff.h：920
/**
 * skb_dst - returns skb dst_entry
 * @skb: buffer
 *
 * Returns skb dst_entry, regardless of reference taken or not.
 */
static inline struct dst_entry *skb_dst(const struct sk_buff *skb)
{
	/* If refdst was not refcounted, check we still are in a
	 * rcu_read_lock section
	 */
	WARN_ON((skb->_skb_refdst & SKB_DST_NOREF) &&
		!rcu_read_lock_held() &&
		!rcu_read_lock_bh_held());
	
	return (struct dst_entry *)(skb->_skb_refdst & SKB_DST_PTRMASK);
}

//include/linux/skbuff.h：902
/**
 * skb_pfmemalloc - Test if the skb was allocated from PFMEMALLOC reserves
 * @skb: buffer
 */
static inline bool skb_pfmemalloc(const struct sk_buff *skb)
{
	return unlikely(skb->pfmemalloc);
}

//include/linux/skbuff.h：2722
/**
 *	skb_orphan_frags - orphan the frags contained in a buffer
 *	@skb: buffer to orphan frags from
 *	@gfp_mask: allocation mask for replacement pages
 *
 *	For each frag in the SKB which needs a destructor (i.e. has an
 *	owner) create a copy of that frag and release the original
 *	page by calling the destructor.
 */
//若skb_shinfo(skb)->tx_flags设置了SKBTX_DEV_ZEROCOPY位，则会复制skb_shared_info结构中的碎片缓存到新分配的若干页面	
//说明：
//skb_shared_info结构中网络数据存储在若干个页面内碎片缓存中，即skb_shinfo(skb)->frags数组中
//该函数分配若干页面（不一定是连续页面），从页面碎片缓存，将网络数据复制到上述若干页面中
//然后使用新分配的页面信息，设置skb_shinfo(skb)->frags数组，并释放老的页面碎片缓存
static inline int skb_orphan_frags(struct sk_buff *skb, gfp_t gfp_mask)
{
	if (likely(!skb_zcopy(skb)))
		return 0;
	
	if (!skb_zcopy_is_nouarg(skb) && skb_uarg(skb)->callback == sock_zerocopy_callback)
		return 0;

	//复制skb_shinfo结构中的碎片缓存到新分配的若干页面
	return skb_copy_ubufs(skb, gfp_mask);
}

//net/core/skbuff.c：1342
/**
 *	skb_copy_ubufs	-	copy userspace skb frags buffers to kernel
 *	@skb: the skb to modify
 *	@gfp_mask: allocation priority
 *
 *	This must be called on SKBTX_DEV_ZEROCOPY skb.
 *	It will copy all frags into kernel and drop the reference
 *	to userspace pages.
 *
 *	If this function is called from an interrupt gfp_mask() must be
 *	%GFP_ATOMIC.
 *
 *	Returns 0 on success or a negative error code on failure
 *	to allocate kernel memory to copy to.
 */
//skb_shinfo结构中网络数据存储在若干个页面内碎片缓存中，即skb_shinfo(skb)->frags数组中
//该函数分配若干页面（不一定是连续页面），从页面碎片缓存，将网络数据复制到上述若干页面中
//然后使用新分配的页面信息，设置skb_shinfo(skb)->frags数组，并释放老的页面碎片缓存
int skb_copy_ubufs(struct sk_buff *skb, gfp_t gfp_mask)
{
	int num_frags = skb_shinfo(skb)->nr_frags;
	struct page *page, *head = NULL;
	int i, new_frags;
	u32 d_off;

	//若skb引用计数大于1，则返回
	if (skb_shared(skb) || skb_unclone(skb, gfp_mask))
		return -EINVAL;

	if (!num_frags)
		goto release;

	new_frags = (__skb_pagelen(skb) + PAGE_SIZE - 1) >> PAGE_SHIFT;
	for (i = 0; i < new_frags; i++) {
		page = alloc_page(gfp_mask);
		if (!page) {
			while (head) {
				struct page *next = (struct page *)page_private(head);
				put_page(head);
				head = next;
			}
			return -ENOMEM;
		}
		set_page_private(page, (unsigned long)head);
		head = page;
	}

	page = head;
	d_off = 0;
	for (i = 0; i < num_frags; i++) {
		skb_frag_t *f = &skb_shinfo(skb)->frags[i];
		u32 p_off, p_len, copied;
		struct page *p;
		u8 *vaddr;

		skb_frag_foreach_page(f, skb_frag_off(f), skb_frag_size(f),
				      p, p_off, p_len, copied) {
			u32 copy, done = 0;
			vaddr = kmap_atomic(p);

			while (done < p_len) {
				if (d_off == PAGE_SIZE) {
					d_off = 0;
					page = (struct page *)page_private(page);
				}
				copy = min_t(u32, PAGE_SIZE - d_off, p_len - done);
				memcpy(page_address(page) + d_off,
				       vaddr + p_off + done, copy);
				done += copy;
				d_off += copy;
			}
			kunmap_atomic(vaddr);
		}
	}

	/* skb frags release userspace buffers */
	for (i = 0; i < num_frags; i++)
		skb_frag_unref(skb, i);

	/* skb frags point to kernel buffers */
	for (i = 0; i < new_frags - 1; i++) {
		__skb_fill_page_desc(skb, i, head, 0, PAGE_SIZE);
		head = (struct page *)page_private(head);
	}
	__skb_fill_page_desc(skb, new_frags - 1, head, 0, d_off);
	skb_shinfo(skb)->nr_frags = new_frags;

release:
	skb_zcopy_clear(skb, false);
	return 0;
}
EXPORT_SYMBOL_GPL(skb_copy_ubufs);

//include/linux/skbuff.h：1661
/**
 *	skb_shared - is the buffer shared
 *	@skb: buffer to check
 *
 *	Returns true if more than one person has a reference to this
 *	buffer.
 */
static inline int skb_shared(const struct sk_buff *skb)
{
	return refcount_read(&skb->users) != 1;
}

//include/linux/skbuff.h：1436
static inline bool skb_zcopy_is_nouarg(struct sk_buff *skb)
{
	return (uintptr_t) skb_shinfo(skb)->destructor_arg & 0x1UL;
}

//include/linux/skbuff.h：1410
static inline struct ubuf_info *skb_zcopy(struct sk_buff *skb)
{
	bool is_zcopy = skb && skb_shinfo(skb)->tx_flags & SKBTX_DEV_ZEROCOPY;

	return is_zcopy ? skb_uarg(skb) : NULL;
}

//include/linux/skbuff.h：483
#define skb_uarg(SKB)	((struct ubuf_info *)(skb_shinfo(SKB)->destructor_arg))
	
#endif

#if 1 //pskb_copy()

//include/linux/skbuff.h：3074
static inline struct sk_buff *pskb_copy(struct sk_buff *skb, gfp_t gfp_mask)
{
	return __pskb_copy(skb, skb_headroom(skb), gfp_mask);
}

//include/linux/skbuff.h：1110
static inline struct sk_buff *__pskb_copy(struct sk_buff *skb, int headroom, gfp_t gfp_mask)
{
	return __pskb_copy_fclone(skb, headroom, gfp_mask, false);
}

//net/core/skbuff.c：1548
/**
 *	__pskb_copy_fclone	-  create copy of an sk_buff with private head.
 *	@skb: buffer to copy
 *	@headroom: headroom of new skb
 *	@gfp_mask: allocation priority
 *	@fclone: true，会设置SKB_ALLOC_FCLONE标志
 *
 *	if true allocate the copy of the skb from the fclone
 *	cache instead of the head cache; it is recommended to set this
 *	to true for the cases where the copy will likely be cloned
 *
 *	Make a copy of both an &sk_buff and part of its data, located
 *	in header. Fragmented data remain shared. This is used when
 *	the caller wishes to modify only header of &sk_buff and needs
 *	private copy of the header to alter. Returns %NULL on failure
 *	or the pointer to the buffer on success.
 *	The returned buffer has a reference count of 1.
 */
struct sk_buff *__pskb_copy_fclone(struct sk_buff *skb, int headroom, gfp_t gfp_mask, bool fclone)
{
	//只复制缓冲区空余出来的头部，和数据包的头部
	unsigned int size = skb_headlen(skb) + headroom;

	//若skb是从紧急内存中分配的，会设置SKB_ALLOC_RX
	int flags = skb_alloc_rx_flag(skb) | (fclone ? SKB_ALLOC_FCLONE : 0);
	
	struct sk_buff *n = __alloc_skb(size, gfp_mask, flags, NUMA_NO_NODE);

	if (!n)
		goto out;

	/* Set the data pointer */
	skb_reserve(n, headroom);
	/* Set the tail pointer and length */
	skb_put(n, skb_headlen(skb));
	/* Copy the bytes */
	skb_copy_from_linear_data(skb, n->data, n->len);

	n->truesize += skb->data_len;
	n->data_len  = skb->data_len;
	n->len	     = skb->len;

	if (skb_shinfo(skb)->nr_frags) 
	{
		int i;

		if (skb_orphan_frags(skb, gfp_mask) || skb_zerocopy_clone(n, skb, gfp_mask)) 
		{
			kfree_skb(n);
			n = NULL;
			goto out;
		}
		
		for (i = 0; i < skb_shinfo(skb)->nr_frags; i++) 
		{
			skb_shinfo(n)->frags[i] = skb_shinfo(skb)->frags[i];
			skb_frag_ref(skb, i);
		}
		skb_shinfo(n)->nr_frags = i;
	}

	if (skb_has_frag_list(skb)) 
	{
		skb_shinfo(n)->frag_list = skb_shinfo(skb)->frag_list;
		skb_clone_fraglist(n);
	}

	skb_copy_header(n, skb);
out:
	return n;
}
EXPORT_SYMBOL(__pskb_copy_fclone);

//net/core/skbuff.c：1475
void skb_copy_header(struct sk_buff *new, const struct sk_buff *old)
{
	__copy_skb_header(new, old);

	skb_shinfo(new)->gso_size = skb_shinfo(old)->gso_size;
	skb_shinfo(new)->gso_segs = skb_shinfo(old)->gso_segs;
	skb_shinfo(new)->gso_type = skb_shinfo(old)->gso_type;
}
EXPORT_SYMBOL(skb_copy_header);

//net/core/skbuff.c：576
static void skb_clone_fraglist(struct sk_buff *skb)
{
	struct sk_buff *list;

	skb_walk_frags(skb, list)
		skb_get(list);
}

//include/linux/skbuff.h：1500
/**
 *	skb_get - reference buffer
 *	@skb: buffer to reference
 *
 *	Makes another reference to a socket buffer and returns a pointer
 *	to the buffer.
 */
static inline struct sk_buff *skb_get(struct sk_buff *skb)
{
	refcount_inc(&skb->users);
	return skb;
}

//include/linux/skbuff.h：3446
static inline bool skb_has_frag_list(const struct sk_buff *skb)
{
	return skb_shinfo(skb)->frag_list != NULL;
}

//include/linux/skbuff.h：2947
/**
 * __skb_frag_ref - take an addition reference on a paged fragment.
 * @frag: the paged fragment
 *
 * Takes an additional reference on the paged fragment @frag.
 */
static inline void __skb_frag_ref(skb_frag_t *frag)
{
	get_page(skb_frag_page(frag));
}

//include/linux/skbuff.h：2959
/**
 * skb_frag_ref - take an addition reference on a paged fragment of an skb.
 * @skb: the buffer
 * @f: the fragment offset.
 *
 * Takes an additional reference on the @f'th paged fragment of @skb.
 */
static inline void skb_frag_ref(struct sk_buff *skb, int f)
{
	__skb_frag_ref(&skb_shinfo(skb)->frags[f]);
}


//net/core/skbuff.c：1307
static int skb_zerocopy_clone(struct sk_buff *nskb, struct sk_buff *orig, gfp_t gfp_mask)
{
	if (skb_zcopy(orig)) 
	{
		if (skb_zcopy(nskb)) 
		{
			/* !gfp_mask callers are verified to !skb_zcopy(nskb) */
			if (!gfp_mask) {
				WARN_ON_ONCE(1);
				return -ENOMEM;
			}
			if (skb_uarg(nskb) == skb_uarg(orig))
				return 0;
			if (skb_copy_ubufs(nskb, GFP_ATOMIC))
				return -EIO;
		}

		skb_zcopy_set(nskb, skb_uarg(orig), NULL);
	}
	return 0;
}

//include/linux/skbuff.h：1417
static inline void skb_zcopy_set(struct sk_buff *skb, struct ubuf_info *uarg,
				 bool *have_ref)
{
	if (skb && uarg && !skb_zcopy(skb)) {
		if (unlikely(have_ref && *have_ref))
			*have_ref = false;
		else
			sock_zerocopy_get(uarg);
		skb_shinfo(skb)->destructor_arg = uarg;
		skb_shinfo(skb)->tx_flags |= SKBTX_ZEROCOPY_FRAG;
	}
}

//include/linux/skbuff.h：3598
static inline void skb_copy_from_linear_data(const struct sk_buff *skb,
					     void *to,
					     const unsigned int len)
{
	memcpy(to, skb->data, len);
}

//net/core/skbuff.c：1485
static inline int skb_alloc_rx_flag(const struct sk_buff *skb)
{
	if (skb_pfmemalloc(skb))
		return SKB_ALLOC_RX;
	
	return 0;
}

//include/linux/skbuff.h：2068
static inline unsigned int skb_headlen(const struct sk_buff *skb)
{
	return skb->len - skb->data_len;
}

#endif

#if 1 //skb_copy()

//复制sk_buff对应的线性缓冲、页面内碎片缓冲、frag_list缓冲中的数据，到新skb对应的线性缓冲区域

//net/core/skbuff.c：1509
/**
 *	skb_copy	-	create private copy of an sk_buff
 *	@skb: buffer to copy
 *	@gfp_mask: allocation priority
 *
 *	Make a copy of both an &sk_buff and its data. This is used when the
 *	caller wishes to modify the data and needs a private copy of the
 *	data to alter. Returns %NULL on failure or the pointer to the buffer
 *	on success. The returned buffer has a reference count of 1.
 *
 *	As by-product this function converts non-linear &sk_buff to linear
 *	one, so that &sk_buff becomes completely private and caller is allowed
 *	to modify all the data of returned buffer. This means that this
 *	function is not recommended for use in circumstances when only
 *	header is going to be modified. Use pskb_copy() instead.
 */
struct sk_buff *skb_copy(const struct sk_buff *skb, gfp_t gfp_mask)
{
	int headerlen = skb_headroom(skb);
	
	unsigned int size = skb_end_offset(skb) + skb->data_len;
	
	struct sk_buff *n = __alloc_skb(size, gfp_mask, skb_alloc_rx_flag(skb), NUMA_NO_NODE);
	if (!n)
		return NULL;

	/* Set the data pointer */
	skb_reserve(n, headerlen);
	
	/* Set the tail pointer and length */
	skb_put(n, skb->len);

	BUG_ON(skb_copy_bits(skb, -headerlen, n->head, headerlen + skb->len));

	skb_copy_header(n, skb);
	return n;
}
EXPORT_SYMBOL(skb_copy);

//net/core/skbuff.c：2188
/**
 *	skb_copy_bits - copy bits from skb to kernel buffer
 *	@skb: source skb
 *	@offset: offset in source
 *	@to: destination buffer
 *	@len: number of bytes to copy
 *
 *	Copy the specified number of bytes from the source skb to the
 *	destination buffer.
 *
 *	CAUTION ! :
 *		If its prototype is ever changed,
 *		check arch/{*}/net/{*}.S files,
 *		since it is called from BPF assembly code.
 */
int skb_copy_bits(const struct sk_buff *skb, int offset, void *to, int len)
{
	int start = skb_headlen(skb);
	struct sk_buff *frag_iter;
	int i, copy;

	if (offset > (int)skb->len - len)
		goto fault;

	/* Copy header. */
	if ((copy = start - offset) > 0) 
	{
		if (copy > len)
			copy = len;

		//实际复制[skb->head, skb->tail)，即线性缓冲区域
		skb_copy_from_linear_data_offset(skb, offset, to, copy);

		if ((len -= copy) == 0)
			return 0;
		
		offset += copy;
		to     += copy;
	}

	for (i = 0; i < skb_shinfo(skb)->nr_frags; i++) 
	{
		int end;
		skb_frag_t *f = &skb_shinfo(skb)->frags[i];

		WARN_ON(start > offset + len);

		end = start + skb_frag_size(f);
		if ((copy = end - offset) > 0) 
		{
			u32 p_off, p_len, copied;
			struct page *p;
			u8 *vaddr;

			if (copy > len)
				copy = len;

			//复制非线性缓冲中的网络数据，到线性缓冲中
			skb_frag_foreach_page(f,
					      skb_frag_off(f) + offset - start,
					      copy, p, p_off, p_len, copied) 
			{
				vaddr = kmap_atomic(p);
				memcpy(to + copied, vaddr + p_off, p_len);
				kunmap_atomic(vaddr);
			}

			if ((len -= copy) == 0)
				return 0;
			offset += copy;
			to     += copy;
		}
		start = end;
	}

	//复制skb_shared_info中的frag_list链表中的网络数据，到线性缓冲区域
	skb_walk_frags(skb, frag_iter) 
	{
		int end;

		WARN_ON(start > offset + len);

		end = start + frag_iter->len;
		if ((copy = end - offset) > 0) 
		{
			if (copy > len)
				copy = len;
			if (skb_copy_bits(frag_iter, offset - start, to, copy))
				goto fault;
			if ((len -= copy) == 0)
				return 0;
			offset += copy;
			to     += copy;
		}
		start = end;
	}

	if (!len)
		return 0;

fault:
	return -EFAULT;
}
EXPORT_SYMBOL(skb_copy_bits);

//include/linux/skbuff.h：3605
static inline void skb_copy_from_linear_data_offset(const struct sk_buff *skb,
						    const int offset, void *to,
						    const unsigned int len)
{
	memcpy(to, skb->data + offset, len);
}

//include/linux/skbuff.h：1386
static inline unsigned int skb_end_offset(const struct sk_buff *skb)
{
	return skb->end;
}

#endif

#endif

#if 1 //sk_buff_head，即skb链表的管理函数

#if 1 //skb_queue_head_init()

//include/linux/skbuff.h：1841
/*
 * This function creates a split out lock class for each invocation;
 * this is needed for now since a whole lot of users of the skb-queue
 * infrastructure in drivers have different locking usage (in hardirq)
 * than the networking core (in softirq only). In the long run either the
 * network layer or drivers should need annotation to consolidate the
 * main types of usage into 3 classes.
 */
static inline void skb_queue_head_init(struct sk_buff_head *list)
{
	spin_lock_init(&list->lock);
	__skb_queue_head_init(list);
}

//include/linux/skbuff.h：1827
/**
 *	__skb_queue_head_init - initialize non-spinlock portions of sk_buff_head
 *	@list: queue to initialize
 *
 *	This initializes only the list and queue length aspects of
 *	an sk_buff_head object.  This allows to initialize the list
 *	aspects of an sk_buff_head without reinitializing things like
 *	the spinlock.  It can also be used for on-stack sk_buff_head
 *	objects where the spinlock is known to not be used.
 */
static inline void __skb_queue_head_init(struct sk_buff_head *list)
{
	list->prev = list->next = (struct sk_buff *)list;
	list->qlen = 0;
}

#endif

#if 1 //skb_queue_head()：在头部插入新的skb

//include/linux/skbuff.h：3119
/**
 *	skb_queue_head - queue a buffer at the list head
 *	@list: list to use
 *	@newsk: buffer to queue
 *
 *	Queue a buffer at the start of the list. This function takes the
 *	list lock and can be used safely with other locking &sk_buff functions
 *	safely.
 *
 *	A buffer cannot be placed on two lists at the same time.
 */
//在list之后（以next字段为序）插入新结点
void skb_queue_head(struct sk_buff_head *list, struct sk_buff *newsk)
{
	unsigned long flags;

	spin_lock_irqsave(&list->lock, flags);
	
	__skb_queue_head(list, newsk);
	
	spin_unlock_irqrestore(&list->lock, flags);
}
EXPORT_SYMBOL(skb_queue_head);

//include/linux/skbuff.h：1987
/**
 *	__skb_queue_head - queue a buffer at the list head
 *	@list: list to use
 *	@newsk: buffer to queue
 *
 *	Queue a buffer at the start of a list. This function takes no locks
 *	and you must therefore hold required locks before calling it.
 *
 *	A buffer cannot be placed on two lists at the same time.
 */
//在list之后（以next字段为序）插入新结点
static inline void __skb_queue_head(struct sk_buff_head *list, struct sk_buff *newsk)
{
	__skb_queue_after(list, (struct sk_buff *)list, newsk);
}

//include/linux/skbuff.h：1960
/**
 *	__skb_queue_after - queue a buffer at the list head
 *	@list: list to use
 *	@prev: place after this buffer
 *	@newsk: buffer to queue
 *
 *	Queue a buffer int the middle of a list. This function takes no locks
 *	and you must therefore hold required locks before calling it.
 *
 *	A buffer cannot be placed on two lists at the same time.
 */
//在prev之后（以next字段为序）插入新结点
static inline void __skb_queue_after(struct sk_buff_head *list,
				     struct sk_buff *prev,
				     struct sk_buff *newsk)
{
	__skb_insert(newsk, prev, prev->next, list);
}

//include/linux/skbuff.h：1860
/*
 *	Insert an sk_buff on a list.
 *
 *	The "__skb_xxxx()" functions are the non-atomic ones that
 *	can only be called with interrupts disabled.
 */
//在prev结点和next结点之间插入新结点
static inline void __skb_insert(struct sk_buff *newsk,
				struct sk_buff *prev, struct sk_buff *next,
				struct sk_buff_head *list)
{
	/* see skb_queue_empty_lockless() for the opposite READ_ONCE() */
	WRITE_ONCE(newsk->next, next);
	WRITE_ONCE(newsk->prev, prev);
	WRITE_ONCE(next->prev, newsk);
	WRITE_ONCE(prev->next, newsk);
	list->qlen++;
}

#endif

#if 1 //skb_queue_tail()：在尾部插入新的skb

//net/core/skbuff.c：3140
/**
 *	skb_queue_tail - queue a buffer at the list tail
 *	@list: list to use
 *	@newsk: buffer to queue
 *
 *	Queue a buffer at the tail of the list. This function takes the
 *	list lock and can be used safely with other locking &sk_buff functions
 *	safely.
 *
 *	A buffer cannot be placed on two lists at the same time.
 */
//在list之前（以prev字段为序）插入新结点
void skb_queue_tail(struct sk_buff_head *list, struct sk_buff *newsk)
{
	unsigned long flags;

	spin_lock_irqsave(&list->lock, flags);
	
	__skb_queue_tail(list, newsk);
	
	spin_unlock_irqrestore(&list->lock, flags);
}
EXPORT_SYMBOL(skb_queue_tail);

//include/linux/skbuff.h：2004
/**
 *	__skb_queue_tail - queue a buffer at the list tail
 *	@list: list to use
 *	@newsk: buffer to queue
 *
 *	Queue a buffer at the end of a list. This function takes no locks
 *	and you must therefore hold required locks before calling it.
 *
 *	A buffer cannot be placed on two lists at the same time.
 */
static inline void __skb_queue_tail(struct sk_buff_head *list, struct sk_buff *newsk)
{
	__skb_queue_before(list, (struct sk_buff *)list, newsk);
}

//include/linux/skbuff.h：1970
//在next之前（以prev字段为序）插入新结点
static inline void __skb_queue_before(struct sk_buff_head *list,
				      struct sk_buff *next,
				      struct sk_buff *newsk)
{
	__skb_insert(newsk, next->prev, next, list);
}

#endif

#if 1 //skb_dequeue()：从skb链表头部取出一个skb

//net/core/skbuff.c：3034
/**
 *	skb_dequeue - remove from the head of the queue
 *	@list: list to dequeue from
 *
 *	Remove the head of the list. The list lock is taken so the function
 *	may be used safely with other locking list functions. The head item is
 *	returned or %NULL if the list is empty.
 */
 //从skb链表头部取出一个skb，链表为空则返回NULL
struct sk_buff *skb_dequeue(struct sk_buff_head *list)
{
	unsigned long flags;
	struct sk_buff *result;

	spin_lock_irqsave(&list->lock, flags);
	
	result = __skb_dequeue(list);
	
	spin_unlock_irqrestore(&list->lock, flags);
	
	return result;
}
EXPORT_SYMBOL(skb_dequeue);

//include/linux/skbuff.h：2036
/**
 *	__skb_dequeue - remove from the head of the queue
 *	@list: list to dequeue from
 *
 *	Remove the head of the list. This function does not take any locks
 *	so must be used with appropriate locks held only. The head item is
 *	returned or %NULL if the list is empty.
 */
static inline struct sk_buff *__skb_dequeue(struct sk_buff_head *list)
{
	struct sk_buff *skb = skb_peek(list);
	if (skb)
		__skb_unlink(skb, list);
	
	return skb;
}

//include/linux/skbuff.h：2016
//从skb链表中摘除skb
static inline void __skb_unlink(struct sk_buff *skb, struct sk_buff_head *list)
{
	struct sk_buff *next, *prev;

	list->qlen--;
	next	   = skb->next;
	prev	   = skb->prev;
	skb->next  = skb->prev = NULL;
	WRITE_ONCE(next->prev, prev);
	WRITE_ONCE(prev->next, next);
}

//include/linux/skbuff.h：1744
/**
 *	skb_peek - peek at the head of an &sk_buff_head
 *	@list_: list to peek at
 *
 *	Peek an &sk_buff. Unlike most other operations you _MUST_
 *	be careful with this one. A peek leaves the buffer on the
 *	list and someone else may run off with it. You must hold
 *	the appropriate locks or have a private queue to do this.
 *
 *	Returns %NULL for an empty list or a pointer to the head element.
 *	The reference count is not incremented and the reference is therefore
 *	volatile. Use with caution.
 */
//查看skb链表第一个skb，但不取出
static inline struct sk_buff *skb_peek(const struct sk_buff_head *list_)
{
	struct sk_buff *skb = list_->next;

	if (skb == (struct sk_buff *)list_)
		skb = NULL;
	
	return skb;
}

#endif

#if 1 //skb_dequeue_tail()：从skb链表尾部取出一个skd

/**
 *	skb_dequeue_tail - remove from the tail of the queue
 *	@list: list to dequeue from
 *
 *	Remove the tail of the list. The list lock is taken so the function
 *	may be used safely with other locking list functions. The tail item is
 *	returned or %NULL if the list is empty.
 */
//从skb链表尾部取出一个skb，链表为空则返回NULL
struct sk_buff *skb_dequeue_tail(struct sk_buff_head *list)
{
	unsigned long flags;
	struct sk_buff *result;

	spin_lock_irqsave(&list->lock, flags);
	
	result = __skb_dequeue_tail(list);
	
	spin_unlock_irqrestore(&list->lock, flags);
	
	return result;
}
EXPORT_SYMBOL(skb_dequeue_tail);

//include/linux/skbuff.h：2053
/**
 *	__skb_dequeue_tail - remove from the tail of the queue
 *	@list: list to dequeue from
 *
 *	Remove the tail of the list. This function does not take any locks
 *	so must be used with appropriate locks held only. The tail item is
 *	returned or %NULL if the list is empty.
 */
static inline struct sk_buff *__skb_dequeue_tail(struct sk_buff_head *list)
{
	struct sk_buff *skb = skb_peek_tail(list);
	if (skb)
		__skb_unlink(skb, list);
	
	return skb;
}

//include/linux/skbuff.h：1756
/**
 *	skb_peek_tail - peek at the tail of an &sk_buff_head
 *	@list_: list to peek at
 *
 *	Peek an &sk_buff. Unlike most other operations you _MUST_
 *	be careful with this one. A peek leaves the buffer on the
 *	list and someone else may run off with it. You must hold
 *	the appropriate locks or have a private queue to do this.
 *
 *	Returns %NULL for an empty list or a pointer to the tail element.
 *	The reference count is not incremented and the reference is therefore
 *	volatile. Use with caution.
 */
//查看skb链表最后一个skb，但不取出
static inline struct sk_buff *skb_peek_tail(const struct sk_buff_head *list_)
{
	struct sk_buff *skb = list_->prev;

	if (skb == (struct sk_buff *)list_)
		skb = NULL;
	return skb;

}

#endif

#if 1 //skb_queue_purge()：逐一从skb链表头取出skd并释放，直到取空

//net/core/skbuff.c：3074
/**
 *	skb_queue_purge - empty a list
 *	@list: list to empty
 *
 *	Delete all buffers on an &sk_buff list. Each buffer is removed from
 *	the list and one reference dropped. This function takes the list
 *	lock and is atomic with respect to other list locking functions.
 */
void skb_queue_purge(struct sk_buff_head *list)
{
	struct sk_buff *skb;
	
	while ((skb = skb_dequeue(list)) != NULL)
		kfree_skb(skb);
}
EXPORT_SYMBOL(skb_queue_purge);

#endif

#if 1 //skb_queue_walk()：逐一访问skb链表的每个元素

#define skb_queue_walk(queue, skb) \
		for (skb = (queue)->next;					\
		     skb != (struct sk_buff *)(queue);				\
		     skb = skb->next)

#endif

#endif

#if 1 //skb_array结构及管理函数

#if 1 //skb_array结构

//include/linux/skb_array.h:25
struct skb_array 
{
	struct ptr_ring ring;
};

//include/linux/ptr_ring.h:29
//实现环形缓冲区逻辑
//.queue数组，即代表了.size个缓冲区，这些缓冲区构成环形缓冲区
//.queue数组元素，是否为NULL，来判断该元素是否被占用，即存放了用户数据
//.producer保存queue数组中当前空闲元素起始索引
//	当向环形缓冲区加入用户数据时，先检测.queue[producer]是否为NULL，为NULL才会加入用户数据，并producer++
//.consumer_head保存queue数组中第一个有用户数据的元素的索引
//	当从环形缓冲取出用户数据时，先检测.queue[consumer_head]是否为NULL，
//		不为NULL时，返回用户数据，并将consumer_head++
//	注意，此时一般都不会执行.queue[consumer_head]=NULL，而是以批处理方式进行
//.consumer_tail保存了queue数组中已经不包含用户数据，但内容不等于NULL的最老（最早被写入）的元素索引
//	当consumer_head与consumer_tail之间的间隔达到.batch时，
//	就会将.queue数组中索引位于consumer_head与consumer_tail之间的元素内容清NULL
//	并更新consumer_tail = consumer_head
struct ptr_ring 
{
	//该字段保存queue数组中当前空闲元素起始索引
	int producer;// ____cacheline_aligned_in_smp;
	
	spinlock_t producer_lock;

	//该字段保存queue数组中第一个有数据的元素的索引
	int consumer_head;// ____cacheline_aligned_in_smp; /* next valid entry */

	//保存了queue数组中已经不包含用户数据，但内容不等于NULL的最老（最早被写入）的元素索引
	int consumer_tail; /* next entry to invalidate */
	
	spinlock_t consumer_lock;
	
	/* Shared consumer/producer data */
	/* Read-only by both the producer and the consumer */

	//queue数组的元素个数
	int size;// ____cacheline_aligned_in_smp; /* max entries in queue */

	//该字段= SMP_CACHE_BYTES(64) * 2 / sizeof(*(r->queue));
	//即16
	//即一次处理queue数组16个元素？
	int batch; /* number of entries to consume in a batch */

	//queue指向元素类型是void*的数组，即缓冲区数组
	//比如：该数组的元素类型可以是sk_buff *，即保存待发送的skb地址。只是一个skb，而非链表
	//当从该数组取出缓冲区时，就会将相应的数组元素清0
	void **queue;
};

#endif

#if 1 //skb_array_init函数

//include/linux/skb_array.h
static inline int skb_array_init(struct skb_array *a, int size, gfp_t gfp)
{
	return ptr_ring_init(&a->ring, size, gfp);
}

//include/linux/ptr_ring.h:486
//为r->queue分配空间，该字段指向元素类型是void*的数组
static inline int ptr_ring_init(struct ptr_ring *r, int size, gfp_t gfp)
{
	r->queue = __ptr_ring_init_queue_alloc(size, gfp);
	if (!r->queue)
		return -ENOMEM;

	__ptr_ring_set_size(r, size);
	
	r->producer = r->consumer_head = r->consumer_tail = 0;
	
	spin_lock_init(&r->producer_lock);
	spin_lock_init(&r->consumer_lock);

	return 0;
}

//include/linux/ptr_ring.h:473
static inline void __ptr_ring_set_size(struct ptr_ring *r, int size)
{
	r->size = size;
	
	r->batch = SMP_CACHE_BYTES * 2 / sizeof(*(r->queue));
	
	/* We need to set batch at least to 1 to make logic
	 * in __ptr_ring_discard_one work correctly.
	 * Batching too much (because ring is small) would cause a lot of
	 * burstiness. Needs tuning, for now disable batching.
	 */
	if (r->batch > r->size / 2 || !r->batch)
		r->batch = 1;
}

//include/linux/ptr_ring.h:466
static inline void **__ptr_ring_init_queue_alloc(unsigned int size, gfp_t gfp)
{
	if (size > KMALLOC_MAX_SIZE / sizeof(void *))
		return NULL;

	//分配size个，每个大小void*
	return kvmalloc_array(size, sizeof(void *), gfp | __GFP_ZERO);
}

#endif

#if 1 //skb_array_produce函数

//include/linux/skb_array.h
//skb_array本质上是环形缓冲区
//该函数将待发送的skb，放入上述环形缓冲区中
//成功返回0
static inline int skb_array_produce(struct skb_array *a, struct sk_buff *skb)
{
	return ptr_ring_produce(&a->ring, skb);
}

//include/linux/ptr_ring.h:123
/*
 * Note: resize (below) nests producer lock within consumer lock, so if you
 * consume in interrupt or BH context, you must disable interrupts/BH when
 * calling this.
 */
static inline int ptr_ring_produce(struct ptr_ring *r, void *ptr)
{
	int ret;

	spin_lock(&r->producer_lock);
	ret = __ptr_ring_produce(r, ptr);
	spin_unlock(&r->producer_lock);

	return ret;
}

//include/linux/ptr_ring.h:98
/* Note: callers invoking this in a loop must use a compiler barrier,
 * for example cpu_relax(). Callers must hold producer_lock.
 * Callers are responsible for making sure pointer that is being queued
 * points to a valid data.
 */
static inline int __ptr_ring_produce(struct ptr_ring *r, void *ptr)
{
	if (unlikely(!r->size) || r->queue[r->producer])
		return -ENOSPC;

	/* Make sure the pointer we are storing points to a valid data. */
	/* Pairs with smp_read_barrier_depends in __ptr_ring_consume. */
	smp_wmb();

	WRITE_ONCE(r->queue[r->producer++], ptr);
	if (unlikely(r->producer >= r->size))
		r->producer = 0;
	
	return 0;
}

#endif

#if 1 //skb_array_consume函数

//include/linux/skb_array.h:101
static inline struct sk_buff *skb_array_consume(struct skb_array *a)
{
	return ptr_ring_consume(&a->ring);
}

//include/linux/ptr_ring.h:326
/*
 * Note: resize (below) nests producer lock within consumer lock, so if you
 * call this in interrupt or BH context, you must disable interrupts/BH when
 * producing.
 */
static inline void *ptr_ring_consume(struct ptr_ring *r)
{
	void *ptr;

	spin_lock(&r->consumer_lock);
	ptr = __ptr_ring_consume(r);
	spin_unlock(&r->consumer_lock);

	return ptr;
}

//include/linux/skb_array.h:96
static inline struct sk_buff *__skb_array_consume(struct skb_array *a)
{
	return __ptr_ring_consume(&a->ring);
}

//include/linux/ptr_ring.h:290
static inline void *__ptr_ring_consume(struct ptr_ring *r)
{
	void *ptr;

	/* The READ_ONCE in __ptr_ring_peek guarantees that anyone
	 * accessing data through the pointer is up to date. Pairs
	 * with smp_wmb in __ptr_ring_produce.
	 */
	ptr = __ptr_ring_peek(r);
	if (ptr)
		__ptr_ring_discard_one(r);

	return ptr;
}

//include/linux/ptr_ring.h:246
/* Must only be called after __ptr_ring_peek returned !NULL */
static inline void __ptr_ring_discard_one(struct ptr_ring *r)
{
	/* Fundamentally, what we want to do is update consumer
	 * index and zero out the entry so producer can reuse it.
	 * Doing it naively at each consume would be as simple as:
	 *       consumer = r->consumer;
	 *       r->queue[consumer++] = NULL;
	 *       if (unlikely(consumer >= r->size))
	 *               consumer = 0;
	 *       r->consumer = consumer;
	 * but that is suboptimal when the ring is full as producer is writing
	 * out new entries in the same cache line.  Defer these updates until a
	 * batch of entries has been consumed.
	 */
	/* Note: we must keep consumer_head valid at all times for __ptr_ring_empty
	 * to work correctly.
	 */
	int consumer_head = r->consumer_head;
	int head = consumer_head++;

	/* Once we have processed enough entries invalidate them in
	 * the ring all at once so producer can reuse their space in the ring.
	 * We also do this when we reach end of the ring - not mandatory
	 * but helps keep the implementation simple.
	 */
	if (unlikely(consumer_head - r->consumer_tail >= r->batch ||
		     consumer_head >= r->size)) {
		/* Zero out entries in the reverse order: this way we touch the
		 * cache line that producer might currently be reading the last;
		 * producer won't make progress and touch other cache lines
		 * besides the first one until we write out all entries.
		 */
		while (likely(head >= r->consumer_tail))
			r->queue[head--] = NULL;
		r->consumer_tail = consumer_head;
	}
	if (unlikely(consumer_head >= r->size)) {
		consumer_head = 0;
		r->consumer_tail = 0;
	}
	/* matching READ_ONCE in __ptr_ring_empty for lockless tests */
	WRITE_ONCE(r->consumer_head, consumer_head);
}

//include/linux/ptr_ring.h:168
static inline void *__ptr_ring_peek(struct ptr_ring *r)
{
	if (likely(r->size))
		return READ_ONCE(r->queue[r->consumer_head]);
	
	return NULL;
}

#endif

#if 1 //skb_array_empty函数

//include/linux/skb_array.h:76
static inline bool skb_array_empty(struct skb_array *a)
{
	return ptr_ring_empty(&a->ring);
}

//include/linux/ptr_ring.h:200
static inline bool ptr_ring_empty(struct ptr_ring *r)
{
	bool ret;

	spin_lock(&r->consumer_lock);
	ret = __ptr_ring_empty(r);
	spin_unlock(&r->consumer_lock);

	return ret;
}

//include/linux/skb_array.h:66
/* Might be slightly faster than skb_array_empty below, but only safe if the
 * array is never resized. Also, callers invoking this in a loop must take care
 * to use a compiler barrier, for example cpu_relax().
 */
static inline bool __skb_array_empty(struct skb_array *a)
{
	return __ptr_ring_empty(&a->ring);
}

//include/linux/ptr_ring.h:193
/*
 * Test ring empty status without taking any locks.
 *
 * NB: This is only safe to call if ring is never resized.
 *
 * However, if some other CPU consumes ring entries at the same time, the value
 * returned is not guaranteed to be correct.
 *
 * In this case - to avoid incorrectly detecting the ring
 * as empty - the CPU consuming the ring entries is responsible
 * for either consuming all ring entries until the ring is empty,
 * or synchronizing with some other CPU and causing it to
 * re-test __ptr_ring_empty and/or consume the ring enteries
 * after the synchronization point.
 *
 * Note: callers invoking this in a loop must use a compiler barrier,
 * for example cpu_relax().
 */
static inline bool __ptr_ring_empty(struct ptr_ring *r)
{
	if (likely(r->size))
		return !r->queue[READ_ONCE(r->consumer_head)];
	return true;
}

#endif

#endif

#if 1 //net_families和sock_register()

//net/socket.c：158
static DEFINE_SPINLOCK(net_family_lock);

//net/socket.c：159
//该数组元素对应了一个协议簇，如AF_INET
//即为每个协议簇提供了创建socket继承体系的回调函数
static const struct net_proto_family __rcu *net_families[NPROTO];// __read_mostly;

//等同代码，内核源码并无下面的代码
net_families[PF_INET] = &inet_family_ops;

//include/linux/net.h：210
struct net_proto_family 
{
	int				family;

	//该回调函数用于创建右侧sock继承关系、并设置包含socket在内的结构的若干字段
	//net：所属的网络名字空间
	//sock：socket结构，已经被创建出来，不过回调函数需要设置其中字段并创建右侧sock继承关系
	//protocol：用户创建socket时指定的协议
	//kern：socket是用于内核还是用户态
	int				(*create)(struct net *net, struct socket *sock, int protocol, int kern);
	
	struct module	*owner;
};

//net/ipv4/af_inet.c：1079
static const struct net_proto_family inet_family_ops = 
{
	.family = PF_INET,
	.create = inet_create,
	.owner	= THIS_MODULE,
};

//net/socket.c：2868
//向net_families注册指定协议簇socket继承体系创建函数
//inet_init()中，为AF_INET注册了inet_family_ops
int sock_register(const struct net_proto_family *ops)
{
	int err;

	spin_lock(&net_family_lock);

	//判断net_families内是否已经注册过
	if (rcu_dereference_protected(net_families[ops->family], lockdep_is_held(&net_family_lock)))
		err = -EEXIST;
	else 
	{
		rcu_assign_pointer(net_families[ops->family], ops);
		err = 0;
	}
	spin_unlock(&net_family_lock);

	pr_info("NET: Registered protocol family %d\n", ops->family);
	return err;
}
EXPORT_SYMBOL(sock_register);

#endif

#if 1 //inetsw和inet_register_protosw()

//net/ipv4/af_inet.c：125
//inetsw数组是若干个链表头组成的数组，其每个元素指向了一个链表，而链表元素类型即inet_protosw结构
//每个链表对应一种socket类型type，比如SOCK_STREAM，而SOCK_STREAM就是数组的下标
//即一个链表中的所有元素，都支持该种socket类型
//每个链表的每个元素，实际上就代表了（type、protocol）的组合，提供了这种组合的操作（ops、prot）
//inet_init()中，调用inet_register_protosw()，将全局数组inetsw_array中存放的所有inet_protosw结构，注册到inetsw中
static struct list_head inetsw[SOCK_MAX];
//static DEFINE_SPINLOCK(inetsw_lock);
static spinlock_t inetsw_lock = __SPIN_LOCK_UNLOCKED(inetsw_lock)


//include/net/protocol.h：81
/* This is used to register socket interfaces for IP protocols.  */
struct inet_protosw 
{
	struct list_head list;

	unsigned short	 type;	   /* This is the 2nd argument to socket(2). */
	unsigned short	 protocol; /* This is the L4 protocol number.  */

	//提供给sock结构使用的若干回调
	struct proto	 *prot;

	//提供给socket结构使用的若干回调
	const struct proto_ops *ops;
  
	unsigned char	 flags;      /* See INET_PROTOSW_* below.  */
};

static struct inet_protosw inetsw_array[] =
{
	{
		.type =       SOCK_STREAM,
		.protocol =   IPPROTO_TCP,
		.prot =       &tcp_prot,
		.ops =        &inet_stream_ops,
		.flags =      INET_PROTOSW_PERMANENT | INET_PROTOSW_ICSK,
	},

	{
		.type =       SOCK_DGRAM,
		.protocol =   IPPROTO_UDP,
		.prot =       &udp_prot,
		.ops =        &inet_dgram_ops,
		.flags =      INET_PROTOSW_PERMANENT,
    },

    {
		.type =       SOCK_DGRAM,
		.protocol =   IPPROTO_ICMP,
		.prot =       &ping_prot,
		.ops =        &inet_sockraw_ops,
		.flags =      INET_PROTOSW_REUSE,
    },

    {
	    .type =       SOCK_RAW,
	    .protocol =   IPPROTO_IP,	/* wild card */
	    .prot =       &raw_prot,
	    .ops =        &inet_sockraw_ops,
	    .flags =      INET_PROTOSW_REUSE,
    }
};

#define INETSW_ARRAY_LEN ARRAY_SIZE(inetsw_array)

//net/ipv4/af_inet.c：1126
//向inetsw注册inet_protosw结构
void inet_register_protosw(struct inet_protosw *p)
{
	struct list_head *lh;
	struct inet_protosw *answer;
	int protocol = p->protocol;
	struct list_head *last_perm;

	spin_lock_bh(&inetsw_lock);

	last_perm = &inetsw[p->type];
	
	list_for_each(lh, &inetsw[p->type]) 
	{
		answer = list_entry(lh, struct inet_protosw, list);
		
		/* 不会覆盖permanent标志的proto*/
		if ((INET_PROTOSW_PERMANENT & answer->flags) == 0)
			break;
		
		if (protocol == answer->protocol)
			goto out_permanent;

		last_perm = lh;
	}

	/* Add the new entry after the last permanent entry if any, so that
	 * the new entry does not override a permanent entry when matched with
	 * a wild-card protocol. But it is allowed to override any existing
	 * non-permanent entry.  This means that when we remove this entry, the
	 * system automatically returns to the old behavior.
	 */
	list_add_rcu(&p->list, last_perm);
out:
	spin_unlock_bh(&inetsw_lock);

	return;

out_permanent:
	pr_err("Attempt to override permanent protocol %d\n", protocol);
	goto out;

out_illegal:
	pr_err("Ignoring attempt to register invalid socket type %d\n",
	       p->type);
	goto out;
}
EXPORT_SYMBOL(inet_register_protosw);

#endif

#if 1 //proto_list和proto_register()

//net/core/sock.c：142
//所有proto结构组成的链表，例如tcp_prot、netlink_proto都在该链表中
//static LIST_HEAD(proto_list);
static struct list_head proto_list = {&proto_list, &proto_list};
//static DEFINE_MUTEX(proto_list_mutex);
static struct mutex proto_list_mutex =  __MUTEX_INITIALIZER(proto_list_mutex);

//net/core/sock.c：3222
#define PROTO_INUSE_NR	64

//net/core/sock.c：3227
//在位图proto_inuse_idx中，proto_listl链表中每个proto结构都会占据一位，proto结构的inuse_idx字段记录了该位
//在位图proto_inuse_idx中，被设置为1的位表示已经被占据
//static DECLARE_BITMAP(proto_inuse_idx, PROTO_INUSE_NR);
static unsigned long proto_inuse_idx[BITS_TO_LONGS(PROTO_INUSE_NR)];

//include/net/sock.h：1067
/* Networking protocol blocks we attach to sockets.
 * socket layer -> transport layer interface，socket层到传输层的接口
 */
struct proto 
{
	void		(*close)(struct sock *sk, long timeout);
	int			(*pre_connect)(struct sock *sk, struct sockaddr *uaddr, int addr_len);
	int			(*connect)(struct sock *sk, struct sockaddr *uaddr, int addr_len);
	int			(*disconnect)(struct sock *sk, int flags);

	struct sock*(*accept)(struct sock *sk, int flags, int *err, bool kern);

	int			(*ioctl)(struct sock *sk, int cmd, unsigned long arg);
	int			(*init)(struct sock *sk);
	void		(*destroy)(struct sock *sk);
	void		(*shutdown)(struct sock *sk, int how);
	int			(*setsockopt)(struct sock *sk, int level, int optname, char __user *optval, unsigned int optlen);
	int			(*getsockopt)(struct sock *sk, int level, int optname, char __user *optval, int __user *option);
	void		(*keepalive)(struct sock *sk, int valbool);
	

	int			(*compat_setsockopt)(struct sock *sk,
					int level,
					int optname, char __user *optval,
					unsigned int optlen);
	int			(*compat_getsockopt)(struct sock *sk,
					int level,
					int optname, char __user *optval,
					int __user *option);
	int			(*compat_ioctl)(struct sock *sk,
					unsigned int cmd, unsigned long arg);

	int			(*sendmsg)(struct sock *sk, struct msghdr *msg,
					   size_t len);
	int			(*recvmsg)(struct sock *sk, struct msghdr *msg,
					   size_t len, int noblock, int flags,
					   int *addr_len);
	int			(*sendpage)(struct sock *sk, struct page *page,
					int offset, size_t size, int flags);
	int			(*bind)(struct sock *sk,
					struct sockaddr *uaddr, int addr_len);

	int			(*backlog_rcv) (struct sock *sk,
						struct sk_buff *skb);

	void		(*release_cb)(struct sock *sk);

	/* Keeping track of sk's, looking them up, and port selection methods. */
	int			(*hash)(struct sock *sk);
	void			(*unhash)(struct sock *sk);
	void			(*rehash)(struct sock *sk);
	int			(*get_port)(struct sock *sk, unsigned short snum);

	/* Keeping track of sockets in use */
#ifdef CONFIG_PROC_FS
	//查找位图proto_inuse_idx中第一个为0的位，将位置赋予该字段
	//并在位图中设置该位，即表示占据了该位
	unsigned int		inuse_idx;
#endif

	bool			(*stream_memory_free)(const struct sock *sk, int wake);
	bool			(*stream_memory_read)(const struct sock *sk);
	/* Memory pressure */
	void			(*enter_memory_pressure)(struct sock *sk);
	void			(*leave_memory_pressure)(struct sock *sk);
	atomic_long_t		*memory_allocated;	/* Current allocated memory. */
	struct percpu_counter	*sockets_allocated;	/* Current number of sockets. */
	/*
	 * Pressure flag: try to collapse.
	 * Technical note: it is used by multiple contexts non atomically.
	 * All the __sk_mem_schedule() is of this nature: accounting
	 * is strict, actions are advisory and have some latency.
	 */
	unsigned long		*memory_pressure;
	long			*sysctl_mem;

	int			*sysctl_wmem;
	int			*sysctl_rmem;
	u32			sysctl_wmem_offset;
	u32			sysctl_rmem_offset;

	int			max_header;
	bool			no_autobind;

	//该缓冲分配的对象是相应的套接字结构，比如对TCP而言，即tcp_sock结构
	//该缓冲分配的对象大小为.obj_sizei字段
	//该缓冲常使用kmem_cache_create_usercopy()创建，a cache with a region suitable for copying to userspace
	//调用kmem_cache_create_usercopy()时，参数useroffset=.useroffset、参数usersize=.usersize、参数flags=.slab_flags
	struct kmem_cache	*slab;

	//.slab字段对应的内存池，要分配的对象大小
	//相应的套接字结构的大小，比如对TCP而言，即tcp_sock的大小
	unsigned int		obj_size;	

	//分配.slab缓冲区时指定的标志
	slab_flags_t		slab_flags;

	//.slab缓冲常使用kmem_cache_create_usercopy()创建，a cache with a region suitable for copying to userspace
	//调用kmem_cache_create_usercopy()时，参数useroffset=.useroffset、参数usersize=.usersize、参数flags=.slab_flags	
	unsigned int		useroffset;	/* Usercopy region offset */
	unsigned int		usersize;	/* Usercopy region size */

	struct percpu_counter	*orphan_count;	//统计套接字个数

	struct request_sock_ops		*rsk_prot;
	struct timewait_sock_ops 	*twsk_prot;

	union 
	{
		struct inet_hashinfo	*hashinfo;
		struct udp_table		*udp_table;
		struct raw_hashinfo		*raw_hash;
		struct smc_hashinfo		*smc_hash;
	} h;

	struct module		*owner;

	//和VFS中目录项中的名称相关
	///proc/slabinfo中显示的.slab缓冲区
	char				name[32];

	struct list_head	node;		//构成proto_list链表
#ifdef SOCK_REFCNT_DEBUG

	//当前结构的引用计数。比如tcp_prot，当创建新socket时，该计数器++
	atomic_t		socks;
#endif
	int			(*diag_destroy)(struct sock *sk, int err);
} __randomize_layout;

//net/ipv4/tcp_ipv4.c：2571
struct proto tcp_prot = 
{
	//和VFS中目录项中的名称相关
	///proc/slabinfo中显示的.slab缓冲区
	.name			= "TCP",				
	
	.owner			= THIS_MODULE,
	.close			= tcp_close,
	.pre_connect	= tcp_v4_pre_connect,
	.connect		= tcp_v4_connect,
	.disconnect		= tcp_disconnect,
	.accept			= inet_csk_accept,
	.ioctl			= tcp_ioctl,
	.init			= tcp_v4_init_sock,		//调用socket()时被调用，任务：初始化tcp_sock
	.destroy		= tcp_v4_destroy_sock,
	.shutdown		= tcp_shutdown,
	.setsockopt		= tcp_setsockopt,
	.getsockopt		= tcp_getsockopt,
	.keepalive		= tcp_set_keepalive,
	.recvmsg		= tcp_recvmsg,
	.sendmsg		= tcp_sendmsg,
	.sendpage		= tcp_sendpage,
	.backlog_rcv	= tcp_v4_do_rcv,
	.release_cb		= tcp_release_cb,
	.hash			= inet_hash,
	.unhash			= inet_unhash,
	.get_port		= inet_csk_get_port,	//调用bind()时被调用
											//根据tcp_hashinfo.bhash表，完成端口绑定工作（包括bind时指定端口与否）
											
	.enter_memory_pressure	= tcp_enter_memory_pressure,
	.leave_memory_pressure	= tcp_leave_memory_pressure,
	.stream_memory_free	= tcp_stream_memory_free,
	.sockets_allocated	= &tcp_sockets_allocated,
	.orphan_count		= &tcp_orphan_count,
	.memory_allocated	= &tcp_memory_allocated,
	.memory_pressure	= &tcp_memory_pressure,
	.sysctl_mem		= sysctl_tcp_mem,
	.sysctl_wmem_offset	= offsetof(struct net, ipv4.sysctl_tcp_wmem),
	.sysctl_rmem_offset	= offsetof(struct net, ipv4.sysctl_tcp_rmem),
	.max_header		= MAX_TCP_HEADER,

	//.slab字段对应的内存池，要分配的对象大小
	.obj_size		= sizeof(struct tcp_sock),
	
	.slab_flags		= SLAB_TYPESAFE_BY_RCU,
	.twsk_prot		= &tcp_timewait_sock_ops,
	.rsk_prot		= &tcp_request_sock_ops,
	.h.hashinfo		= &tcp_hashinfo,				//inet_hashinfo结构，包含bhash（被占用端口hash）、ehash（已建立连接hash）、listening_hash/lhash2（监听哈希）
	.no_autobind		= true,

	.compat_setsockopt	= compat_tcp_setsockopt,
	.compat_getsockopt	= compat_tcp_getsockopt,

	.diag_destroy		= tcp_abort,

	//inet_init()中调用proto_register()设置
	//内部会调用kmem_cache_create_usercopy()创建a cache with a region suitable for copying to userspace
	//调用kmem_cache_create_usercopy()时，参数useroffset=.useroffset、参数usersize=.usersize、参数flags=.slab_flags
	//该内存池，用于.obj_size，即struct tcp_sock结构的分配
	.slab =;									
	
	.rsk_prot->slab_name = "request_sock_TCP";	//rsk_prot指向tcp_request_sock_ops
	.rsk_prot->slab =;							//构建内存池，用于tcp_request_sock_ops.obj_size，即struct tcp_request_sock的分配
	
	.twsk_prot->twsk_slab_name = "tw_sock_TCP";	//twsk_prot指向tcp_timewait_sock_ops
	.twsk_prot->twsk_slab =;					//创建内存池，用于twsk_prot->twsk_obj_size，即struct tcp_timewait_sock的分配
	
	.inuse_idx	=;								//查找位图proto_inuse_idx中第一个为0的位，将位置赋予该字段
												//并在位图中设置该位，即表示占据了该位
												
	.node =;									//将tcp_prot加入到链表proto_list中
};
EXPORT_SYMBOL(tcp_prot);

//net/core/sock.c：3370
//该函数的主要任务是在proto_list链表中注册prot，并初始化prot部分字段
int proto_register(struct proto *prot, int alloc_slab)
{
	int ret = -ENOBUFS;

	//对于netlink_proto_init()，alloc_slab=0
	if (alloc_slab) 
	{
		prot->slab = kmem_cache_create_usercopy(prot->name,
					prot->obj_size, 0,
					SLAB_HWCACHE_ALIGN | SLAB_ACCOUNT |
					prot->slab_flags,
					prot->useroffset, prot->usersize,
					NULL);

		if (prot->slab == NULL) 
		{
			pr_crit("%s: Can't create sock SLAB cache!\n",
				prot->name);
			goto out;
		}

		if (req_prot_init(prot))
			goto out_free_request_sock_slab;

		if (prot->twsk_prot != NULL) 
		{
			prot->twsk_prot->twsk_slab_name = kasprintf(GFP_KERNEL, "tw_sock_%s", prot->name);

			if (prot->twsk_prot->twsk_slab_name == NULL)
				goto out_free_request_sock_slab;

			prot->twsk_prot->twsk_slab =
				kmem_cache_create(prot->twsk_prot->twsk_slab_name,
						  prot->twsk_prot->twsk_obj_size,
						  0,
						  SLAB_ACCOUNT |
						  prot->slab_flags,
						  NULL);
			if (prot->twsk_prot->twsk_slab == NULL)
				goto out_free_timewait_sock_slab_name;
		}
	}

	mutex_lock(&proto_list_mutex);
	
	ret = assign_proto_idx(prot);
	if (ret) 
	{
		mutex_unlock(&proto_list_mutex);
		goto out_free_timewait_sock_slab_name;
	}
	
	list_add(&prot->node, &proto_list);

	mutex_unlock(&proto_list_mutex);

	return ret;

out_free_timewait_sock_slab_name:
	if (alloc_slab && prot->twsk_prot)
		kfree(prot->twsk_prot->twsk_slab_name);
out_free_request_sock_slab:
	if (alloc_slab) {
		req_prot_cleanup(prot->rsk_prot);

		kmem_cache_destroy(prot->slab);
		prot->slab = NULL;
	}
out:
	return ret;
}
EXPORT_SYMBOL(proto_register);

//net/core/sock.c：3345
static int req_prot_init(const struct proto *prot)
{
	//对于tcp，rsk_prot=&tcp_request_sock_ops
	struct request_sock_ops *rsk_prot = prot->rsk_prot;

	if (!rsk_prot)
		return 0;

	rsk_prot->slab_name = kasprintf(GFP_KERNEL, "request_sock_%s", prot->name);
	if (!rsk_prot->slab_name)
		return -ENOMEM;

	rsk_prot->slab = kmem_cache_create(rsk_prot->slab_name,
					   rsk_prot->obj_size, 0,
					   SLAB_ACCOUNT | prot->slab_flags,
					   NULL);

	if (!rsk_prot->slab) {
		pr_crit("%s: Can't create request sock SLAB cache!\n",
			prot->name);
		return -ENOMEM;
	}
	return 0;
}

//net/core/sock.c：3302
static int assign_proto_idx(struct proto *prot)
{
	//查找位图proto_inuse_idx中，第一个为0的位
	prot->inuse_idx = find_first_zero_bit(proto_inuse_idx, PROTO_INUSE_NR);

	if (unlikely(prot->inuse_idx == PROTO_INUSE_NR - 1)) 
	{
		pr_err("PROTO_INUSE_NR exhausted\n");
		return -ENOSPC;
	}

	set_bit(prot->inuse_idx, proto_inuse_idx);

	return 0;
}

#endif

#if 1 //inet_protos和inet_add_protocol()

//net/ipv4/protocol.c：27
//该数组的每个元素对应一种协议，比如udp、tcp、ip
//元素的索引，即协议编号，比如数组下标17，对应的就是udp协议（其协议号也为17）
//即，该数组给出了IP承载的协议处理函数
//由inet_init()初始化该数组，即设置icmp_protocol、udp_protocol、tcp_protocol、igmp_protocol
struct net_protocol __rcu *inet_protos[MAX_INET_PROTOS];// __read_mostly;
EXPORT_SYMBOL(inet_protos);

//include/net/protocol.h:34
/* This is one larger than the largest protocol value that can be
 * found in an ipv4 or ipv6 header.  Since in both cases the protocol
 * value is presented in a __u8, this is defined to be 256.
 */
#define MAX_INET_PROTOS		256

//include/net/protocol.h:37
/* This is used to register protocols. */
struct net_protocol 
{
	//对于发往本机的数据包而言，如果查找路由表，然后再查找skb所属的socket会比较浪费，因为socket本身就缓存了路由信息
	//这种情况下，不如先查找skb所属的socket
	//然而对于转发数据包较多的情况，就应该先查找路由表更节约时间
	//内核使用了sysctl命令sysctl_ip_early_demux(预分流)控制上述方案，为1时（默认），先查找skb所属的socket
	//这种情况下会调用该回调函数
	int			(*early_demux)(struct sk_buff *skb);
	int			(*early_demux_handler)(struct sk_buff *skb);

	//正常传输层协议处理函数
	int			(*handler)(struct sk_buff *skb);

	/* This returns an error if we weren't able to handle the error. */
	int			(*err_handler)(struct sk_buff *skb, u32 info);

	unsigned int		no_policy:1,
						netns_ok:1,		//为true表示namespace aware，才能注册到inet_protos中
				/* does the protocol do more stringent
				 * icmp tag validation than simple
				 * socket lookup?
				 */
						icmp_strict_tag_validation:1;
};

//net/ipv4/af_inet.c：1705
static struct net_protocol tcp_protocol = 
{
	.early_demux			=	tcp_v4_early_demux,
	.early_demux_handler 	=  	tcp_v4_early_demux,
	.handler				=	tcp_v4_rcv,
	.err_handler			=	tcp_v4_err,
	.no_policy				=	1,
	.netns_ok				=	1,
	
	.icmp_strict_tag_validation = 1,
};

//net/ipv4/protocol.c：32
//向inet_protos注册IP承载的协议处理函数
int inet_add_protocol(const struct net_protocol *prot, unsigned char protocol)
{
	if (!prot->netns_ok) 
	{
		pr_err("Protocol %u is not namespace aware, cannot register.\n", protocol);
		return -EINVAL;
	}

	return !cmpxchg((const struct net_protocol **)&inet_protos[protocol], NULL, prot) ? 0 : -1;
}
EXPORT_SYMBOL(inet_add_protocol);

#endif

#if 1 //SNMP和MIB

//include/net/netns/mib.h:7
struct netns_mib 
{
	DEFINE_SNMP_STAT(struct tcp_mib, tcp_statistics);
	//DEFINE_SNMP_STAT(struct ipstats_mib, ip_statistics);
	struct ipstats_mib __percpu ip_statistics;
	
	DEFINE_SNMP_STAT(struct linux_mib, net_statistics);
	DEFINE_SNMP_STAT(struct udp_mib, udp_statistics);
	DEFINE_SNMP_STAT(struct udp_mib, udplite_statistics);
	DEFINE_SNMP_STAT(struct icmp_mib, icmp_statistics);
	DEFINE_SNMP_STAT_ATOMIC(struct icmpmsg_mib, icmpmsg_statistics);

#if IS_ENABLED(CONFIG_IPV6)
	struct proc_dir_entry *proc_net_devsnmp6;
	DEFINE_SNMP_STAT(struct udp_mib, udp_stats_in6);
	DEFINE_SNMP_STAT(struct udp_mib, udplite_stats_in6);

	//DEFINE_SNMP_STAT(struct ipstats_mib, ipv6_statistics);
	struct ipstats_mib __percpu ipv6_statistics;
	
	DEFINE_SNMP_STAT(struct icmpv6_mib, icmpv6_statistics);
	DEFINE_SNMP_STAT_ATOMIC(struct icmpv6msg_mib, icmpv6msg_statistics);
#endif
#ifdef CONFIG_XFRM_STATISTICS
	DEFINE_SNMP_STAT(struct linux_xfrm_mib, xfrm_statistics);
#endif
};

//include/net/snmp.h:114
#define DEFINE_SNMP_STAT(type, name)	__typeof__(type) __percpu *name

//include/net/snmp.h:51
#define IPSTATS_MIB_MAX	__IPSTATS_MIB_MAX
struct ipstats_mib 
{
	/* mibs[] must be first field of struct ipstats_mib */

	//index IPSTATS_MIB_INPKTS	=1，		表示接收到的数据包数量，ip_rcv()中会加1
	//index IPSTATS_MIB_INOCTETS=2，		表示接收到的字节数，ip_rcv()中会增加
	//index IPSTATS_MIB_INHDRERRORS=7,	表示ip头部结构出错统计，即出错的包数目
	//index IPSTATS_MIB_INTRUNCATEDPKTS=12, 当帧长度-MAC头部长度，小于ip头部的总长度字段tot_len时，加1
	//index IPSTATS_MIB_INDISCARDS=13，	表示接收包时，丢弃的数据包数量
	//index IPSTATS_MIB_CSUMERRORS,		表示ip头checksum计算出错的次数
	//index IPSTATS_MIB_NOECTPKTS开始的4项：关于显示拥塞通知分片数量统计
	u64		mibs[IPSTATS_MIB_MAX];
	
	struct u64_stats_sync syncp;
};

/* ipstats mib definitions */
/*
 * RFC 1213:  MIB-II
 * RFC 2011 (updates 1213):  SNMPv2-MIB-IP
 * RFC 2863:  Interfaces Group MIB
 * RFC 2465:  IPv6 MIB: General Group
 * draft-ietf-ipv6-rfc2011-update-10.txt: MIB for IP: IP Statistics Tables
 */
enum
{
	IPSTATS_MIB_NUM = 0,
/* frequently written fields in fast path, kept in same cache line */

	//表示接收到的数据包数量，ip_rcv()中会加1
	IPSTATS_MIB_INPKTS,				/* InReceives */

	//表示接收到的字节数，ip_rcv()中会增加
	IPSTATS_MIB_INOCTETS,			/* InOctets */

	//表示传入本机（目的地为本机）的数据包的个数
	IPSTATS_MIB_INDELIVERS,			/* InDelivers */
	
	IPSTATS_MIB_OUTFORWDATAGRAMS,	/* OutForwDatagrams */
	IPSTATS_MIB_OUTPKTS,			/* OutRequests */
	IPSTATS_MIB_OUTOCTETS,			/* OutOctets */
/* other fields */

	//ip头部结构出错次数统计，即出错的包数目
	IPSTATS_MIB_INHDRERRORS,		/* InHdrErrors */
	
	IPSTATS_MIB_INTOOBIGERRORS,		/* InTooBigErrors */
	IPSTATS_MIB_INNOROUTES,			/* InNoRoutes */
	IPSTATS_MIB_INADDRERRORS,		/* InAddrErrors */
	IPSTATS_MIB_INUNKNOWNPROTOS,		/* InUnknownProtos */

	//当帧长度-MAC头部长度，小于ip头部的总长度字段tot_len时，加1
	IPSTATS_MIB_INTRUNCATEDPKTS,		/* InTruncatedPkts */

	//表示接收包时，丢弃的数据包数量
	IPSTATS_MIB_INDISCARDS,			/* InDiscards */
	
	IPSTATS_MIB_OUTDISCARDS,		/* OutDiscards */
	IPSTATS_MIB_OUTNOROUTES,		/* OutNoRoutes */
	IPSTATS_MIB_REASMTIMEOUT,		/* ReasmTimeout */
	IPSTATS_MIB_REASMREQDS,			/* ReasmReqds */
	IPSTATS_MIB_REASMOKS,			/* ReasmOKs */
	IPSTATS_MIB_REASMFAILS,			/* ReasmFails */
	IPSTATS_MIB_FRAGOKS,			/* FragOKs */
	IPSTATS_MIB_FRAGFAILS,			/* FragFails */
	IPSTATS_MIB_FRAGCREATES,		/* FragCreates */
	IPSTATS_MIB_INMCASTPKTS,		/* InMcastPkts */
	IPSTATS_MIB_OUTMCASTPKTS,		/* OutMcastPkts */
	IPSTATS_MIB_INBCASTPKTS,		/* InBcastPkts */
	IPSTATS_MIB_OUTBCASTPKTS,		/* OutBcastPkts */
	IPSTATS_MIB_INMCASTOCTETS,		/* InMcastOctets */
	IPSTATS_MIB_OUTMCASTOCTETS,		/* OutMcastOctets */
	IPSTATS_MIB_INBCASTOCTETS,		/* InBcastOctets */
	IPSTATS_MIB_OUTBCASTOCTETS,		/* OutBcastOctets */

	//ip头检验和出错次数统计
	IPSTATS_MIB_CSUMERRORS,			/* InCsumErrors */

	//关于显示拥塞通知分片数量统计
	IPSTATS_MIB_NOECTPKTS,			/* tos字段低两位=00：发送主机不支持ECN，InNoECTPkts */
	IPSTATS_MIB_ECT1PKTS,			/* tos字段低两位=01或者10：发送主机支持ECN，InECT1Pkts */
	IPSTATS_MIB_ECT0PKTS,			/* tos字段低两位=01或者10：发送主机支持ECN，InECT0Pkts */
	IPSTATS_MIB_CEPKTS,				/* tos字段低两位=11：路由器正在经历拥塞，InCEPkts */

	IPSTATS_MIB_REASM_OVERLAPS,		/* ReasmOverlaps */
	__IPSTATS_MIB_MAX
};


//include/net/ip.h:290
#define __IP_UPD_PO_STATS(net, field, val) __SNMP_UPD_PO_STATS64((net)->mib.ip_statistics, field, val)

//include/net/snmp.h:193
#define __SNMP_UPD_PO_STATS64(mib, basefield, addend) __SNMP_UPD_PO_STATS(mib, basefield, addend)

//include/net/snmp.h:144
#define __SNMP_UPD_PO_STATS(mib, basefield, addend)	\
	do { \
		__typeof__((mib->mibs) + 0) ptr = mib->mibs;	\
		__this_cpu_inc(ptr[basefield##PKTS]);		\
		__this_cpu_add(ptr[basefield##OCTETS], addend);	\
	} while (0)

//include/net/ip.h
#define __IP_INC_STATS(net, field)		__SNMP_INC_STATS64((net)->mib.ip_statistics, field)

//include/net/snmp.h:187
#define __SNMP_INC_STATS64(mib, field)	__SNMP_INC_STATS(mib, field)

//include/net/snmp.h:121
#define __SNMP_INC_STATS(mib, field)	__this_cpu_inc(mib->mibs[field])

//include/net/ip.h:288
#define __IP_ADD_STATS(net, field, val) __SNMP_ADD_STATS64((net)->mib.ip_statistics, field, val)

//include/net/snmp.h:190
#define __SNMP_ADD_STATS64(mib, field, addend)	__SNMP_ADD_STATS(mib, field, addend)

//include/net/snmp.h:133
#define __SNMP_ADD_STATS(mib, field, addend)	__this_cpu_add(mib->mibs[field], addend)

#endif
